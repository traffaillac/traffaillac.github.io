import librosa as rs
import numpy as np
import pygame as pg

do4, sr = rs.load("lalalilalou.m4a") # renvoie nécessairement un float32 dans [-1,1]
pg.mixer.init(sr, -16, 1) # fréquence=sr, format=int16, mono
pg.mixer.set_num_channels(32) # nombre de notes qui peuvent être jouées simultanément
screen = pg.display.set_mode((640, 480)) # pour le focus

print("Génération des notes: ", end="")
touches = [
	9, 49, 97, 50, 122, 101, 52, 114, 53, 116, 54, 121,
	117, 56, 105, 57, 111, 112, 41, 94, 45, 36, 8, 13,
	64, 113, 119, 115, 120, 99, 102, 118, 103, 98, 104, 110,
	44, 107, 59, 108, 58, 61, 249, 1073742053, 96]
notes = {}
for touche, steps in zip(touches, range(-24, 21)):
	print("#", end="", flush=True)
	y = rs.effects.pitch_shift(do4, sr, steps)
	notes[touche] = pg.sndarray.make_sound((y*32767).astype('int16')) # conversion en int16 dans [-32767,32767]
print()

while True:
	ev = pg.event.wait()
	if ev.type==pg.QUIT or ev.type==pg.KEYDOWN and ev.key==pg.K_ESCAPE:
		break
	if ev.type==pg.KEYDOWN:
		if ev.key in notes:
			notes[ev.key].play()
pg.quit()
