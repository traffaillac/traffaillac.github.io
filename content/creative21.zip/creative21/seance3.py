Scale.default = "chromatic"
Clock.bpm = 90
p1 >> klank(
    oct=3,
    spin=1,
    lpf=sinvar([800,2000],8))
p2 >> pluck([0],
    amp=.5,
    oct=3,
    lpf=1100,
    lpr=2,
    echo=.66,
    echotime=4,
    chop=4)
p3 >> play("{&&&&&&&p}",
    dur=4,
    amp=1,
    room=1,
    mix=.2)
p4 >> glass([0,-5,0,5,0,4,0,3],
    chop=4)

