# Knapsack

## Motivating problem

* Description : you have a knapsack with a capacity of W kg, and a list of items with weights and values, fill the sack with the biggest total value
* Limits of naive solution

## General principle

* Draw the decision tree and spot recurring nodes

## Implementation

* Optimization 1 : divide weights by common divisor
* Optimization 2 : fold the array from 2D to 1D
* Optimization 3 : sorting the items by value/weight

# Applications

* Optimisation de charges sur les bateaux ou avions
* Minimisation de déchets lors de la découpe de matériaux
* Remplissage des trames lors des téléchargements Internet
