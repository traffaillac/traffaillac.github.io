# Freewick tree or binary indexed tree

## Motivating problem

* Problem description : given an array of numbers, compute prefix sums
* Key requirement : updates are mixed with queries (ex. arithmetic coding)
* Limits of naive solution

## General principle

* Draw array with 9 elements zero-initialized, add(i, v) updates value at index i, sum(i) computes prefix sum up to i (excluded).
* Draw **predefined tree structure**, each element labeled with its index, binary representation and sum range (values between its parent included and its index excluded). Depth in tree is number of set bits in index, parent is index minus lsb.
* Describe value update on tree (increment ranges to the right at same level, then at upper level, etc. to the root)
* Describe sum access on tree (sum all nodes up to the root)

## Implementation

* LSB = Least Significant set Bit, MSB = Most Significant set Bit
* LSB(x) = x & -x
* unset_LSB(x) = x & (x - 1)
* To iterate over values to update, add lowest set bit until getting past size.
* To iterate over values to sum, reset lowest set bit until reaching 0.

## Application to other problems

* Range sums
* 2D range sums
* Other associative binary operations
* Inversion count of array with unique values (when values are integers AND bounded they can be used as indexes, which I call the Fenwick trick)

## Challenges

* Implement and get it to run on Kattis :)
* Change the implementation to remove the unused index 0 (advice : tree.sum(0) should still return 0)
* Try implementing the same functions with a Heap structure
