# Graphs I

## Glossary

* Vertices/Nodes (noeuds)
* Edges (arêtes)
* Weighted (pondéré)
* Directed (orienté)
* In/Out degree (degré entrant/sortant)
* Self-loop (boucle)
* Multigraph
* Sparse/Dense (creux/dense)
* Planar
* Chromatic number
* _Strongly_ connected components (composantes _fortement_ connexes)
* Path, cycle/circuit (chemin, cycle)
* Eulerian/Hamiltonian path/cycle
* Topological order
* Sub graph (sous-graphe)
* Clique
* Simple graph = no self-loop and not multigraph
* Tree, forest
* Complete graph (graphe complet)
* Directed Acyclic Graph DAG (graphe orienté acyclique)
* Bipartite _undirected_ graph (graphe biparti)
* Matching (couplage)

## Graph traversal

* Depth First Search DFS (profondeur)

```python
sys.setrecursionlimit(...)
def dfs(G, visited, u):
	print("Visit", u)
	visited[n] = True # must be set before any call to dfs
	for v in G[u]:
		if not visited[v]:
			dfs(G, visited, v)
```

* Breadth First Search BFS (largeur)

```python
def bfs(G, visited, u):
	fifo = collections.deque((u,))
	visited[u] = True
	while fifo:
		u = queue.popleft()
		if visited[u]: # may have been queued several times
			continue
		print("Visit", u)
		visited[u] = True
		for v in G[u]:
			if not visited[v]:
				fifo.append(v)

def bfs2(G, queued, u):
	fifo = collections.deque((u,))
	queued[u] = True
	while fifo:
		u = queue.popleft()
		print("Visit", u)
		for v in G[u]:
			if not queued[v]:
				queued[v] = True
				fifo.append(v)
```

* Special case for 2D grids (implicit graph)

```python
def dfs(G, visited, r, c):
	print("Visit", r, c)
	visited[r][c] = True
	for dr, dc in ((-1,0), (0,-1), (1,0), (0,1)): # take care to make edges unwalkable
		if G[r+dr][c+dc] == ' ' and not visited[r+dr][c+dc]:
			dfs(G, visited, r+dr, c+dc)
```

## Simple algorithms

* Counting connected components (undirected) -> count number of dfs/bfs calls to visit all vertices
* Flood fill (undirected) -> propagate value during each dfs/bfs call
* Bipartite check (undirected) -> flood fill two alternating colors, failing if two nodes connected by an edge have the same color

## Topological sorting (directed)

* Kahn's algorithm
	1. count number of incoming edges for each node
	2. add all roots to queue
	3. for each item in queue, decrease count of outgoing nodes, then add every node with zero count to queue
	4. nodes were visited in topological order
* DFS algorithm
	1. set all nodes to unmarked
	2. for each unmarked node, run dfs
	3. for each visited node mark temporary, visit every unmarked nodes (with error if any has a temporary mark), then turn temporary into permanent mark and add to left of queue
	4. queue contains nodes in topological order

## Articulation/cut vertices and bridges (undirected)

1. start from arbitrary root node, give depth 0
2. for each connected unvisited node, recurse while giving depth+1
3. compute lowest reachable depth from current node as min of lowest depths from neighbors (excl. parent) and own depth
3. for each neighbor, if lowest reachable depth is strictly higher than current depth then edge is a bridge
4. for each neighbor, if lowest reachable depth is higher or equal than current depth and current node is not root, then it is a cut vertex
5. if current node is root and has more than 1 child it is a cut vertex
