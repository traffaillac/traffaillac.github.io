/*

Fichier : Affichage.h

Auteur : Thibault Raffaillac <thibaultraffaillac@yahoo.fr>
Cr�� le : 02/12/07
Derni�re modification le : 19/05/08

Ce fichier contient les fonctions permettant tout affichage dans le cadre de mon
TIPE de 2008 (2e ann�e de maths sp�).
Ces fonctions comprennent la cr�ation d'une fen�tre d'affichage, le trac� de
segments et de points, et la sauvegarde de l'image cr��e.

*/

#ifndef TRAF_AFFICHAGE_H
#define TRAF_AFFICHAGE_H

#include <SDL.h>

#ifndef MAX
#define MAX(a,b) (((a)<(b))?(b):(a))
#endif

#ifndef MIN
#define MIN(a,b) (((a)>(b))?(b):(a))
#endif

#define RESOLUTION_X 1280
#define RESOLUTION_Y 800
#define NOIR 0x00000000 // La couleur noire (fa�on de parler :-)

/**
 * Cette fonction lance la SDL, cr�e une fen�tre d'affichage et param�tre le
 * tout pour une utilisation dans le cadre du TIPE.
 *
 * Elle renvoie 0 si tout s'est bien pass� et -1 en cas d'erreur.
 */
int InitAffichage (void);

/**
 * Cette fonction trace une ligne lisse et de couleur dans la fen�tre.
 *
 * Elle renvoie 0 si tout s'est bien pass� et -1 en cas d'erreur.
 */
int Ligne (double x1, double y1, double x2, double y2, const Uint32 couleur);

/**
 * Cette fonction dessine un point de couleur dans la fen�tre.
 * Ce point n'est pas forc�ment dessin� sur un unique pixel, mais sur 4 au
 * maximum.
 * Pour des raisons internes, sa longueur ne devrait de pr�f�rence pas d�passer
 * 400 pixels, sinon elle pourrait ne plus ressembler � une ligne !
 *
 * Elle renvoie 0 si tout s'est bien pass� et -1 en cas d'erreur.
 */
int Point (const double x, const double y, const Uint32 couleur);

/**
 * Cette fonction fournit un d�grad� de couleurs entre le bleu et le rouge, la
 * position du d�grad� entre les deux couleurs �tant sp�cifi�e par la variable
 * intensite (entre 0 et 255).
 * Attention : Cette fonction �quivaut � �crire
 * SDL_MapRGBA (format, intensite, 0, 255-intensite), o� format est le format de
 * couleur d'une surface cr��e avec les masques RMASK � AMASK, mais ce n'est PAS
 * le format de la surface principale !
 *
 * Elle renvoie la couleur demand�e.
 */
Uint32 Nuance (int intensite);

int PriseImage (void);

/**
 * Cette fonction trace un graphe � partir du tableau donn� en argument, dont
 * tailleTableau est suppos� �tre le nombre d'�l�ments.
 */
int TraceGraphe (int tableau[], int tailleTableau);

#endif
