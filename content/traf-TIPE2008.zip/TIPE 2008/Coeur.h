/*

Fichier : Coeur.h

Auteur : Thibault Raffaillac <thibaultraffaillac@yahoo.fr>
Cr�� le : 14/01/08
Derni�re modification le : 10/03/08

Ce fichier contient toutes les fonctions qui ont fait le sujet d'une �tude dans
le cadre le mon TIPE de 2008 (2e ann�e de maths sp�).
Elles comprennent les fonctions de calcul des potentiels et de dessin de la
lentille �lectrostatique et d'autres informations � afficher.
Ces fonctions utilisent les fonctions d'affichage de base pr�sentes dans le
fichier Affichage.h.

*/

#ifndef TRAF_COEUR_H
#define TRAF_COEUR_H

/* Cette variable permet de faire g�n�rer par le programme une image
suppl�mentaire repr�sentant la densit� d'�lectrons � travers une plaque
de 6 cases centr�e sur l'axe de la lentille.
Les trajectoires d'�lectrons ne sont alors plus repr�sent�es pour acc�l�rer
le calcul, et les informations sur les calculs de trajectoire ne sont plus
g�n�r�es dans le fichier stdout pour ne pas l'encombrer. */
#define TRACE_GRAPHE_FOCAL 0

/**
 * Cette fonction initialise les constantes utilis�es dans les fonctions qui
 * suivent.
 */
void InitCoeur (void);

/**
 * Cette fonction initialise le tableau repr�sentant les potentiels avec des
 * valeurs acceptables pour le d�marrage de l'algorithme qui les calculera.
 */
void InitialisationPotentiels (void);

/**
 * Cette fonction calcule une grille de potentiels d�crivant la lentille
 * �lectrostatique, en v�rifiant � chaque fois un crit�re de convergence.
 */
void CalculPotentiels (void);

/**
 * Cette fonction dessine simplement les plaques de la lentille.
 */
void DessinLentille (void);

/**
 * Cette fonction repr�sente la grille des potentiels dans la lentille sous
 * forme de points de couleur, la couleur repr�sentant la variation du potentiel
 * de -V_PLAQUE � V_PLAQUE.
 */
void DessinPotentiels (void);

/**
 * Cette fonction trace NOMBRE_EQUIPOT �quipotentielles dans la lentille, les
 * valeurs de potentiels �tant r�guli�rement r�parties entre -V_PLAQUE et
 * V_PLAQUE.
 */
void DessinEquipotentielles (void);

/**
 * Cette fonction trace le chemin dans la lentille d'un �lectron dont la
 * position et la vitesse initiales sont connues.
 */
void TrajectoireElectron (double x, double xPrime, double yPrime);

/**
 * Si TRACE_GRAPHE_FOCAL vaut 1, cette fonction fait g�n�rer l'image du graphe
 * en bitmap et inscrit les informations recuillies sur le calcul des densit�s
 * d'�lectrons dans stdout.
 * Sinon, elle trace une ligne rouge qui repr�sente le plan au travers duquel
 * les �lectrons sont compt�s.
 */
int TraceGrapheFocal (void);

#endif
