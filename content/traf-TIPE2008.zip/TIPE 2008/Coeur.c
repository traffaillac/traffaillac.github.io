/*

Fichier : Coeur.c

Auteur : Thibault Raffaillac <thibaultraffaillac@yahoo.fr>
Cr�� le : 14/01/08
Derni�re modification le : 20/05/08

Ce fichier contient toutes les fonctions qui ont fait le sujet d'une �tude dans
le cadre le mon TIPE de 2008 (2e ann�e de maths sp�).
Elles comprennent les fonctions de calcul des potentiels et de dessin de la
lentille �lectrostatique et d'autres informations � afficher.
Ces fonctions utilisent les fonctions d'affichage de base pr�sentes dans le
fichier Affichage.h.

*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "Affichage.h"
#include "coeur.h"

#define V_PLAQUE 1000.0 // Le potentiel en volts de la cathode.
#define TAILLE_GAUCHE 16 // Le nombre de points dans la partie gauche de la lentille.
#define TAILLE_DROITE 48 // Le nombre de points dans la partie droite de la lentille.
#define TAILLE_BAS 24 // Le nombre de points dans la partie basse du dispositif.
#define TAILLE_HAUT 16 // Le nombre de points dans le haut de la lentille.
#define VALEUR_CONV 0.001 /* Lorsque la distance qui s�pare une ancienne valeur
de potentiel de sa nouvelle est inf�rieure � cette valeur, la convergence est
atteinte pour le point. */
#define VITESSE_CONV 1.5 // Cette valeur conditionne la vitesse de convergence.
#define NOMBRE_EQUIPOT 8 // Le nombre d'�quipotentielles � tracer.
#define LIMITE_ITERATIONS_POTENTIELS 1000 // Le nombre maximum d'it�rations pour d�terminer les potentiels.
#define LIMITE_ITERATIONS_TRAJECTOIRE ((TAILLE_HAUT+TAILLE_GAUCHE+TAILLE_DROITE)*2) // Le nombre maximum de cases que peut parcourir l'�lectron.
#define LIMITE_ITERATIONS_NEWTON 6 // Le nombre maximum d'it�rations pour annuler une fonction par la m�thode de Newton.
#define VALEUR_ANNULATION 0.001 // Pour l'annulation par la m�thode de Newton : une variable inf�rieure � cette valeur est nulle.
#define PAS_EN_METRES 1.0 // La taille r�elle d'une case de la lentille.
#define Q_SUR_M_SUR_L2 1.0 // Une constante physique du montage.

#define V_HAUT(i,j) (V[(i)*(TAILLE_GAUCHE+TAILLE_DROITE+1)+(j)])
/* Attention : dans V_BAS, l'origine de i est � l'endroit o� commence la matrice
du bas, pas celle du haut. */
#define V_BAS(i,j) (V[(TAILLE_HAUT+1)*(TAILLE_GAUCHE+TAILLE_DROITE+1)+(i)*(TAILLE_GAUCHE+1)+(j)])

static double V[(TAILLE_HAUT+1)*(TAILLE_GAUCHE+TAILLE_DROITE+1)+TAILLE_BAS*(TAILLE_GAUCHE+1)],
   pasEnPixels, origineX, origineY;
#if (TRACE_GRAPHE_FOCAL == 1)
#define ENTREES_GRAPHE_PAR_CASE 16
static int densitesElectrons[ENTREES_GRAPHE_PAR_CASE*6]={0}, electronsNonComptes=0,
   electronsArrives=0;
#endif

void InitCoeur (void)
{
   // D�claration des variables
   double dx, dy;

   dx = ((double)(RESOLUTION_X-1))/(2*(TAILLE_GAUCHE+TAILLE_DROITE));
   dy = ((double)(RESOLUTION_Y-1))/(2*(TAILLE_BAS+TAILLE_HAUT));
   pasEnPixels = MIN(dx,dy);
   origineX = ((double)(RESOLUTION_X-1))/2-pasEnPixels*(TAILLE_GAUCHE+TAILLE_DROITE);
   origineY = ((double)(RESOLUTION_Y-1))/2-pasEnPixels*(TAILLE_HAUT+TAILLE_BAS);
fprintf (stdout, "Initialisation du coeur:\n   tailleTableau=%d\n   pasEnPixels=%lf\n   origineX=%lf\n   origineY=%lf\n", (TAILLE_HAUT+1)*(TAILLE_GAUCHE+TAILLE_DROITE+1)+TAILLE_BAS*(TAILLE_GAUCHE+1), pasEnPixels, origineX, origineY);

   return;
}

void InitialisationPotentiels (void)
{
   // D�claration des variables
   int i, j;

   for (i = 0; i <= TAILLE_HAUT; i++) {
      V_HAUT(i,0) = 0.0;
      for (j = 1; j <= TAILLE_GAUCHE-1; j++) {
         V_HAUT(i,j) = (V_PLAQUE*j)/TAILLE_GAUCHE;
      }
      for ( ; j <= TAILLE_GAUCHE+TAILLE_DROITE; j++) {
         V_HAUT(i,j) = V_PLAQUE;
      }
   }
   for (i = 0 ; i <= TAILLE_BAS-1; i++) {
      V_BAS(i,0) = 0.0;
      for (j = 1; j <= TAILLE_GAUCHE-1; j++) {
         V_BAS(i,j) = (V_PLAQUE*j)/TAILLE_GAUCHE;
      }
      V_BAS(i,TAILLE_GAUCHE) = V_PLAQUE;
   }

   return;
}

void CalculPotentiels (void)
{
   // D�claration des variables
   int convOK, i, j;
   double Vnouv;
int k = 0; double ecartMax;

   /* Remarque : suite � une optimisation du code pour ramener la gestion du
      tableau � une dimension, il ne refl�te plus la structure du code
      algorithmique. Se r�f�rer au fichier OldCoeur.c si besoin est. */
   do {
      convOK = 1;
ecartMax = 0;
      for (j = 1; j <= TAILLE_GAUCHE+TAILLE_DROITE-1; j++) {
         Vnouv = V_HAUT(0,j)+VITESSE_CONV*((V_HAUT(0,j-1)+V_HAUT(0,j+1)+4*V_HAUT(1,j))/6-V_HAUT(0,j));
ecartMax = MAX(ecartMax,fabs(Vnouv-V_HAUT(0,j)));
         if (fabs(Vnouv-V_HAUT(0,j)) >= VALEUR_CONV)
            convOK = 0;
         V_HAUT(0,j) = Vnouv;
      }
      for (i = 1; i <= TAILLE_HAUT-1; i++) {
         for (j = 1; j <= TAILLE_GAUCHE+TAILLE_DROITE-1; j++) {
            Vnouv = V_HAUT(i,j)+VITESSE_CONV*((V_HAUT(i-1,j)+V_HAUT(i+1,j)+V_HAUT(i,j-1)+V_HAUT(i,j+1))/4+(V_HAUT(i+1,j)-V_HAUT(i-1,j))/(8*i)-V_HAUT(i,j));
ecartMax = MAX(ecartMax,fabs(Vnouv-V_HAUT(i,j)));
            if (fabs(Vnouv-V_HAUT(i,j)) >= VALEUR_CONV)
               convOK = 0;
            V_HAUT(i,j) = Vnouv;
         }
      }
      for (j = 1; j <= TAILLE_GAUCHE-1; j++) {
         Vnouv = V_HAUT(TAILLE_HAUT,j)+VITESSE_CONV*
            ((V_HAUT(TAILLE_HAUT-1,j)+V_HAUT(TAILLE_HAUT+1,j)+V_HAUT(TAILLE_HAUT,j-1)+V_HAUT(TAILLE_HAUT,j+1))/4+(V_HAUT(TAILLE_HAUT+1,j)-V_HAUT(TAILLE_HAUT-1,j))/(8*TAILLE_HAUT)-V_HAUT(TAILLE_HAUT,j));
ecartMax = MAX(ecartMax,fabs(Vnouv-V_HAUT(TAILLE_HAUT,j)));
         if (fabs(Vnouv-V_HAUT(TAILLE_HAUT,j)) >= VALEUR_CONV)
            convOK = 0;
         V_HAUT(TAILLE_HAUT,j) = Vnouv;
      }
      for (j = 1; j <= TAILLE_GAUCHE-1; j++) {
         Vnouv = V_BAS(0,j)+VITESSE_CONV*((V_HAUT(TAILLE_HAUT,j)+
            V_BAS(1,j)+V_BAS(0,j-1)+V_BAS(0,j+1))/4+(V_BAS(1,j)-V_HAUT(TAILLE_HAUT,j))/(8*(TAILLE_HAUT+1))-V_BAS(0,j));
ecartMax = MAX(ecartMax,fabs(Vnouv-V_BAS(0,j)));
         if (fabs(Vnouv-V_BAS(0,j)) >= VALEUR_CONV)
            convOK = 0;
         V_BAS(0,j) = Vnouv;
      }
      for (i = 1 ; i <= TAILLE_BAS-2; i++) {
         for (j = 1; j <= TAILLE_GAUCHE-1; j++) {
            Vnouv = V_BAS(i,j)+VITESSE_CONV*((V_BAS(i-1,j)+V_BAS(i+1,j)+V_BAS(i,j-1)+V_BAS(i,j+1))/4+(V_BAS(i+1,j)-V_BAS(i-1,j))/(8*(i+TAILLE_HAUT+1))-V_BAS(i,j));
ecartMax = MAX(ecartMax,fabs(Vnouv-V_BAS(i,j)));
            if (fabs(Vnouv-V_BAS(i,j)) >= VALEUR_CONV)
               convOK = 0;
            V_BAS(i,j) = Vnouv;
         }
      }
k++;
   } while (!convOK && (k < LIMITE_ITERATIONS_POTENTIELS));
fprintf (stdout, "Calcul des potentiels:\n   nombreIterations=%d\n   ecartMax=%lf\n", k, ecartMax);

   return;
}

void DessinLentille (void)
{
   Ligne (origineX, origineY+pasEnPixels*TAILLE_BAS, origineX+pasEnPixels*TAILLE_DROITE, origineY+pasEnPixels*TAILLE_BAS, NOIR);
   Ligne (origineX+pasEnPixels*TAILLE_DROITE, origineY+pasEnPixels*TAILLE_BAS, origineX+pasEnPixels*TAILLE_DROITE, origineY, NOIR);
   Ligne (origineX+pasEnPixels*(TAILLE_DROITE+2*TAILLE_GAUCHE), origineY, origineX+pasEnPixels*(TAILLE_DROITE+2*TAILLE_GAUCHE), origineY+pasEnPixels*TAILLE_BAS, NOIR);
   Ligne (origineX+pasEnPixels*(TAILLE_DROITE+2*TAILLE_GAUCHE), origineY+pasEnPixels*TAILLE_BAS, RESOLUTION_X-1-origineX, origineY+pasEnPixels*TAILLE_BAS, NOIR);
   Ligne (origineX, origineY+pasEnPixels*(TAILLE_BAS+2*TAILLE_HAUT), origineX+pasEnPixels*TAILLE_DROITE, origineY+pasEnPixels*(TAILLE_BAS+2*TAILLE_HAUT), NOIR);
   Ligne (origineX+pasEnPixels*TAILLE_DROITE, origineY+pasEnPixels*(TAILLE_BAS+2*TAILLE_HAUT), origineX+pasEnPixels*TAILLE_DROITE, RESOLUTION_Y-1-origineY, NOIR);
   Ligne (origineX+pasEnPixels*(TAILLE_DROITE+2*TAILLE_GAUCHE), RESOLUTION_Y-1-origineY, origineX+pasEnPixels*(TAILLE_DROITE+2*TAILLE_GAUCHE), origineY+pasEnPixels*(TAILLE_BAS+2*TAILLE_HAUT), NOIR);
   Ligne (origineX+pasEnPixels*(TAILLE_DROITE+2*TAILLE_GAUCHE), origineY+pasEnPixels*(TAILLE_BAS+2*TAILLE_HAUT), RESOLUTION_X-1-origineX, origineY+pasEnPixels*(TAILLE_BAS+2*TAILLE_HAUT), NOIR);

   return;
}

void DessinPotentiels (void)
{
   // D�claration des variables
   int i, j;

   Point (((double)(RESOLUTION_X-1))/2, ((double)(RESOLUTION_Y-1))/2, Nuance(128));
   for (j = 1; j <= TAILLE_GAUCHE+TAILLE_DROITE-1; j++) {
      Point (((double)(RESOLUTION_X-1))/2+pasEnPixels*j, ((double)(RESOLUTION_Y-1))/2, Nuance((int)nearbyint(127.5*(V_PLAQUE+V[j])/V_PLAQUE)));
      Point (((double)(RESOLUTION_X-1))/2-pasEnPixels*j, ((double)(RESOLUTION_Y-1))/2, Nuance((int)nearbyint(127.5*(V_PLAQUE-V[j])/V_PLAQUE)));
   }
   for (i = 1; i <= TAILLE_HAUT-1; i++) {
      Point (((double)(RESOLUTION_X-1))/2, ((double)(RESOLUTION_Y-1))/2+pasEnPixels*i, Nuance(128));
      Point (((double)(RESOLUTION_X-1))/2, ((double)(RESOLUTION_Y-1))/2-pasEnPixels*i, Nuance(128));
      for (j = 1; j <= TAILLE_GAUCHE+TAILLE_DROITE-1; j++) {
         Point (((double)(RESOLUTION_X-1))/2+pasEnPixels*j, ((double)(RESOLUTION_Y-1))/2+pasEnPixels*i, Nuance((int)nearbyint(127.5*(V_PLAQUE+V_HAUT(i,j))/V_PLAQUE)));
         Point (((double)(RESOLUTION_X-1))/2+pasEnPixels*j, ((double)(RESOLUTION_Y-1))/2-pasEnPixels*i, Nuance((int)nearbyint(127.5*(V_PLAQUE+V_HAUT(i,j))/V_PLAQUE)));
         Point (((double)(RESOLUTION_X-1))/2-pasEnPixels*j, ((double)(RESOLUTION_Y-1))/2+pasEnPixels*i, Nuance((int)nearbyint(127.5*(V_PLAQUE-V_HAUT(i,j))/V_PLAQUE)));
         Point (((double)(RESOLUTION_X-1))/2-pasEnPixels*j, ((double)(RESOLUTION_Y-1))/2-pasEnPixels*i, Nuance((int)nearbyint(127.5*(V_PLAQUE-V_HAUT(i,j))/V_PLAQUE)));
      }
   }
   /* Remplacer i par TAILLE_HAUT n'est pas n�cessaire ici, on ne recherche pas
      une ex�cution qui soit la plus rapide possible. */
   Point (((double)(RESOLUTION_X-1))/2, ((double)(RESOLUTION_Y-1))/2+pasEnPixels*i, Nuance(128));
   Point (((double)(RESOLUTION_X-1))/2, ((double)(RESOLUTION_Y-1))/2-pasEnPixels*i, Nuance(128));
   for (j = 1; j <= TAILLE_GAUCHE-1; j++) {
      Point (((double)(RESOLUTION_X-1))/2+pasEnPixels*j, ((double)(RESOLUTION_Y-1))/2+pasEnPixels*i, Nuance((int)nearbyint(127.5*(V_PLAQUE+V_HAUT(i,j))/V_PLAQUE)));
      Point (((double)(RESOLUTION_X-1))/2+pasEnPixels*j, ((double)(RESOLUTION_Y-1))/2-pasEnPixels*i, Nuance((int)nearbyint(127.5*(V_PLAQUE+V_HAUT(i,j))/V_PLAQUE)));
      Point (((double)(RESOLUTION_X-1))/2-pasEnPixels*j, ((double)(RESOLUTION_Y-1))/2+pasEnPixels*i, Nuance((int)nearbyint(127.5*(V_PLAQUE-V_HAUT(i,j))/V_PLAQUE)));
      Point (((double)(RESOLUTION_X-1))/2-pasEnPixels*j, ((double)(RESOLUTION_Y-1))/2-pasEnPixels*i, Nuance((int)nearbyint(127.5*(V_PLAQUE-V_HAUT(i,j))/V_PLAQUE)));
   }
   for (i = 0 ; i <= TAILLE_BAS-2; i++) {
      Point (((double)(RESOLUTION_X-1))/2, ((double)(RESOLUTION_Y-1))/2+pasEnPixels*(i+TAILLE_HAUT+1), Nuance(128));
      Point (((double)(RESOLUTION_X-1))/2, ((double)(RESOLUTION_Y-1))/2-pasEnPixels*(i+TAILLE_HAUT+1), Nuance(128));
      for (j = 1; j <= TAILLE_GAUCHE-1; j++) {
         Point (((double)(RESOLUTION_X-1))/2+pasEnPixels*j, ((double)(RESOLUTION_Y-1))/2+pasEnPixels*(i+TAILLE_HAUT+1), Nuance((int)nearbyint(127.5*(V_PLAQUE+V_BAS(i,j))/V_PLAQUE)));
         Point (((double)(RESOLUTION_X-1))/2+pasEnPixels*j, ((double)(RESOLUTION_Y-1))/2-pasEnPixels*(i+TAILLE_HAUT+1), Nuance((int)nearbyint(127.5*(V_PLAQUE+V_BAS(i,j))/V_PLAQUE)));
         Point (((double)(RESOLUTION_X-1))/2-pasEnPixels*j, ((double)(RESOLUTION_Y-1))/2+pasEnPixels*(i+TAILLE_HAUT+1), Nuance((int)nearbyint(127.5*(V_PLAQUE-V_BAS(i,j))/V_PLAQUE)));
         Point (((double)(RESOLUTION_X-1))/2-pasEnPixels*j, ((double)(RESOLUTION_Y-1))/2-pasEnPixels*(i+TAILLE_HAUT+1), Nuance((int)nearbyint(127.5*(V_PLAQUE-V_BAS(i,j))/V_PLAQUE)));
      }
   }

   return;
}

void DessinEquipotentielles (void)
{
   // D�claration des variables
   int i, j, k;
   double Vequipot, nouvX, ancX;
   Uint32 couleur1, couleur2;

   if ((NOMBRE_EQUIPOT%2) == 1) {
      Ligne (((double)(RESOLUTION_X-1))/2, origineY, ((double)(RESOLUTION_X-1))/2, ((double)(RESOLUTION_Y-1))/2, Nuance(128));
      Ligne (((double)(RESOLUTION_X-1))/2, ((double)(RESOLUTION_Y-1))/2, ((double)(RESOLUTION_X-1))/2, (double)(RESOLUTION_Y-1)-origineY, Nuance(128));
   }
   for (i = 1; i <= NOMBRE_EQUIPOT/2; i++) {
      Vequipot = V_PLAQUE-i*V_PLAQUE*2/(NOMBRE_EQUIPOT+1);
      k = (int)(TAILLE_GAUCHE*Vequipot/V_PLAQUE);
      ancX = (TAILLE_GAUCHE*Vequipot/V_PLAQUE)*pasEnPixels;
      couleur1 = Nuance((int)nearbyint(127.5*(V_PLAQUE+Vequipot)/V_PLAQUE));
      couleur2 = Nuance((int)nearbyint(127.5*(V_PLAQUE-Vequipot)/V_PLAQUE));
      for (j = TAILLE_BAS-2; j >= 0; j--) {
         if (Vequipot < V_BAS(j,k)) {
            do {
               k--;
            } while (Vequipot < V_BAS(j,k));
         } else if (Vequipot > V_BAS(j,k+1)) {
            do {
               k++;
            } while (Vequipot > V_BAS(j,k+1));
         }
         nouvX = pasEnPixels*(k+(Vequipot-V_BAS(j,k))/(V_BAS(j,k+1)-V_BAS(j,k)));
         Ligne (((double)(RESOLUTION_X-1))/2+ancX, ((double)(RESOLUTION_Y-1))/2-(j+TAILLE_HAUT+2)*pasEnPixels, ((double)(RESOLUTION_X-1))/2+nouvX, ((double)(RESOLUTION_Y-1))/2-(j+TAILLE_HAUT+1)*pasEnPixels, couleur1);
         Ligne (((double)(RESOLUTION_X-1))/2+ancX, ((double)(RESOLUTION_Y-1))/2+(j+TAILLE_HAUT+2)*pasEnPixels, ((double)(RESOLUTION_X-1))/2+nouvX, ((double)(RESOLUTION_Y-1))/2+(j+TAILLE_HAUT+1)*pasEnPixels, couleur1);
         Ligne (((double)(RESOLUTION_X-1))/2-ancX, ((double)(RESOLUTION_Y-1))/2-(j+TAILLE_HAUT+2)*pasEnPixels, ((double)(RESOLUTION_X-1))/2-nouvX, ((double)(RESOLUTION_Y-1))/2-(j+TAILLE_HAUT+1)*pasEnPixels, couleur2);
         Ligne (((double)(RESOLUTION_X-1))/2-ancX, ((double)(RESOLUTION_Y-1))/2+(j+TAILLE_HAUT+2)*pasEnPixels, ((double)(RESOLUTION_X-1))/2-nouvX, ((double)(RESOLUTION_Y-1))/2+(j+TAILLE_HAUT+1)*pasEnPixels, couleur2);
         ancX = nouvX;
      }
      for (j = TAILLE_HAUT; j >= 0; j--) {
         if (Vequipot < V_HAUT(j,k)) {
            do {
               k--;
            } while (Vequipot < V_HAUT(j,k));
         } else if (Vequipot > V_HAUT(j,k+1)) {
            do {
               k++;
            } while (Vequipot > V_HAUT(j,k+1));
         }
         nouvX = pasEnPixels*(k+(Vequipot-V_HAUT(j,k))/(V_HAUT(j,k+1)-V_HAUT(j,k)));
         Ligne (((double)(RESOLUTION_X-1))/2+ancX, ((double)(RESOLUTION_Y-1))/2-(j+1)*pasEnPixels, ((double)(RESOLUTION_X-1))/2+nouvX, ((double)(RESOLUTION_Y-1))/2-j*pasEnPixels, couleur1);
         Ligne (((double)(RESOLUTION_X-1))/2+ancX, ((double)(RESOLUTION_Y-1))/2+(j+1)*pasEnPixels, ((double)(RESOLUTION_X-1))/2+nouvX, ((double)(RESOLUTION_Y-1))/2+j*pasEnPixels, couleur1);
         Ligne (((double)(RESOLUTION_X-1))/2-ancX, ((double)(RESOLUTION_Y-1))/2-(j+1)*pasEnPixels, ((double)(RESOLUTION_X-1))/2-nouvX, ((double)(RESOLUTION_Y-1))/2-j*pasEnPixels, couleur2);
         Ligne (((double)(RESOLUTION_X-1))/2-ancX, ((double)(RESOLUTION_Y-1))/2+(j+1)*pasEnPixels, ((double)(RESOLUTION_X-1))/2-nouvX, ((double)(RESOLUTION_Y-1))/2+j*pasEnPixels, couleur2);
         ancX = nouvX;
      }
   }

   return;
}

/* Dans la fonction qui suit la distinction entre les deux parties du tableau
   n'est plus n�cessaire : on reste en haut ! */
#define V(i,j) V_HAUT(i,j)

void TrajectoireElectron (double x, double xPrime, double yPrime)
{
#if (TRACE_GRAPHE_FOCAL != 1)
fprintf (stdout, "Trajectoire d'electron:\n");
#endif
   /* On v�rifie tout d'abord que l'�lectron rentre bien dans la lentille. */
   int i = (int)floor(x/PAS_EN_METRES);
   if ((i < -TAILLE_HAUT) || (i > TAILLE_HAUT+1)) {
      fprintf (stdout, "   Echec dans le calcul de trajectoire: L'electron ne commence pas dans la lentille.\n");
      return;
   }
   
   // D�claration des variables
   int j = -TAILLE_GAUCHE-TAILLE_DROITE, k, nombreIterations, maxIterations = 1;
   double yMoinsL = -PAS_EN_METRES, a, bPlusL, c, t, xMoinsL, cPlusL, V1, V2, V3, V4,
#if (TRACE_GRAPHE_FOCAL != 1) // Cette incursion emp�chera le compilateur de se plaindre.
      ancOrd = ((double)(RESOLUTION_Y-1))/2+x*pasEnPixels/PAS_EN_METRES,
      ancAbs = origineX, nouvOrd, nouvAbs,
#endif
      coeff1, coeff2, coeff3, coeff4, cosTemp, sinTemp, chTemp, shTemp;

   
   /* On initialise les variables pour la premi�re case. */
   x -= i*PAS_EN_METRES;
   if (i >= 0) {
      V1 = V(i,TAILLE_GAUCHE+TAILLE_DROITE);
      V2 = V(i+1,TAILLE_GAUCHE+TAILLE_DROITE);
      V3 = V(i+1,TAILLE_GAUCHE+TAILLE_DROITE-1);
      V4 = V(i,TAILLE_GAUCHE+TAILLE_DROITE-1);
   } else {
      V1 = V(-i,TAILLE_GAUCHE+TAILLE_DROITE);
      V2 = V(-i-1,TAILLE_GAUCHE+TAILLE_DROITE);
      V3 = V(-i-1,TAILLE_GAUCHE+TAILLE_DROITE-1);
      V4 = V(-i,TAILLE_GAUCHE+TAILLE_DROITE-1);
   }
   
   /* On lance le calcul de trajectoire sur la premi�re case, il
      s'auto-entretiendra pour les autres cases. */
   for (k = 1; k <= LIMITE_ITERATIONS_TRAJECTOIRE; k++) {
      a = Q_SUR_M_SUR_L2*(V3+V1-V2-V4);
      bPlusL = PAS_EN_METRES*(V3-V4)/(V3+V1-V2-V4);
      c = PAS_EN_METRES*(V4-V1)/(V3+V1-V2-V4);
      cPlusL = c+PAS_EN_METRES;
      coeff1 = (x+yMoinsL+bPlusL+c)/2;
      coeff2 = (x-yMoinsL-bPlusL+c)/2;
      
      /* Ce test permet de s�parer les calculs de x, yMoinsL, xPrime et
         yPrime, qui sont diff�rents selon le signe de a. */
      if (a >= 0) {
         a = sqrt(a);
         coeff3 = (xPrime+yPrime)/2/a;
         coeff4 = (xPrime-yPrime)/2/a;
         
         /* On proc�de � la premi�re annulation : celle de yMoinsL. */
         t = 0.0;
nombreIterations = 0;
         do {
if (++nombreIterations > LIMITE_ITERATIONS_NEWTON) {
   fprintf (stdout, "   Echec dans le calcul de trajectoire: La limite du nombre d'iterations de la methode de Newton est depassee.\n");
   return;
}
            t -= yMoinsL/yPrime;
            cosTemp = cos(a*t); sinTemp = sin(a*t);
            chTemp = cosh(a*t); shTemp = sinh(a*t);
            yMoinsL = coeff1*cosTemp+coeff3*sinTemp-coeff2*chTemp-coeff4*shTemp-bPlusL;
            yPrime = a*(-coeff1*sinTemp+coeff3*cosTemp-coeff2*shTemp-coeff4*chTemp);
         } while (fabs(yMoinsL) > VALEUR_ANNULATION);
if (nombreIterations > maxIterations) maxIterations = nombreIterations;
         x = coeff1*cosTemp+coeff3*sinTemp+coeff2*chTemp+coeff4*shTemp-c;
         xPrime = a*(-coeff1*sinTemp+coeff3*cosTemp+coeff2*shTemp+coeff4*chTemp);
         
         /* Ce test permet de d�terminer la prochaine case dans laquelle ira
            l'�lectron. */
         if (x < 0.0) {
            /* On ira � gauche, donc on annule x. */
nombreIterations = 0;
            do {
if (++nombreIterations > LIMITE_ITERATIONS_NEWTON) {
   fprintf (stdout, "   Echec dans le calcul de trajectoire: La limite du nombre d'iterations de la methode de Newton est depassee.\n");
   return;
}
               t -= x/xPrime;
               cosTemp = cos(a*t); sinTemp = sin(a*t);
               chTemp = cosh(a*t); shTemp = sinh(a*t);
               x = coeff1*cosTemp+coeff3*sinTemp+coeff2*chTemp+coeff4*shTemp-c;
               xPrime = a*(-coeff1*sinTemp+coeff3*cosTemp+coeff2*shTemp+coeff4*chTemp);
            } while (fabs(x) > VALEUR_ANNULATION);
if (nombreIterations > maxIterations) maxIterations = nombreIterations;
            yMoinsL = coeff1*cosTemp+coeff3*sinTemp-coeff2*chTemp-coeff4*shTemp-bPlusL;
#if (TRACE_GRAPHE_FOCAL != 1)
            nouvAbs = ((double)(RESOLUTION_X-1))/2+((double)(j+1)+yMoinsL/PAS_EN_METRES)*pasEnPixels;
            nouvOrd = ((double)(RESOLUTION_Y-1))/2+((double)i+x/PAS_EN_METRES)*pasEnPixels;
            Ligne (ancAbs, ancOrd, nouvAbs, nouvOrd, NOIR);
            if (i <= -TAILLE_HAUT) {
               break;
            }
            ancAbs = nouvAbs;
            ancOrd = nouvOrd;
#else
            if (i <= -TAILLE_HAUT) {
               return;
            }
#endif
            yPrime = a*(-coeff1*sinTemp+coeff3*cosTemp-coeff2*shTemp-coeff4*chTemp);
            
            /* On proc�de � l'initialisation des variables pour la prochaine
               case. */
            x = x+PAS_EN_METRES; i--;
            V2 = V1; V3 = V4;
            if (i >= 0) {
               if (j >= 0) {
                  V1 = -V(i,j); V4 = -V(i,j+1);
               } else {
                  V1 = V(i,-j); V4 = V(i,-j-1);
               }
            } else {
               if (j >= 0) {
                  V1 = -V(-i,j); V4 = -V(-i,j+1);
               } else {
                  V1 = V(-i,-j); V4 = V(-i,-j-1);
               }
            }
            continue; // Pourquoi aller au bout de la boucle, c'est fini !
         } else if (x > PAS_EN_METRES) {
            /* On ira � droite, donc on annule xMoinsL. */
            xMoinsL = x-PAS_EN_METRES;
            i++; // Cette instruction est plac�e ici pour optimiser la suite.
nombreIterations = 0;
            do {
if (++nombreIterations > LIMITE_ITERATIONS_NEWTON) {
   fprintf (stdout, "   Echec dans le calcul de trajectoire: La limite du nombre d'iterations de la methode de Newton est depassee.\n");
   return;
}
               t -= xMoinsL/xPrime;
               cosTemp = cos(a*t); sinTemp = sin(a*t);
               chTemp = cosh(a*t); shTemp = sinh(a*t);
               xMoinsL = coeff1*cosTemp+coeff3*sinTemp+coeff2*chTemp+coeff4*shTemp-cPlusL;
               xPrime = a*(-coeff1*sinTemp+coeff3*cosTemp+coeff2*shTemp+coeff4*chTemp);
            } while (fabs(xMoinsL) > VALEUR_ANNULATION);
if (nombreIterations > maxIterations) maxIterations = nombreIterations;
            yMoinsL = coeff1*cosTemp+coeff3*sinTemp-coeff2*chTemp-coeff4*shTemp-bPlusL;
#if (TRACE_GRAPHE_FOCAL != 1)
            nouvAbs = ((double)(RESOLUTION_X-1))/2+((double)(j+1)+yMoinsL/PAS_EN_METRES)*pasEnPixels;
            nouvOrd = ((double)(RESOLUTION_Y-1))/2+((double)i+xMoinsL/PAS_EN_METRES)*pasEnPixels;
            Ligne (ancAbs, ancOrd, nouvAbs, nouvOrd, NOIR);
            /* Attention � la diff�rence avec le code algorithmique, i est ici
                d�j� incr�ment�. */
            if (i >= TAILLE_HAUT) {
               break;
            }
            ancAbs = nouvAbs;
            ancOrd = nouvOrd;
#else
            if (i >= TAILLE_HAUT) {
               return;
            }
#endif
            yPrime = a*(-coeff1*sinTemp+coeff3*cosTemp-coeff2*shTemp-coeff4*chTemp);
            
            /* On initialise les variables pour la prochaine case. */
            x = xMoinsL;
            V1 = V2; V4 = V3;
            if (i >= 0) {
               if (j >= 0) {
                  V2 = -V(i+1,j); V3 = -V(i+1,j+1);
               } else {
                  V2 = V(i+1,-j); V3 = V(i+1,-j-1);
               }
            } else {
               if (j >= 0) {
                  V2 = -V(-i-1,j); V3 = -V(-i-1,j+1);
               } else {
                  V2 = V(-i-1,-j); V3 = V(-i-1,-j-1);
               }
            }
            continue;
         } else {
            /* On va tout droit ! Trac� de droite et v�rification d'arriv�e... */
            j++;
#if (TRACE_GRAPHE_FOCAL != 1)
            nouvAbs = ((double)(RESOLUTION_X-1))/2+((double)j+yMoinsL/PAS_EN_METRES)*pasEnPixels;
            nouvOrd = ((double)(RESOLUTION_Y-1))/2+((double)i+x/PAS_EN_METRES)*pasEnPixels;
            Ligne (ancAbs, ancOrd, nouvAbs, nouvOrd, NOIR);
            /* Attention � la diff�rence avec le code algorithmique, j est ici
                d�j� incr�ment�. */
            if (j >= TAILLE_GAUCHE+TAILLE_DROITE) {
               break;
            }
            ancAbs = nouvAbs;
            ancOrd = nouvOrd;
#else
            if (j >= TAILLE_GAUCHE+TAILLE_DROITE/2) {
               if ((i >= -3) && (i <= 2)) {
                  densitesElectrons[ENTREES_GRAPHE_PAR_CASE*(i+3)+((x<PAS_EN_METRES)?((int)(x/PAS_EN_METRES*ENTREES_GRAPHE_PAR_CASE)):(ENTREES_GRAPHE_PAR_CASE-1))]++;
               } else {
                  electronsNonComptes++;
               }
               electronsArrives++;
               return;
            }
#endif
            
            /* L'initialisation pour la prochaine case. */
            yMoinsL -= PAS_EN_METRES;
            V2 = V3; V1 = V4;
            if (i >= 0) {
               if (j >= 0) {
                  V4 = -V(i,j+1); V3 = -V(i+1,j+1);
               } else {
                  V4 = V(i,-j-1); V3 = V(i+1,-j-1);
               }
            } else {
               if (j >= 0) {
                  V4 = -V(-i,j+1); V3 = -V(-i-1,j+1);
               } else {
                  V4 = V(-i,-j-1); V3 = V(-i-1,-j-1);
               }
            }
            continue;
         }
      } else {
         a = sqrt(-a);
         coeff3 = (xPrime+yPrime)/2/a;
         coeff4 = (xPrime-yPrime)/2/a;
         
         /* On proc�de � la premi�re annulation : celle de yMoinsL. */
         t = 0.0;
nombreIterations = 0;
         do {
if (++nombreIterations > LIMITE_ITERATIONS_NEWTON) {
   fprintf (stdout, "   Echec dans le calcul de trajectoire: La limite du nombre d'iterations de la methode de Newton est depassee.\n");
   return;
}
            t -= yMoinsL/yPrime;
            cosTemp = cos(a*t); sinTemp = sin(a*t);
            chTemp = cosh(a*t); shTemp = sinh(a*t);
            yMoinsL = coeff1*chTemp+coeff3*shTemp-coeff2*cosTemp-coeff4*sinTemp-bPlusL;
            yPrime = a*(coeff1*shTemp+coeff3*chTemp+coeff2*sinTemp-coeff4*cosTemp);
         } while (fabs(yMoinsL) > VALEUR_ANNULATION);
if (nombreIterations > maxIterations) maxIterations = nombreIterations;
         x = coeff1*chTemp+coeff3*shTemp+coeff2*cosTemp+coeff4*sinTemp-c;
         xPrime = a*(coeff1*shTemp+coeff3*chTemp-coeff2*sinTemp+coeff4*cosTemp);
         
         /* Ce test permet de d�terminer la prochaine case dans laquelle ira
            l'�lectron. */
         if (x < 0.0) {
            /* On ira � gauche, donc on annule x. */
nombreIterations = 0;
            do {
if (++nombreIterations > LIMITE_ITERATIONS_NEWTON) {
   fprintf (stdout, "   Echec dans le calcul de trajectoire: La limite du nombre d'iterations de la methode de Newton est depassee.\n");
   return;
}
               t -= x/xPrime;
               cosTemp = cos(a*t); sinTemp = sin(a*t);
               chTemp = cosh(a*t); shTemp = sinh(a*t);
               x = coeff1*chTemp+coeff3*shTemp+coeff2*cosTemp+coeff4*sinTemp-c;
               xPrime = a*(coeff1*shTemp+coeff3*chTemp-coeff2*sinTemp+coeff4*cosTemp);
            } while (fabs(x) > VALEUR_ANNULATION);
if (nombreIterations > maxIterations) maxIterations = nombreIterations;
            yMoinsL = coeff1*chTemp+coeff3*shTemp-coeff2*cosTemp-coeff4*sinTemp-bPlusL;
#if (TRACE_GRAPHE_FOCAL != 1)
            nouvAbs = ((double)(RESOLUTION_X-1))/2+((double)(j+1)+yMoinsL/PAS_EN_METRES)*pasEnPixels;
            nouvOrd = ((double)(RESOLUTION_Y-1))/2+((double)i+x/PAS_EN_METRES)*pasEnPixels;
            Ligne (ancAbs, ancOrd, nouvAbs, nouvOrd, NOIR);
            if (i <= -TAILLE_HAUT) {
               break;
            }
            ancAbs = nouvAbs;
            ancOrd = nouvOrd;
#else
            if (i <= -TAILLE_HAUT) {
               return;
            }
#endif
            yPrime = a*(coeff1*shTemp+coeff3*chTemp+coeff2*sinTemp-coeff4*cosTemp);
            
            /* On proc�de � l'initialisation des variables pour la prochaine
               case. */
            x = x+PAS_EN_METRES; i--;
            V2 = V1; V3 = V4;
            if (i >= 0) {
               if (j >= 0) {
                  V1 = -V(i,j); V4 = -V(i,j+1);
               } else {
                  V1 = V(i,-j); V4 = V(i,-j-1);
               }
            } else {
               if (j >= 0) {
                  V1 = -V(-i,j); V4 = -V(-i,j+1);
               } else {
                  V1 = V(-i,-j); V4 = V(-i,-j-1);
               }
            }
            continue;
         } else if (x > PAS_EN_METRES) {
            /* On ira � droite, donc on annule xMoinsL. */
            xMoinsL = x-PAS_EN_METRES;
            i++;
nombreIterations = 0;
            do {
if (++nombreIterations > LIMITE_ITERATIONS_NEWTON) {
   fprintf (stdout, "   Echec dans le calcul de trajectoire: La limite du nombre d'iterations de la methode de Newton est depassee.\n");
   return;
}
               t -= xMoinsL/xPrime;
               cosTemp = cos(a*t); sinTemp = sin(a*t);
               chTemp = cosh(a*t); shTemp = sinh(a*t);
               xMoinsL = coeff1*chTemp+coeff3*shTemp+coeff2*cosTemp+coeff4*sinTemp-cPlusL;
               xPrime = a*(coeff1*shTemp+coeff3*chTemp-coeff2*sinTemp+coeff4*cosTemp);
            } while (fabs(xMoinsL) > VALEUR_ANNULATION);
if (nombreIterations > maxIterations) maxIterations = nombreIterations;
            yMoinsL = coeff1*chTemp+coeff3*shTemp-coeff2*cosTemp-coeff4*sinTemp-bPlusL;
#if (TRACE_GRAPHE_FOCAL != 1)
            nouvAbs = ((double)(RESOLUTION_X-1))/2+((double)(j+1)+yMoinsL/PAS_EN_METRES)*pasEnPixels;
            nouvOrd = ((double)(RESOLUTION_Y-1))/2+((double)i+xMoinsL/PAS_EN_METRES)*pasEnPixels;
            Ligne (ancAbs, ancOrd, nouvAbs, nouvOrd, NOIR);
            /* Attention � la diff�rence avec le code algorithmique, i est ici
                d�j� incr�ment�. */
            if (i >= TAILLE_HAUT) {
               break;
            }
            ancAbs = nouvAbs;
            ancOrd = nouvOrd;
#else
            if (i >= TAILLE_HAUT) {
               return;
            }
#endif
            yPrime = a*(coeff1*shTemp+coeff3*chTemp+coeff2*sinTemp-coeff4*cosTemp);
            
            /* On initialise les variables pour la prochaine case. */
            x = xMoinsL;
            V1 = V2; V4 = V3;
            if (i >= 0) {
               if (j >= 0) {
                  V2 = -V(i+1,j); V3 = -V(i+1,j+1);
               } else {
                  V2 = V(i+1,-j); V3 = V(i+1,-j-1);
               }
            } else {
               if (j >= 0) {
                  V2 = -V(-i-1,j); V3 = -V(-i-1,j+1);
               } else {
                  V2 = V(-i-1,-j); V3 = V(-i-1,-j-1);
               }
            }
            continue;
         } else {
            /* On va tout droit ! Tra�ons la droite et v�rifions l'arriv�e... */
            j++;
#if (TRACE_GRAPHE_FOCAL != 1)
            nouvAbs = ((double)(RESOLUTION_X-1))/2+((double)j+yMoinsL/PAS_EN_METRES)*pasEnPixels;
            nouvOrd = ((double)(RESOLUTION_Y-1))/2+((double)i+x/PAS_EN_METRES)*pasEnPixels;
            Ligne (ancAbs, ancOrd, nouvAbs, nouvOrd, NOIR);
            /* Attention � la diff�rence avec le code algorithmique, j est ici
               d�j� incr�ment�. */
            if (j >= TAILLE_GAUCHE+TAILLE_DROITE) {
               break;
            }
            ancAbs = nouvAbs;
            ancOrd = nouvOrd;
#else
            if (j >= TAILLE_GAUCHE+TAILLE_DROITE/2) {
               if ((i >= -3) && (i <= 2)) {
                  densitesElectrons[ENTREES_GRAPHE_PAR_CASE*(i+3)+((x<PAS_EN_METRES)?((int)(x/PAS_EN_METRES*ENTREES_GRAPHE_PAR_CASE)):(ENTREES_GRAPHE_PAR_CASE-1))]++;
               } else {
                  electronsNonComptes++;
               }
               electronsArrives++;
               return;
            }
#endif
            
            /* On initialise la prochaine case. */
            yMoinsL -= PAS_EN_METRES;
            V2 = V3; V1 = V4;
            if (i >= 0) {
               if (j >= 0) {
                  V4 = -V(i,j+1); V3 = -V(i+1,j+1);
               } else {
                  V4 = V(i,-j-1); V3 = V(i+1,-j-1);
               }
            } else {
               if (j >= 0) {
                  V4 = -V(-i,j+1); V3 = -V(-i-1,j+1);
               } else {
                  V4 = V(-i,-j-1); V3 = V(-i-1,-j-1);
               }
            }
         }
      }
      
      /* Cette partie de la boucle peut �tre utilis�e pour afficher des
         informations pour chaque case. Il suffit de retirer les instructions
         continue dans la boucle. */
   }
fprintf (stdout, "   casesParcourues=%d\n   maxIterationsNewton=%d\n", k, maxIterations);
   
   return;
}

int TraceGrapheFocal (void)
{
#if (TRACE_GRAPHE_FOCAL == 1)
   int i = TraceGraphe (densitesElectrons, ENTREES_GRAPHE_PAR_CASE*6);
fprintf (stdout, "   electronsArrives=%d\n   electronsNonComptes=%d\n",electronsArrives,electronsNonComptes);
   return (i);
#else
   Ligne (((double)(RESOLUTION_X-1))/2+(TAILLE_GAUCHE+TAILLE_DROITE/2)*pasEnPixels,((double)(RESOLUTION_Y-1))/2-3*pasEnPixels,((double)(RESOLUTION_X-1))/2+(TAILLE_GAUCHE+TAILLE_DROITE/2)*pasEnPixels,((double)(RESOLUTION_Y-1))/2+3*pasEnPixels,
      NOIR);//SDL_MapRGB(SDL_GetVideoSurface()->format, 0, 0, 255));
   return (0);
#endif
}
