/*

Fichier : Affichage.c

Auteur : Thibault Raffaillac <thibaultraffaillac@yahoo.fr>
Cr�� le : 07/01/08
Derni�re modification le : 20/05/08

Ce fichier contient les fonctions permettant tout affichage dans le cadre de mon
TIPE de 2008 (2e ann�e de maths sp�).
Ces fonctions comprennent la cr�ation d'une fen�tre d'affichage, le trac� de
segments et de points, et la sauvegarde de l'image cr��e.

*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include "Affichage.h"

#define TAILLE_PIXEL 86 // L'�quivalent d'un pixel pour une pr�cision de distance de 1/64.
#define RESOLUTION_GRAPHE_X 800
#define RESOLUTION_GRAPHE_Y 400
#define VALEUR_MAX_AFFICHEE 90

/* Le programme ne peut pas �tre compil� sur une machine little endian. */
#define RMASK 0x000000ff
#define GMASK 0x0000ff00
#define BMASK 0x00ff0000
#define AMASK 0xff000000

static Uint32 cadreLigneTbl[RESOLUTION_X*RESOLUTION_Y];

int InitAffichage (void)
{
   /* Chargement de la SDL. */
   if (SDL_Init (SDL_INIT_VIDEO|SDL_INIT_TIMER) != 0) {
      fprintf (stderr, "Echec dans l'initialisation de la SDL: %s\n", SDL_GetError ());
      return (-1);
   }

   /* On cr�e la zone d'affichage � la taille voulue. */
   SDL_Surface *surface = SDL_SetVideoMode (RESOLUTION_X, RESOLUTION_Y, 32, SDL_SWSURFACE);
   if (surface == NULL) {
      fprintf (stderr, "Impossible de charger le mode video: %s\n", SDL_GetError());
      SDL_Quit ();
      return (-1);
   }
   SDL_WM_SetCaption ("Lentille Electrostatique", NULL);

   /* On colorie la surface d'affichage en blanc. */
   if (SDL_FillRect (surface, NULL, SDL_MapRGB (surface->format, 255, 255, 255)) != 0) {
      fprintf (stderr, "Echec lors du coloriage de la surface: %s\n", SDL_GetError());
      SDL_Quit ();
      return (-1);
   }
   SDL_UpdateRect (surface, 0, 0, 0, 0);

   /* On indique tous les �v�nements qu'on souhaite ignorer. */
   SDL_EventState (SDL_ACTIVEEVENT, SDL_IGNORE);
   SDL_EventState (SDL_KEYUP, SDL_IGNORE);
   SDL_EventState (SDL_MOUSEMOTION, SDL_IGNORE);
   SDL_EventState (SDL_MOUSEBUTTONDOWN, SDL_IGNORE);
   SDL_EventState (SDL_MOUSEBUTTONUP, SDL_IGNORE);
   SDL_EventState (SDL_JOYAXISMOTION, SDL_IGNORE);
   SDL_EventState (SDL_JOYBALLMOTION, SDL_IGNORE);
   SDL_EventState (SDL_JOYHATMOTION, SDL_IGNORE);
   SDL_EventState (SDL_JOYBUTTONDOWN, SDL_IGNORE);
   SDL_EventState (SDL_JOYBUTTONUP, SDL_IGNORE);
   SDL_EventState (SDL_SYSWMEVENT, SDL_IGNORE);
   SDL_EventState (SDL_VIDEORESIZE, SDL_IGNORE);
   SDL_EventState (SDL_VIDEOEXPOSE, SDL_IGNORE);
   SDL_EventState (SDL_USEREVENT, SDL_IGNORE);

   return (0);
}

int LigneInterne (SDL_Surface *surface, double x1, double y1, double x2, double y2, const Uint32 couleur)
{
   /* On v�rifie tout d'abord que l'affichage est bien en 32 bits par pixel. */
   if (surface->format->BytesPerPixel != 4) {
      SDL_SetError ("L'affichage n'est pas en 32 bits.");
      return (-1);
   }

   // D�claration des variables
   int xe1, xe2, ye1, ye2, dxe, dye, xi, yi, xf, yf, x, y, xe, ye;
   unsigned int racine, arronRacine, distance;
   double dtemp;
   SDL_Surface *cadreLigne = NULL;
   Uint32 *pointeur;
   SDL_Rect coordCadre;

   /* On s�pare d'abord les cas de pente douce et forte. */
   if (fabs(x2-x1) >= fabs(y2-y1)) {   // Pente douce.
      
      /* On place le premier point � gauche et on effectue les initialisations
         n�cessaires. */
      if (x1 > x2) {
         dtemp = x1; x1 = x2; x2 = dtemp;
         dtemp = y1; y1 = y2; y2 = dtemp;
      }
      xe1 = (int)nearbyint(x1*TAILLE_PIXEL); xe2 = (int)nearbyint(x2*TAILLE_PIXEL);
      ye1 = (int)nearbyint(y1*TAILLE_PIXEL); ye2 = (int)nearbyint(y2*TAILLE_PIXEL);
      dxe = xe2-xe1;
      if (dxe == 0) {
         Point (x1, y1, couleur);
         return (0);
      }
      dye = ye2-ye1;
      racine = (int)nearbyint(sqrt(dxe*dxe+dye*dye));
      arronRacine = (racine+1)/2;
      /* On n'utilise pas nearbyint ici car on a combin� addition (resp.
         soustraction) et arrondi en une unique op�ration. */
      xi = MAX(0, (int)(x1-0.5)); xf = MIN(surface->w, (int)(x2+1.5));
      if (ye2 > ye1) {
         yi = MAX(0, (int)(y1-0.5)); yf = MIN(surface->h, (int)(y2+1.5));
      } else {
         yi = MAX(0, (int)(y2-0.5)); yf = MIN(surface->h, (int)(y1+1.5));
      }
      cadreLigne = SDL_CreateRGBSurfaceFrom(&cadreLigneTbl, xf-xi, yf-yi, 32, (xf-xi)*4, RMASK, GMASK, BMASK, AMASK);
      pointeur = cadreLigne->pixels;

      /* On tente de verrouiller le cadre pour tracer dedans. */
      if (SDL_MUSTLOCK(cadreLigne) != 0) {
         if (SDL_LockSurface(cadreLigne) != 0) {
            SDL_SetError ("Impossible de verrouiller la surface de dessin.");
            SDL_FreeSurface (cadreLigne);
            return (-1);
         }
      }

      /* On trace la droite dans le cadre cr�� pour l'occasion. */
      for (y = yi; y < yf; y++) {
         ye = y*TAILLE_PIXEL;
         for (x = xi; x < xf; x++) {
            xe = x*TAILLE_PIXEL;
            distance = (abs(dye*(xe-xe1)+dxe*(ye1-ye))+arronRacine)/racine;
            if (((ye1-ye)*dye)/dxe > (xe-xe1)) {
               distance = MAX(distance, abs(dxe*(xe-xe1)+dye*(ye-ye1)));
            } else if (((ye2-ye)*dye)/dxe < (xe-xe2)) {
               distance = MIN(distance, abs(dxe*(xe-xe2)+dye*(ye-ye2)));
            }
            distance = MIN(63, distance); distance = ((63-distance)*255+32)/63;
            *pointeur = (couleur&0x00ffffff)|(distance<<24);
            pointeur++;
         }
      }
   } else { // Pente forte

      /* On place le premier point en haut et on effectue les initialisations
         n�cessaires. */
      if (y1 > y2) {
         dtemp = x1; x1 = x2; x2 = dtemp;
         dtemp = y1; y1 = y2; y2 = dtemp;
      }
      xe1 = (int)nearbyint(x1*TAILLE_PIXEL); xe2 = (int)nearbyint(x2*TAILLE_PIXEL);
      ye1 = (int)nearbyint(y1*TAILLE_PIXEL); ye2 = (int)nearbyint(y2*TAILLE_PIXEL);
      dye = ye2-ye1;
      if (dye == 0) {
         Point (x1, y1, couleur);
         return (0);
      }
      dxe = xe2-xe1;
      racine = (int)nearbyint(sqrt(dxe*dxe+dye*dye));
      arronRacine = (racine+1)/2;
      /* On n'utilise pas nearbyint ici car on a combin� addition (resp.
         soustraction) et arrondi en une unique op�ration. */
      if (xe2 > xe1) {
         xi = MAX(0, (int)(x1-0.5)); xf = MIN(surface->w, (int)(x2+1.5));
      } else {
         xi = MAX(0, (int)(x2-0.5)); xf = MIN(surface->w, (int)(x1+1.5));
      }
      yi = MAX(0, (int)(y1-0.5)); yf = MIN(surface->h, (int)(y2+1.5));
      cadreLigne = SDL_CreateRGBSurfaceFrom(&cadreLigneTbl, xf-xi, yf-yi, 32, (xf-xi)*4, RMASK, GMASK, BMASK, AMASK);
      pointeur = cadreLigne->pixels;

      /* On tente de verrouiller le cadre pour tracer dedans. */
      if (SDL_MUSTLOCK(cadreLigne) != 0) {
         if (SDL_LockSurface(cadreLigne) != 0) {
            SDL_SetError ("Impossible de verrouiller la surface de dessin.");
            SDL_FreeSurface (cadreLigne);
            return (-1);
         }
      }

      /* On trace la droite dans le cadre cr�� pour l'occasion. */
      for (y = yi; y < yf; y++) {
         ye = y*TAILLE_PIXEL;
         for (x = xi; x < xf; x++) {
            xe = x*TAILLE_PIXEL;
            distance = (abs(dye*(xe-xe1)+dxe*(ye1-ye))+arronRacine)/racine;
            if (((xe1-xe)*dxe)/dye > (ye-ye1)) {
               distance = MAX(distance, abs(dye*(ye-ye1)+dxe*(xe-xe1)));
            } else if (((xe2-xe)*dxe)/dye < (ye-ye2)) {
               distance = MIN(distance, abs(dye*(ye-ye2)+dxe*(xe-xe2)));
            }
            distance = MIN(63, distance); distance = ((63-distance)*255+32)/63;
            *pointeur = (couleur&0x00ffffff)|(distance<<24);
            pointeur++;
         }
      }
   }

   /* On d�verrouille le cadre s'il l'�tait. */
   if (SDL_MUSTLOCK(cadreLigne) != 0) {
      SDL_UnlockSurface (cadreLigne);
   }

   /* Enfin, on place le cadre sur la surface, avec un m�lange alpha. */
   coordCadre.x = xi; coordCadre.y = yi;
   if (SDL_BlitSurface (cadreLigne, NULL, surface, &coordCadre) != 0) {
      SDL_SetError ("Echec du blitting de la ligne.");
      SDL_FreeSurface (cadreLigne);
      return (-1);
   }
   SDL_FreeSurface (cadreLigne);
   return (0);
}

int Ligne (double x1, double y1, double x2, double y2, const Uint32 couleur)
{
   return (LigneInterne(SDL_GetVideoSurface(),x1,y1,x2,y2,couleur));
}

int Point (const double x, const double y, const Uint32 couleur)
{
   /* On v�rifie tout d'abord que l'affichage est bien en 32 bits par pixel. */
   SDL_Surface *surface = SDL_GetVideoSurface();
   if (surface->format->BytesPerPixel != 4) {
      SDL_SetError ("L'affichage n'est pas en 32 bits.");
      return (-1);
   }

   /* On tente de verrouiller le cadre pour tracer dedans. */
   if (SDL_MUSTLOCK(surface) != 0) {
      if (SDL_LockSurface(surface) != 0) {
         SDL_SetError ("Impossible de verrouiller la surface de dessin.");
         return (-1);
      }
   }

   // D�claration des variables
   int xe = (int)nearbyint(x*16), ye = (int)nearbyint(y*16), xi = xe/16, yi = ye/16;
   unsigned int itemp, rouge, vert, bleu, dxe = xe-xi*16, dye = ye-yi*16,
      compo2 = 16711680-(couleur&0x00ff0000), compo3 = 65280-(couleur&0x0000ff00),
      compo4 = 255-(couleur&0x000000ff);
   Uint32 *pointeur = surface->pixels + xi*4 + yi*surface->pitch;

   /* On commence par le point en haut � gauche. */
   itemp = (16-dxe)*(16-dye);
   bleu = 255-(compo2*itemp+8388608)/16777216;
   vert = 255-(compo3*itemp+32768)/65536;
   rouge = 255-(compo4*itemp+128)/256;
   *pointeur = (rouge<<16)|(vert<<8)|bleu;

   /* Puis le point en haut � droite. */
   pointeur++;
   itemp = dxe*(16-dye);
   if (itemp != 0) {
      bleu = 255-(compo2*itemp+8388608)/16777216;
      vert = 255-(compo3*itemp+32768)/65536;
      rouge = 255-(compo4*itemp+128)/256;
      *pointeur = (rouge<<16)|(vert<<8)|bleu;
   }

   /* Puis le point en bas � droite. */
   pointeur += surface->w;
   itemp = dxe*dye;
   if (itemp != 0) {
      bleu = 255-(compo2*itemp+8388608)/16777216;
      vert = 255-(compo3*itemp+32768)/65536;
      rouge = 255-(compo4*itemp+128)/256;
      *pointeur = (rouge<<16)|(vert<<8)|bleu;
   }

   /* Enfin le point en bas � gauche. */
   pointeur--;
   itemp = (16-dxe)*dye;
   if (itemp != 0) {
      bleu = 255-(compo2*itemp+8388608)/16777216;
      vert = 255-(compo3*itemp+32768)/65536;
      rouge = 255-(compo4*itemp+128)/256;
      *pointeur = (rouge<<16)|(vert<<8)|bleu;
   }

   /* On d�verrouille le cadre s'il l'�tait. */
   if (SDL_MUSTLOCK(surface) != 0) {
      SDL_UnlockSurface (surface);
   }

   /* Et c'est fini ! */
   return (0);
}

int PriseImage (void)
{
   // D�claration des variables
   SDL_Surface *surface = SDL_GetVideoSurface();
   char nomFichier[64];
   time_t nowSec = time (NULL);
   struct tm *now = localtime (&nowSec);
   
   /* On d�termine le nom du ficher en y indiquant la date de cr�ation. */
   sprintf (nomFichier, "lentille_electrostatique_%02d-%02d-%02d_%dh%02dm%02ds.bmp",
      now->tm_mday, now->tm_mon + 1, now->tm_year % 100, now->tm_hour,
      now->tm_min, now->tm_sec);
   
   /* Puis on enregistre. */
   return (SDL_SaveBMP(surface, nomFichier));
}

int TraceGraphe (int tableau[], int tailleTableau)
{
   // D�claration des variables
   SDL_Surface *surface = SDL_CreateRGBSurface(SDL_SWSURFACE,
      RESOLUTION_GRAPHE_X, RESOLUTION_GRAPHE_Y, 32, RMASK, GMASK, BMASK, AMASK);
   int i, valeurMax;
   Uint32 gris = SDL_MapRGB (surface->format, 192, 192, 192);
   double ancOrd, ancAbs, nouvOrd, nouvAbs;
   char nomFichier[64];
   time_t nowSec = time (NULL);
   struct tm *now = localtime (&nowSec);
   
   /* On colorie la surface de dessin en blanc. */
   if (SDL_FillRect (surface, NULL, SDL_MapRGB (surface->format, 255, 255, 255)) != 0) {
      fprintf (stderr, "Echec lors du coloriage de la surface: %s\n", SDL_GetError());
      SDL_FreeSurface (surface);
      return (-1);
   }
   
   /* On trace ensuite les axes. */
   LigneInterne (surface,0.0,(double)(RESOLUTION_GRAPHE_Y-1),((double)(RESOLUTION_GRAPHE_X-1))/2,(double)(RESOLUTION_GRAPHE_Y-1),gris);
   LigneInterne (surface,((double)(RESOLUTION_GRAPHE_X-1))/2,(double)(RESOLUTION_GRAPHE_Y-1),(double)(RESOLUTION_GRAPHE_X-1),(double)(RESOLUTION_GRAPHE_Y-1),gris);
   for (i = 0; i <= 6; i++) {
      nouvAbs = ((double)(RESOLUTION_GRAPHE_X-1))*((double)i)/6;
      LigneInterne (surface,nouvAbs,0.0,nouvAbs,(double)(RESOLUTION_GRAPHE_Y-1),gris);
   }
   
   /* On trace le graphe. */
   valeurMax = tableau[0];
   ancOrd = (((double)(VALEUR_MAX_AFFICHEE-tableau[0]))/VALEUR_MAX_AFFICHEE)*((double)(RESOLUTION_GRAPHE_Y-1));
   if (ancOrd < 0.0) {
      ancOrd = 0.0;
   }
   ancAbs = ((double)(RESOLUTION_GRAPHE_X-1))/2/tailleTableau;
   for (i = 1; i < tailleTableau; i++) {
      if (tableau[i] > valeurMax) {
         valeurMax = tableau[i];
      }
      nouvOrd = (((double)(VALEUR_MAX_AFFICHEE-tableau[i]))/VALEUR_MAX_AFFICHEE)*((double)(RESOLUTION_GRAPHE_Y-1));
      if (nouvOrd < 0.0) {
         nouvOrd = 0.0;
      }
      nouvAbs = (((double)i+0.5)/tailleTableau)*((double)(RESOLUTION_GRAPHE_X-1));
      LigneInterne (surface,ancAbs,ancOrd,nouvAbs,nouvOrd,NOIR);
      ancAbs = nouvAbs;
      ancOrd = nouvOrd;
   }
fprintf (stdout, "Trace du graphe:\n   valeurMax=%d\n", valeurMax);

   /* On d�termine le nom du ficher en y indiquant la date de cr�ation. */
   sprintf (nomFichier, "graphe_focal_%02d-%02d-%02d_%dh%02dm%02ds.bmp",
      now->tm_mday, now->tm_mon + 1, now->tm_year % 100, now->tm_hour,
      now->tm_min, now->tm_sec);
   
   /* Enfin on enregistre. */
   i = SDL_SaveBMP(surface, nomFichier);
   SDL_FreeSurface (surface);
   return (i);
}

Uint32 Nuance (int intensite)
{
   return (NOIR);
   //return (intensite|((255-intensite)<<16));
}
