/*

Fichier : main.c

Auteur : Thibault Raffaillac <thibaultraffaillac@yahoo.fr>
Cr�� le : 08/01/08
Derni�re modification le : 20/05/08

Ceci est le fichier contenant le code principal qui appelle les fonctions
n�cessaires dans le cadre de mon TIPE de 2008 (2e ann�e de maths sp�).

*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <SDL.h>
#include "Affichage.h"
#include "Coeur.h"

int main (int argc, char *argv[])
{
   // D�claration des variables
   double x, angle, vitesse;
   SDL_Event event;
   
	/* On initialise d'abord l'environnement. */
	if (InitAffichage() == -1) {
	   return (1);
   }
   InitCoeur ();
	
	/* On appelle les fonctions �tudi�es, dans l'ordre. */
	DessinLentille ();
	InitialisationPotentiels ();
	CalculPotentiels ();
	DessinPotentiels ();
	DessinEquipotentielles ();
	vitesse = 20.4;
	angle = 0.0;
	for (x = -11.2; x < 12.0; x += 3.2) {
	   TrajectoireElectron (x, -vitesse*sin(angle), vitesse*cos(angle));
	}
	TraceGrapheFocal ();
	PriseImage ();
	
	/* On affiche et on attend afin d'admirer le travail. */
   SDL_UpdateRect (SDL_GetVideoSurface(), 0, 0, 0, 0);
	SDL_WaitEvent (&event);
	
	/* On ferme proprement le programme. */
	SDL_Quit ();
   return (0);
}
