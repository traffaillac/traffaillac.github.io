/*

Le projet d'Oscillation d'un Fil en angles consiste � simuler les oscillations
d'un pendule de n masses identiques li�es entre elles par des tiges rigides, en
utilisant les angles qu'elles font avec la verticale dans un rep�re euclidien.

Le probl�me est ici r�solu en utilisant les outils suivants :
_coordonn�es angulaires
_�quations de Lagrange
_m�thode d'Euler

Auteur : Thibault Raffaillac <thibaultraffaillac@yahoo.fr>
Cr�� le : 29/04/07

*/

#ifndef TRAF_MAIN_H
#define TRAF_MAIN_H

//La constante qui influe sur le r�alisme de la simulation
#define G_SUR_L 98.1

//Cette macro �l�ve au carr� son argument.
#define CARRE(arg) ((arg)*(arg))

int main (int argc, char *argv[]);

/*Cette fonction initialise les param�tres des masses de telle fa�on que le fil
soit en position initiale � la verticale et immobile.*/
void initMasses (void);

/*Cette fonction calcule les coefficients du syst�me � r�soudre, et prend en
argument les tableaux des positions et des vitesses.*/
void calculCoeffs (double dtblpos[], double dtblvit[]);

/*Cette fonction r�alise l'approximation des vitesses � l'aide de la m�thode de
Runge-Kutta � l'ordre 4.

Elle renvoie -1 si un des syst�mes n'a pas pu �tre r�solu, en le signalant dans
stderr, 0 si tout s'est bien pass�, et 1 si une des vitesses est trop importante.*/
int approxRK4 (long numeroImage);

#endif
