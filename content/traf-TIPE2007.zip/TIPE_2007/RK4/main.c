/*

Le projet d'Oscillation d'un Fil en angles consiste � simuler les oscillations
d'un pendule de n masses identiques li�es entre elles par des tiges rigides, en
utilisant les angles qu'elles font avec la verticale dans un rep�re euclidien.

Le probl�me est ici r�solu en utilisant les outils suivants :
_coordonn�es angulaires
_�quations de Lagrange
_m�thode d'Euler

Auteur : Thibault Raffaillac <thibaultraffaillac@yahoo.fr>
Cr�� le : 29/04/07

*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <SDL/SDL.h>
#include "../AffichageMasses.h"
#include "../../FonctionsUtiles/UtilitesVariees.h"
#include "../../FonctionsUtiles/UtilitesMatrices.h"
#include "main.h"

#define TOLERANCE_ANNULATION 4   //Le test d'annulation d'un nombre en virgule flotante sera fait � 10^-4 pr�s.

#define NOMBRE_POINTS 20   //Le pendule est constitu� de 10 masses.

#define INTERVALLE_TEMPS_DEPART 0.001 //Pour l'approximation: une image est calcul�e toutes les 0.0001 secondes.

#define LIMITE_TOURS_PAR_SECONDE 100 //Le programme s'arr�te si la vitesse d'une masse exc�de 10 tours par seconde.

#define RALENTI 2 //Ce coefficient de ralenti permet de mieux profiter de l'animation.

#if (NOMBRE_POINTS != 1)
#define DERNIERE_MASSE 1   //La derni�re masse est 2 fois plus lourde que les autres.
#else
#define DERNIERE_MASSE 1   //Une masse seule n'a pas besoin d'�tre lest�e, donc le coefficient vaut 1.
#endif

//D�claration des variables internes 
static double positions[NOMBRE_POINTS];
static double vitesses[NOMBRE_POINTS];
static double systeme[NOMBRE_POINTS][NOMBRE_POINTS+1];
static double intervalleTemps;

int main (int argc, char *argv[])
{
   //D�claration des variables
   int i, j, k, continuer = 0, reinitialiser, attendre = 1;
   
   //Initialisation de l'affichage
   initAffichage (600, 600, NOMBRE_POINTS, 300);
   //Initialisation du r�solveur de matrice
   initResolveur (TOLERANCE_ANNULATION);
   
   //Boucle principale de r�initialisation
   do {
      
      //Les initialisations � faire chaque fois qu'on relance le fil
      initMasses ();
      afficheFilAngles (positions);
      continuer = 1;
      i = 0;
      
      //Cette boucle attend que l'utilisateur se d�cide � lancer le fil.
      while (attendre) {
         switch (pause ()) {
         case CHOIX_CONTINUER:
            attendre = 0;
            break;
         case CHOIX_QUITTER:
            continuer = 0;
            attendre = 0;
            reinitialiser = 0;
            break;
         default:
            break;
         }
      }
      
      //La boucle importante qui fait bouger le fil
      while (continuer) {
         i++;
         
         //On appelle la fonction qui g�re les approximations de l'image suivante.
         k = approxRK4 (i);
         
         /*On ne peut pas utiliser de structure switch car on utilise des
         instructions break, qui doivent servir � sortir de la boucle continuer.*/
         if (k == -1) {   //Un syst�me n'a pas pu �tre r�solu.
            
            /*Si un syst�me n'a pu �tre r�solu, on ajoute des informations dans
            stderr, ..*/
            fprintf (stderr, "   Positions:");
            for (j = 0; j < NOMBRE_POINTS; j++) {
               fprintf (stderr, "   %.6Le", positions[j]);
            }
            fprintf (stderr, "\n   Vitesses:");
            for (j = 0; j < NOMBRE_POINTS; j++) {
               fprintf (stderr, "   %.6Le", vitesses[j]);
            }
            fprintf (stderr, "\n");
            
            //..puis on fige le fil en rouge avant d'essayer de mettre fin au programme.
            filEnRouge ();
            afficheFilAngles (positions);
            if (pause () == CHOIX_REINITIALISER) {
               reinitAffichage ();
               reinitialiser = 1;
               attendre = 1;
               break;
            }
            arretAffichage ();
            return (EXIT_FAILURE);
         } else if (k == 1) { //Une des vitesses est trop importante.
            if (pause () == CHOIX_REINITIALISER) {
               reinitAffichage ();
               reinitialiser = 1;
               attendre = 1;
               break;
            }
            reinitialiser = 0;
            break;
         }
         
         //Si une image doit �tre affich�e, on intercepte aussi les �v�nements.
         if ((j = verifieEtTemporise (intervalleTemps*1000, RALENTI)) != N_AFFICHE_PAS_IMAGE) {
            
            //On affiche le fil.
            afficheFilAngles (positions);
            
            //On traite enfin les �v�nements.
            switch (gereEvenements ()) {
            case CHOIX_REINITIALISER:
               reinitAffichage ();
               reinitialiser = 1;
               continuer = 0;
               attendre = 1;
               break;
            case CHOIX_QUITTER:
               continuer = 0;
               reinitialiser = 0;
               break;
            default:
               break;
            }
         }
      }
   } while (reinitialiser);
   
   //Arret du programme
   arretAffichage ();
   return (EXIT_SUCCESS);
}

void initMasses (void)
{
   //D�claration des variables
   int i;
   
   //Positionnement des masses � l'horizontale et sans vitesse initiale
   for (i = 0; i < NOMBRE_POINTS; i++) {
       positions[i] = 0;
       vitesses[i] = 0;
   }
   
   //Initialisation de l'intervalle de temps
   intervalleTemps = INTERVALLE_TEMPS_DEPART;
   
   return;
}

void calculCoeffs(double dtblpos[NOMBRE_POINTS], double dtblvit[NOMBRE_POINTS])
{
   //D�claration des variables
   int i, j;
   double dtemp1, dtemp2, dtbltemp[NOMBRE_POINTS][NOMBRE_POINTS], carreVit[NOMBRE_POINTS];
      
   //Calculs pr�liminaires communs aux coefficients du syst�me final
   for (i = 0; i < NOMBRE_POINTS; i++) {
      for (j = 0; j < i; j++) {
         dtemp1 = dtblpos[i] - dtblpos[j];
         dtbltemp[i][j] = cos(dtemp1);
         dtbltemp[j][i] = sin(dtemp1);
      }
      carreVit[i] = CARRE(dtblvit[i]);
   }
   
   //Calculs des coefficients du syst�me final
   for (i = 0; i < NOMBRE_POINTS; i++) {
      dtemp2 = (double)(NOMBRE_POINTS - i);
      
      //On initialise le terme de la colonne.
      systeme[i][NOMBRE_POINTS] = -G_SUR_L * dtemp2 * cos(dtblpos[i]);
      
      //Calcul des coefficients de la matrice triangulaire inf�rieure
      dtemp2 += DERNIERE_MASSE - 1;
      for (j = 0; j < i; j++) {
         systeme[i][j] = dtemp2 * dtbltemp[i][j];   //i>j donc c'est un cosinus.
         systeme[i][NOMBRE_POINTS] -= dtemp2 * dtbltemp[j][i] * carreVit[j];   //j<i donc c'est un sinus.
      }
      
      //Calcul des coefficients de la diagonale
      systeme[i][i] = dtemp2;
      
      //Calcul des coefficients de la matrice triangulaire sup�rieure
      for (j = i+1; j < NOMBRE_POINTS; j++) {
         dtemp2--;
         systeme[i][j] = dtemp2 * dtbltemp[j][i];   //j>i donc c'est un cosinus.
         systeme[i][NOMBRE_POINTS] += dtemp2 * dtbltemp[i][j] * carreVit[j];   //i<j donc c'est un sinus.
      }
   }
   
   return;
}

int approxRK4 (long numeroImage)
{
   //D�claration des variables
   int i, itemp;
   double dtemp, dtbltemp1[4][NOMBRE_POINTS], dtbltemp2[NOMBRE_POINTS],
   dtbltemp3[NOMBRE_POINTS];
   static double anciennesVitesses[NOMBRE_POINTS] = {};
   
   //Pr�paration des calculs des premiers coefficients de la m�thode RK4
   calculCoeffs (positions, vitesses);
   if (resoudSys (NOMBRE_POINTS, systeme, dtbltemp1[0]) == -1) {
      fprintf (stderr, "Fonction approxRK4: image %ld, le 1er systeme n'est pas resolu.\n", numeroImage);
      return (-1);
   }
   
   //Calcul des premiers coefficients de la m�thode RK4 et pr�paration des suivants
   dtemp = intervalleTemps/72;
   for (i = 0; i < NOMBRE_POINTS; i++) {
      dtbltemp1[0][i] *= intervalleTemps;
      dtbltemp3[i] = vitesses[i] + dtbltemp1[0][i]/2;
      dtbltemp2[i] = positions[i] + dtemp*(16*dtbltemp3[i] + 21*vitesses[i] - anciennesVitesses[i]);
   }
   
   //Pr�paration des calculs des deuxi�mes coefficients de la m�thode RK4
   calculCoeffs (dtbltemp2, dtbltemp3);
   if (resoudSys (NOMBRE_POINTS, systeme, dtbltemp1[1]) == -1) {
      fprintf (stderr, "Fonction approxRK4: image %ld, le 2e systeme n'est pas resolu.\n", numeroImage);
      return (-1);
   }
   
   //Calcul des deuxi�mes coefficients de la m�thode RK4 et pr�paration des suivants
   for (i = 0; i < NOMBRE_POINTS; i++) {
      dtbltemp1[1][i] *= intervalleTemps;
      dtbltemp3[i] = vitesses[i] + dtbltemp1[1][i]/2;
      dtbltemp2[i] = positions[i] + dtemp*(16*dtbltemp3[i] + 21*vitesses[i] - anciennesVitesses[i]);
   }
   
   //Pr�paration des calculs des troisi�mes coefficients de la m�thode RK4
   calculCoeffs (dtbltemp2, dtbltemp3);
   if (resoudSys (NOMBRE_POINTS, systeme, dtbltemp1[2]) == -1) {
      fprintf (stderr, "Fonction approxRK4: image %ld, le 3e systeme n'est pas resolu.\n", numeroImage);
      return (-1);
   }
   
   //Calcul des troisi�mes coefficients de la m�thode RK4 et pr�paration des suivants
   dtemp = intervalleTemps/12;
   for (i = 0; i < NOMBRE_POINTS; i++) {
      dtbltemp1[2][i] *= intervalleTemps;
      dtbltemp3[i] = vitesses[i] + dtbltemp1[2][i];
      dtbltemp2[i] = positions[i] + dtemp*(5*dtbltemp3[i] + 8*vitesses[i] - anciennesVitesses[i]);
   }
   
   //Pr�paration des calculs des quatri�mes coefficients de la m�thode RK4
   calculCoeffs (dtbltemp2, dtbltemp3);
   if (resoudSys (NOMBRE_POINTS, systeme, dtbltemp1[3]) == -1) {
      fprintf (stderr, "Fonction approxRK4: image %ld, le 4e systeme n'est pas resolu.\n", numeroImage);
      return (-1);
   }
   
   /*Calcul des quatri�mes coefficients de la m�thode RK4, des positions, des
   vitesses et v�rification de celles-ci.*/
   itemp = 0;
   for (i = 0; i < NOMBRE_POINTS; i++) {
      dtbltemp1[3][i] *= intervalleTemps;
      positions[i] += dtemp*(8*vitesses[i] - anciennesVitesses[i]);
      anciennesVitesses[i] = vitesses[i];
      vitesses[i] += (dtbltemp1[0][i] + 2*dtbltemp1[1][i] + 2*dtbltemp1[2][i] + dtbltemp1[3][i])/6;
      positions[i] += dtemp*(5*vitesses[i]);
      if (fabs (vitesses[i]) > 2*LIMITE_TOURS_PAR_SECONDE*M_PI) {
         itemp = 1;
      }
   }
   
   return (itemp);
}
