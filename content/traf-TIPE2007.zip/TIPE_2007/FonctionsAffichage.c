/*

Les fonctions utilis�es pour l'affichage dans le programme du TIPE

Auteur : Thibault Raffaillac <thibaultraffaillac@yahoo.fr>
Cr�� le : 05/03/07

*/

#include <stdlib.h>
#include <SDL/SDL.h>

int SDL_Ligne32 (SDL_Surface *surface, int x1, int y1, int x2, int y2, Uint32 couleur)
{
   //La fonction ne s'ex�cute que si le mode d'affichage est en 32 bits par pixel.
   if (surface->format->BytesPerPixel != 4) {
      SDL_SetError ("L'affichage n'est pas en 32 bits.");
      return (-1);
   }
   
   //Initialisations
   int pitch = surface->pitch/4, dx = abs (x1-x2), dy = abs (y1-y2),
      xmin, xmax, ymin, ymax, i, limitePixel, sensDeParcours;
   Uint32 *pixels = (Uint32 *)surface->pixels, *pointeur;
   
   //Le premier test s�pare les lignes de pente "douce" de celles de pente "forte".
   if (dx >= dy) {
      //Initialisation des valeurs des variables
      if (y1 >= y2) {
         ymax = y1; ymin = y2; xmax = x1; xmin = x2;
      } else {
         ymin = y1; ymax = y2; xmin = x1; xmax = x2;
      }
      sensDeParcours = (xmin <= xmax) ? 1 : -1;
      pointeur = pixels + ymin*pitch + xmin;
      
      //Boucle de "coloriage" :)
      *pointeur = couleur;
      limitePixel = dx;
      for (i = 1; i <= dx; i++) {
         pointeur += sensDeParcours;
         if (i*dy*2 > limitePixel) {
            pointeur += pitch;
            limitePixel += dx*2;
         }
         *pointeur = couleur;
      }
   } else {
      //Initialisation des valeurs des variables
      if (x1 >= x2) {
         xmax = x1; xmin = x2; ymax = y1; ymin = y2;
      } else {
         xmin = x1; xmax = x2; ymin = y1; ymax = y2;
      }
      sensDeParcours = (ymin <= ymax) ? 1 : -1;
      pointeur = pixels + ymin*pitch + xmin;
      
      //Boucle de "coloriage" ;)
      *pointeur = couleur;
      limitePixel = dy;
      for (i = 1; i <= dy; i++) {
         pointeur += sensDeParcours*pitch;
         if (i*dx*2 > limitePixel) {
            pointeur++;
            limitePixel += dy*2;
         }
         *pointeur = couleur;
      }
   }
   return (0);
}
