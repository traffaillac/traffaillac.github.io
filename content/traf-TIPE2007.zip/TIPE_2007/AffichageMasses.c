/*

Ce fichier contient les fonctions g�rant l'affichage des masses et/ou les tiges
qui les relient, dans le cadre de mon projet de TIPE de 2007 (maths sp� 1e ann�e.)

Auteur : Thibault Raffaillac <thibaultraffaillac@yahoo.fr>
Cr�� le : 09/03/07

*/

#include <stdio.h>
#include <stdlib.h>
#include <SDL/SDL.h>
#include <time.h>
#include "FonctionsAffichage.h"
#include "AffichageMasses.h"

/*D�claration des variables internes li�es � l'affichage*/
static SDL_Surface *ecran = NULL;
static Uint32 couleurFil;
static int nombreMasses = 0, hauteur, largeur;
static double longueurTige;
//Pour verifieEtTemporise
static int dureeMinProchainAffichage = DUREE_ENTRE_CHAQUE_IMAGE;
static double dureeDepuisAffichage = 0, dureeDepuisDebutSimulation = 0;
static Uint32 dernierAffichageTheorique, dernierAffichageReel;

int initAffichage (int largeurEntree, int hauteurEntree, int nombreMassesEntre, int longueurFilEntree)
{
   //Chargement de la SDL
   if (SDL_Init (SDL_INIT_VIDEO | SDL_INIT_TIMER) == -1) {
      fprintf (stderr, "Echec dans l'initialisation de la SDL: %s\n", SDL_GetError ());
      return (-1);
   }
   
   //Cr�ation d'une zone d'affichage de taille d�sir�e
   ecran = SDL_SetVideoMode (largeurEntree, hauteurEntree, 32, SDL_SWSURFACE | SDL_DOUBLEBUF);
   if (ecran == NULL) {
      fprintf (stderr, "Impossible de charger le mode video: %s\n", SDL_GetError());
      arretAffichage ();
      return (-1);
   }
   SDL_WM_SetCaption ("Oscillations d'un fil", NULL);
   
   //On indique tous les �v�nements qu'on souhaite ignorer.
   SDL_EventState (SDL_ACTIVEEVENT, SDL_IGNORE);
   SDL_EventState (SDL_KEYUP, SDL_IGNORE);
   SDL_EventState (SDL_MOUSEMOTION, SDL_IGNORE);
   SDL_EventState (SDL_MOUSEBUTTONDOWN, SDL_IGNORE);
   SDL_EventState (SDL_MOUSEBUTTONUP, SDL_IGNORE);
   SDL_EventState (SDL_JOYAXISMOTION, SDL_IGNORE);
   SDL_EventState (SDL_JOYBALLMOTION, SDL_IGNORE);
   SDL_EventState (SDL_JOYHATMOTION, SDL_IGNORE);
   SDL_EventState (SDL_JOYBUTTONDOWN, SDL_IGNORE);
   SDL_EventState (SDL_JOYBUTTONUP, SDL_IGNORE);
   SDL_EventState (SDL_SYSWMEVENT, SDL_IGNORE);
   SDL_EventState (SDL_VIDEORESIZE, SDL_IGNORE);
   SDL_EventState (SDL_VIDEOEXPOSE, SDL_IGNORE);
   SDL_EventState (SDL_USEREVENT, SDL_IGNORE);
   
   //Initialisation des variables propres � l'affichage
   nombreMasses = nombreMassesEntre;
   longueurTige = ((double)longueurFilEntree) / ((double)nombreMasses);
   hauteur = hauteurEntree;
   largeur = largeurEntree;
   couleurFil = SDL_MapRGB (ecran->format, 0, 0, 0);
   
   //Initialisation de la mesure du temps dans la fonction verifieEtTemporise
   dernierAffichageTheorique = SDL_GetTicks ();
   dernierAffichageReel = dernierAffichageTheorique;
   
   return (0);
}

int reinitAffichage (void)
{
   //On v�rifie que l'affichage a bien �t� initialis�.
   if (ecran == NULL) {
      fprintf (stderr, "Impossible d'afficher: l'affichage n'a pas �t� initialis�\n");
      return (-1);
   }
   
   couleurFil = SDL_MapRGB (ecran->format, 0, 0, 0);
   dernierAffichageTheorique = SDL_GetTicks ();
   dernierAffichageReel = dernierAffichageTheorique;
   dureeDepuisDebutSimulation = 0;
   
   return (0);
}

int afficheFilAngles (double tableauAngles[nombreMasses])
{
   /*Erreur si l'affichage n'a pas encore �t� initialis�, ou si au contraire il
   a �t� arr�t�.*/
   if (ecran == NULL) {
      fprintf (stderr, "Impossible d'afficher: l'affichage n'a pas �t� initialis�\n");
      return (-1);
   }
   
   //D�claration des variables
   int i, itempx1, itempx2, itempy1, itempy2;
   double dtempx = hauteur/2, dtempy = largeur/2;
   itempx1 = (int)(dtempx + 0.5);
   itempy1 = (int)(dtempy + 0.5);
   
   //On "nettoie" l'�cran de l'image pr�c�dente.
   SDL_FillRect (ecran, NULL, SDL_MapRGB (ecran->format, 255, 255, 255));
   
   //La boucle de tra�age des lignes
   for (i = 0; i < nombreMasses; i++) {
      dtempx += longueurTige * cos (tableauAngles[i]);
      //Attention ! On consid�re que l'axe des ordonn�es est dirig� vers le haut.
      dtempy -= longueurTige * sin (tableauAngles[i]);
      itempx2 = (int)(dtempx + 0.5);
      itempy2 = (int)(dtempy + 0.5);
      if (SDL_Ligne32 (ecran, itempx1, itempy1, itempx2, itempy2, couleurFil) == -1) {
         fprintf (stderr, "Fonction afficheFilAngles: Impossible d'afficher: %s\n", SDL_GetError ());
         return (-1);
      }
      itempx1 = itempx2;
      itempy1 = itempy2;
   }
   SDL_Flip (ecran);
   
   return (0);
}

int verifieEtTemporise (double intervalleTemps, double ralenti)
{
   //On v�rifie que l'affichage a bien �t� initialis�.
   if (ecran == NULL) {
      fprintf (stderr, "Impossible d'afficher: l'affichage n'a pas �t� initialis�\n");
      return (-1);
   }
   //On v�rifie que ralenti est une valeur sup�rieure � 1.
   if (ralenti < 1) {
      fprintf (stderr, "Fonction verifieEtTemporise: La variable ralenti a une valeur inferieure a 1.\n");
      return (-1);
   }
   
   //D�claration des variables
   int qualiteIntervalle;
   long ltemp;
   Uint32 tempsActuel = SDL_GetTicks ();
   
   /*On ajoute l'intervalle de temps � la somme du temps th�orique, en tenant
   compte du ralenti, et on teste si l'image doit �tre affich�e.*/
   dureeDepuisAffichage += intervalleTemps * ralenti;
   dureeDepuisDebutSimulation += intervalleTemps * ralenti;
   if (dureeDepuisAffichage >= dureeMinProchainAffichage) {
      
      //On d�termine d'abord la qualit� de l'intervalle de temps.
      ltemp = tempsActuel - dernierAffichageReel;
      if (ltemp <= (((long)dureeDepuisAffichage) / 2)) { //On peut faire plus de calculs.
         qualiteIntervalle = OK_INTERVALLE_A_AUGMENTER;
      } else if (ltemp > (long)dureeDepuisAffichage) {   //On fait trop de calculs.
         
         /*Attention, m�me si l'intervalle est trop important, le fil ne sera
         pas forc�ment color� en rouge, car il reste la marge de 10ms qui permet
         de corriger l'exc�s avant que le calcul ne soit en retard par rapport
         � l'affichage.*/
         qualiteIntervalle = OK_INTERVALLE_A_DIMINUER;
      } else {
         qualiteIntervalle = OK_INTERVALLE_PARFAIT;
      }
      
      //On actualise ensuite les variables de contr�le du temps.
      dernierAffichageTheorique += (long)dureeDepuisAffichage;
      dureeMinProchainAffichage = (((long)dureeDepuisAffichage - dureeMinProchainAffichage) < DUREE_ENTRE_CHAQUE_IMAGE) ? DUREE_ENTRE_CHAQUE_IMAGE - (long)dureeDepuisAffichage + dureeMinProchainAffichage : 0;
      dureeDepuisAffichage -= (long)dureeDepuisAffichage;
      
      /*Enfin, on temporise jusqu'� la date d'affichage en essayant de conserver
      une marge de 10ms.*/
      ltemp = dernierAffichageTheorique - tempsActuel;
      if (ltemp > 10) {
         SDL_Delay (ltemp - 10);
      } else { //On ne temporise pas.
         
         /*Si le calcul est en retard par rapport � l'affichage, on colore le
         fil en rouge.*/
         if (ltemp < 0) {
            filEnRouge ();
         }
      }
      dernierAffichageReel = SDL_GetTicks ();
      return (qualiteIntervalle);
   } else {
      return (N_AFFICHE_PAS_IMAGE);
   }
}

int filEnRouge (void)
{
   //On v�rifie que l'affichage a bien �t� initialis�.
   if (ecran == NULL) {
      fprintf (stderr, "Impossible d'afficher: l'affichage n'a pas �t� initialis�\n");
      return (-1);
   }
   
   couleurFil = SDL_MapRGB (ecran->format, 255, 0, 0);
   
   return (0);
}

int gereEvenements (void)
{
   //On v�rifie que l'affichage a bien �t� initialis�.
   if (ecran == NULL) {
      fprintf (stderr, "Impossible d'afficher: l'affichage n'a pas �t� initialis�\n");
      return (-1);
   }
   
   //D�claration des variables
   SDL_Event event;
   int choix = CHOIX_CONTINUER;
   
   /*La boucle qui extrait tous les �v�nements qui ont �t� �mis depuis le dernier
   appel de cette fonction*/
   while (SDL_PollEvent (&event)) {
      switch (event.type) {
         case SDL_QUIT:
            return (CHOIX_QUITTER);
            break;
         case SDL_KEYDOWN:
            switch (event.key.keysym.sym) {
               case SDLK_RETURN:
                  choix = CHOIX_PAUSE;
                  break;
               case SDLK_ESCAPE:
                  return (CHOIX_QUITTER);
                  break;
               case SDLK_DELETE:
                  return (CHOIX_REINITIALISER);
                  break;
               default:
                  break;
            }
            break;
         default:
            break;
      }
   }
   
   if (choix == CHOIX_PAUSE)
      choix = pause();
   
   return (choix);
}

int pause (void)
{
   //On v�rifie que l'affichage a bien �t� initialis�.
   if (ecran == NULL) {
      fprintf (stderr, "Impossible d'afficher: l'affichage n'a pas �t� initialis�\n");
      return (-1);
   }
   
   /*Declaration des variables*/
   SDL_Event event;
   //La diff�rence de temps introduite par la pause sera calcul�e apr�s la pause.
   Uint32 tempsAvant = SDL_GetTicks ();
   Uint32 tempsApres;
   
   //La boucle qui poireaute en attendant les �v�nements, et qui les g�re
   while (SDL_WaitEvent (&event)) {
      
      //On compense d'abord le temps consomm� par la pause.
      tempsApres = SDL_GetTicks ();
      dernierAffichageTheorique += tempsApres - tempsAvant;
      dernierAffichageReel += tempsApres - tempsAvant;
      tempsAvant = tempsApres;
      
      switch (event.type) {
         case SDL_QUIT:
            return (CHOIX_QUITTER);
            break;
         case SDL_KEYDOWN:
            switch (event.key.keysym.sym) {
               case SDLK_RETURN:
                  return (CHOIX_CONTINUER);
                  break;
               case SDLK_ESCAPE:
                  return (CHOIX_QUITTER);
                  break;
               case SDLK_SPACE:
                  if (priseImage ())
                     fprintf (stderr, "Impossible d'enregistrer une image: %s\n", SDL_GetError());
                  break;
               case SDLK_DELETE:
                  return (CHOIX_REINITIALISER);
                  break;
               default:
                  break;
            }
            break;
         default:
            break;
      }
   }
   
   //Si le programme poursuit apr�s la boucle, cel� signifie qu'il y a eu une erreur.
   fprintf (stderr, "Erreur de SDL_WaitEvent: %s\n", SDL_GetError());
   return (CHOIX_QUITTER);   
}

int priseImage (void)
{
   //On v�rifie que l'affichage a bien �t� initialis�.
   if (ecran == NULL) {
      fprintf (stderr, "Impossible d'afficher: l'affichage n'a pas �t� initialis�\n");
      return (-1);
   }
   
   /*On dessine un cadre autour du fil.*/
   SDL_Ligne32 (ecran, 0, 0, largeur - 1, 0, couleurFil);
   SDL_Ligne32 (ecran, largeur - 1, 0, largeur - 1, hauteur - 1, couleurFil);
   SDL_Ligne32 (ecran, largeur - 1, hauteur - 1, 0, hauteur - 1, couleurFil);
   SDL_Ligne32 (ecran, 0, hauteur - 1, 0, 0, couleurFil);
   
   /*On d�termine le nom du ficher en y indiquant le nombre de masses et la date
   de cr�ation.*/
   char nomFichier[50];
   time_t nowSec = time (NULL);
   struct tm *now = localtime (&nowSec);
   sprintf (nomFichier, "fil_de_%d_masses_%02d-%02d-%02d_%dh%02dm%02ds_%.3fs.bmp",
      nombreMasses, now->tm_mday, now->tm_mon + 1, now->tm_year % 100,
      now->tm_hour, now->tm_min, now->tm_sec, dureeDepuisDebutSimulation/1000);
   
   //Puis on enregistre.
   return (SDL_SaveBMP(ecran, nomFichier));
}

void arretAffichage (void)
{
   //On annule le pointeur ecran, ainsi afficheFil ne peut plus �tre utilis�e
   ecran = NULL;
   SDL_Quit ();
   
   return;
}
