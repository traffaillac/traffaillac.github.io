/*

Ce fichier contient les fonctions g�rant l'affichage des masses et/ou les tiges
qui les relient, dans le cadre de mon projet de TIPE de 2007 (maths sp� 1e ann�e.)

Auteur : Thibault Raffaillac <thibaultraffaillac@yahoo.fr>
Cr�� le : 09/03/07

*/

#ifndef TRAF_TIPE_AFFICHAGE_MASSES_H
#define TRAF_TIPE_AFFICHAGE_MASSES_H

#define DUREE_ENTRE_CHAQUE_IMAGE 40

typedef enum {
   CHOIX_CONTINUER,
   CHOIX_QUITTER,
   CHOIX_REINITIALISER,
   CHOIX_PRISE_IMAGE,
   CHOIX_PAUSE
} AffChoix;

typedef enum {
   N_AFFICHE_PAS_IMAGE,
   OK_INTERVALLE_A_AUGMENTER,
   OK_INTERVALLE_PARFAIT,
   OK_INTERVALLE_A_DIMINUER
} AffImage;

/*Cette fonction initialise la SDL et cr�e un �cran par d�faut de taille voulue.
La fonction renvoie 0 apr�s s'�tre d�roul�e sans encombre et -1 en cas d'�chec.*/
int initAffichage (int largeurEntree, int hauteurEntree, int nombreMassesEntre, int longueurFilEntree);

/*Cette fonction r�initialise des param�tres li�s � l'affichage en vue de
relancer le fil.

Si la fonction est appel�e alors que l'affichage n'a pas encore �t� initialis�,
alors elle renverra -1.*/
int reinitAffichage (void);

/*Cette fonction affiche le fil � partir des donn�es des angles des tiges.

Si la fonction est appel�e alors que l'affichage n'a pas �t� initialis�,
alors elle renverra -1.*/
int afficheFilAngles (double tableauMasses[]);

/*Cette fonction d�termine en fonction de l'intervalle de temps qui lui est
envoy� si l'image qui lui correspond doit �tre affich�e, en respectant ces r�gles:
_une image est affich�e toutes les 40ms en moyenne, mais cette dur�e peut �tre
chang�e.
_si les intervalles de temps d�passent toujours 40ms, toutes les images seront
affich�es.
_si le temps r�el se situe apr�s le temps th�orique d'affichage d'une image,
alors le fil est color� en rouge.
_dans l'autre cas o� le calcul n'est donc pas en retard, on temporise jusqu'� 10ms
avant l'affichage th�orique de mani�re � toujours conserver une marge de temps.
_si une image doit �tre affich�e, la fonction indique en plus si l'intervalle
doit �tre augment�, s'il peut �tre diminu� ou s'il est parfait, en renvoyant
OK_INTERVALLE_A_AUGMENTER, OK_INTERVALLE_A_DIMINUER ou OK_INTERVALLE_PARFAIT.
Si l'image ne doit pas �tre affich�e, la fonction renvoie N_AFFICHE_PAS_IMAGE.
_la fonction re�oit aussi une valeur ralenti qui d�signe un coefficient
multiplicateur de l'intervalle de temps, 1 signifiant alors "pas de ralenti".
Plus d'images seront bien s�r d�clar�es comme � afficher.

Si la fonction est appel�e alors que l'affichage n'a pas encore �t� initialis�
ou si le ralenti est inf�rieur � 1, alors elle renverra -1.

Attention ! intervalleTemps doit �tre donn�e en millisecondes.*/
int verifieEtTemporise (double intervalleTemps, double ralenti);

/*Cette fonction colore le fil en rouge.

Si elle est appel�e alors que l'affichage n'a pas �t� initialis�, alors elle
renverra -1.*/
int filEnRouge (void);

/*Cette fonction intercepte les �v�nements, les traite (pause, sauvegarde
d'image, r�initialisation de l'oscillateur) et renvoie CHOIX_CONTINUER pour
continuer, CHOIX_QUITTER pour quitter et CHOIX_REINITIALISER pour r�initialiser.

Si la fonction est appel�e alors que l'affichage n'a pas encore �t� initialis�,
alors elle renverra -1.
*/
int gereEvenements (void);

/*Cette fonction impose une pause :) pendant laquelle on peut au choix prendre
une photo, ou r�initialiser. Elle renvoie CHOIX_QUITTER, CHOIX_CONTINUER ou
CHOIX_REINITIALISER.

Si la fonction est appel�e alors que l'affichage n'a pas encore �t� initialis�,
alors elle renverra -1.
*/
int pause (void);

/*Cette fonction sauvegarde l'image actuellement affich�e dans un fichier, en
prenant garde de ne pas en �craser un pr�c�dent au passage.
Elle renvoie 0 si l'op�ration s'est d�roul�e avec succ�s et -1 en cas d'�chec.*/
int priseImage (void);

/*Cette fonction arr�te la SDL.*/
void arretAffichage (void);

#endif
