/*

Les fonctions utilis�es pour l'affichage dans le programme du TIPE

Auteur : Thibault Raffaillac <thibaultraffaillac@yahoo.fr>
Cr�� le : 05/03/07

*/

#ifndef TRAF_TIPE_FONCTIONS_AFFICHAGE_H
#define TRAF_TIPE_FONCTIONS_AFFICHAGE_H

/*Fonction qui trace un segment entre deux points d�limit�s par leurs coordonn�es
dans la surface dans laquelle on dessine.
Cette fonction n'utilise que des op�rations d'entiers (comme �a elle est rapide :).*/
int SDL_ligne32 (SDL_Surface *surface, int x1, int y1, int x2, int y2, Uint32 couleur);

#endif
