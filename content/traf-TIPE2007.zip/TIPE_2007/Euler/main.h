/*

Le projet d'Oscillation d'un Fil en angles consiste � simuler les oscillations
d'un pendule de n masses identiques li�es entre elles par des tiges rigides, en
utilisant les angles qu'elles font avec la verticale dans un rep�re euclidien.

Le probl�me est ici r�solu en utilisant les outils suivants :
_coordonn�es angulaires
_�quations de Lagrange
_m�thode d'Euler

Auteur : Thibault Raffaillac
Cr�� le : 29/04/07

*/

#ifndef TRAF_MAIN_H
#define TRAF_MAIN_H

//La constante qui influe sur le r�alisme de la simulation
#define G_SUR_L 98.1

//Cette macro �l�ve au carr� son argument.
#define CARRE(arg) ((arg)*(arg))

int main(int argc, char *argv[]);

/*Cette fonction initialise les param�tres des masses de telle fa�on que le fil
soit en position initiale � la verticale et immobile.*/
void initMasses(void);

/*Cette fonction calcule les coefficients des n syst�mes lin�aires � n inconnues
(les acc�l�rations).*/
void calculCoeffs(long numeroImage);

/*Cette fonction r�alise l'approximation des positions des masses puis des
vitesses par la m�thode d'Euler, � partir des r�sultats de la r�solution du
syst�me d'�quations sur les acc�l�rations.

Elle renvoie -1 si une des vitesses calcul�e d�passe la limite de tours par
seconde.*/
int approxEuler(void);

#endif
