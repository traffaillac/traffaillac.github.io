/*

Le projet d'Oscillation d'un Fil en angles consiste � simuler les oscillations
d'un pendule de n masses identiques li�es entre elles par des tiges rigides, en
utilisant les angles qu'elles font avec la verticale dans un rep�re euclidien.

Le probl�me est ici r�solu en utilisant les outils suivants :
_coordonn�es angulaires
_�quations de Lagrange
_m�thode d'Euler

R�alis� par : bOOOby
Cr�ation le : 29/04/07

*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <SDL/SDL.h>
#include "../AffichageMasses.h"
#include "../../FonctionsUtiles/UtilitesVariees.h"
#include "../../FonctionsUtiles/UtilitesMatrices.h"
#include "main.h"

#define TOLERANCE_ANNULATION 4   //Le test d'annulation d'un nombre en virgule flotante sera fait � 10^-4 pr�s.

#define NOMBRE_POINTS 20   //Le pendule est constitu� de 10 masses.

#define INTERVALLE_TEMPS 0.001 //Pour l'approximation: une image est calcul�e toutes les 0.0001 secondes.

#define LIMITE_TOURS_PAR_SECONDE 100 //Le programme s'arr�te si la vitesse d'une masse exc�de 10 tours par seconde.

#define RALENTI 2

//D�claration des variables internes 
static double positions[NOMBRE_POINTS];
static double vitesses[NOMBRE_POINTS];
static double accelerations[NOMBRE_POINTS];
static double systeme[NOMBRE_POINTS][NOMBRE_POINTS+1];

int main (int argc, char *argv[])
{
   //D�claration des variables
   int i, j, continuer = 0, reinitialiser, attendre = 1;
   
   //Initialisation de l'affichage
   initAffichage (600, 600, NOMBRE_POINTS, 300);
   //Initialisation du r�solveur de matrice
   initResolveur (TOLERANCE_ANNULATION);
   
   //Boucle principale de r�initialisation
   do {
      
      //Les initialisations � faire chaque fois qu'on relance le fil             //Ne pas oublier d'appeler reinitAffichage pour r�initialiser.
      initMasses ();
      afficheFilAngles (positions);
      continuer = 1;
      i = 0;
      
      //Cette boucle attend que l'utilisateur se d�cide � lancer le fil.
      while (attendre) {
         switch (pause ()) {
         case CHOIX_CONTINUER:
            attendre = 0;
            break;
         case CHOIX_QUITTER:
            continuer = 0;
            attendre = 0;
            reinitialiser = 0;
            break;
         default:
            break;
         }
      }
      
      //La boucle importante qui fait bouger le fil
      while (continuer) {
         i++;
         
         //On calcule les coefficients de la matrice des acc�l�rations.
         calculCoeffs (i);
         
         //On r�soud cette matrice.
         if (resoudSys(NOMBRE_POINTS, systeme, accelerations) == -1) {
            
            //Si la matrice n'a pu �tre r�solue, on le signale dans stderr, ..
            fprintf (stderr, "Systeme des accelerations non resolu a l'image %ld:\n   Positions:", i);
            for (j = 0; j < NOMBRE_POINTS; j++) {
               fprintf (stderr, "   %.6Le", positions[j]);
            }
            fprintf (stderr, "\n   Vitesses:");
            for (j = 0; j < NOMBRE_POINTS; j++) {
               fprintf (stderr, "   %.6Le", vitesses[j]);
            }
            fprintf (stderr, "\n");
            
            //..puis on fige le fil en rouge avant d'essayer de mettre fin au programme.
            filEnRouge ();
            afficheFilAngles (positions);
            if (pause () == CHOIX_REINITIALISER) {
               reinitAffichage ();
               reinitialiser = 1;
               attendre = 1;
               break;
            }
            arretAffichage ();
            return EXIT_FAILURE;
         }
         
         //On approxime les nouvelles positions et vitesses.
         if (approxEuler () == -1) {   //Une des vitesses est trop importante.
            if (pause () == CHOIX_REINITIALISER) {
               reinitAffichage ();
               reinitialiser = 1;
               attendre = 1;
               break;
            }
            reinitialiser = 0;
            break;
         }
         
         //Si une image doit �tre affich�e, on intercepte aussi les �v�nements.
         if ((j = verifieEtTemporise (INTERVALLE_TEMPS*1000, RALENTI)) != N_AFFICHE_PAS_IMAGE) {
            
            //On affiche le fil.
            afficheFilAngles (positions);
            
            //On traite enfin les �v�nements.
            switch (gereEvenements ()) {
            case CHOIX_REINITIALISER:
               reinitAffichage ();
               reinitialiser = 1;
               continuer = 0;
               attendre = 1;
               break;
            case CHOIX_QUITTER:
               continuer = 0;
               reinitialiser = 0;
               break;
            default:
               break;
            }
         }
      }
   } while (reinitialiser);
   
   //Arret du programme
   arretAffichage ();
   return EXIT_SUCCESS;
}

void initMasses (void)
{
   //D�claration des variables
   int i;
   
   //Positionnement des masses � l'horizontale et sans vitesse initiale
   for (i = 0; i < NOMBRE_POINTS; i++) {
       positions[i] = 0;
       vitesses[i] = 0;
   }
}

void calculCoeffs (long numeroImage)
{
   //D�claration des variables
   int i, j, itemp;
   double dtemp, dtbltemp[NOMBRE_POINTS][NOMBRE_POINTS], carreVit[NOMBRE_POINTS];
      
   //Calculs pr�liminaires communs aux coefficients du syst�me final
   for (i = 0; i < NOMBRE_POINTS; i++) {
      for (j = 0; j < i; j++) {
         dtemp = positions[i] - positions[j];
         dtbltemp[i][j] = cos(dtemp);
         dtbltemp[j][i] = sin(dtemp);
      }
      carreVit[i] = CARRE(vitesses[i]);
   }
   
   //Calculs des coefficients du syst�me final
   for (i = 0; i < NOMBRE_POINTS; i++) {
      itemp = NOMBRE_POINTS - i;
      
      //On initialise le terme de la colonne.
      systeme[i][NOMBRE_POINTS] = -G_SUR_L * itemp * cos(positions[i]);
      
      //Calcul des coefficients de la matrice triangulaire inf�rieure
      for (j = 0; j < i; j++) {
         systeme[i][j] = itemp * dtbltemp[i][j];   //i>j donc c'est un cosinus.
         systeme[i][NOMBRE_POINTS] -= itemp * dtbltemp[j][i] * carreVit[j];   //j<i donc c'est un sinus.
      }
      
      //Calcul des coefficients de la diagonale
      systeme[i][i] = itemp;
      
      //Calcul des coefficients de la matrice triangulaire sup�rieure
      for (j = i+1; j < NOMBRE_POINTS; j++) {
         itemp = NOMBRE_POINTS - j;
         systeme[i][j] = itemp * dtbltemp[j][i];   //j>i donc c'est un cosinus.
         systeme[i][NOMBRE_POINTS] += itemp * dtbltemp[i][j] * carreVit[j];   //i<j donc c'est un sinus.
      }
   }
}

int approxEuler(void)
{
   //D�claration des variables
   int i;
   
   //Boucle d'approximation des positions et des vitesses
   for (i = 0; i < NOMBRE_POINTS; i++) {
      positions[i] += vitesses[i] * INTERVALLE_TEMPS;
      vitesses[i] += accelerations[i] * INTERVALLE_TEMPS;
      if (fabs (vitesses[i]) > 2*LIMITE_TOURS_PAR_SECONDE*M_PI) {
         return -1;
      }
   }
}
