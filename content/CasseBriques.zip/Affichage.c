/*

Fichier: Affichage.c

Auteur: Thibault Raffaillac <thibaultraffaillac@yahoo.fr>
Cr�� le: 04/07/07

Ce fichier contient les fonctions pour g�rer l'affichage du casse-briques.

*/

#include "Affichage.h"

int premierAffichage (ObjetsAffichage *surfaces, ObjetsCDE *objets)
{
   //D�claration des variables
   int i, j, k = 0;
   Uint32 couleur;
   
   /* On remplit d'abord l'�cran de noir. */
   if (SDL_FillRect (surfaces->ecran, NULL, surfaces->couleurNoir) < 0) {
      fprintf (stderr, "Fonction premierAffichage: Echec lors du coloriage de l'ecran en noir: %s\n", SDL_GetError ());
      return (-1);
   }
   
   /* Puis on dessine les lignes de bord. */
   SDL_Ligne32 (surfaces->ecran, 0, 599, 0, 0, surfaces->couleurBlanc);
   SDL_Ligne32 (surfaces->ecran, 0, 0, 799, 0, surfaces->couleurBlanc);
   SDL_Ligne32 (surfaces->ecran, 799, 0, 799, 599, surfaces->couleurBlanc);
   
   /* On dessine les briques. */
   for (i = 0; i < NOMBRE_BRIQUES_EN_HAUTEUR; i++) {
      couleur = SDL_MapTSV (surfaces->ecran->format, (float)(rand () % 360), 1.0, 1.0);
      surfaces->cadresActualisation[2].y = objets->briques[k].y;
      for (j = 0; j < NOMBRE_BRIQUES_EN_LARGEUR; j++) {
         surfaces->cadresActualisation[2].x = objets->briques[k].x;
         if (SDL_FillRect (surfaces->ecran, &(surfaces->cadresActualisation[2]), couleur) < 0) {
            fprintf (stderr, "Fonction premierAffichage: Echec lors de l'affichage de la %de brique: %s\n", k+1, SDL_GetError ());
            return (-1);
         }
         k++;
      }
   }
   
   /* On affiche la barre. */
   afficheBarre (surfaces, objets);
   surfaces->aToucheBarre = 0;
   
   /* On affiche enfin la balle. */
   afficheBalle (surfaces, objets);
   
   SDL_UpdateRect (surfaces->ecran, 0, 0, 0, 0);
   
   return (0);
}

int preparationAffichage (ObjetsAffichage *surfaces)
{
   /* Pour la barre. */
   surfaces->barreChangee = 0;
   
   /* Pour les briques. */
   surfaces->cadreLibre = 2;
   
   /* Pour la balle. */
   return (effaceBalle (surfaces));
}

int actualiseAffichage (ObjetsAffichage *surfaces, ObjetsCDE *objets)
{
   //D�claration des variables
   int i = 1, j;
   
   /* On affiche la barre d'abord. */
   if (surfaces->barreChangee) {
      afficheBarre (surfaces, objets);
      i = 0;
      j = surfaces->cadresActualisation[0].x - surfaces->cadresEffacement[0].x;
      if (j > 0) {
         surfaces->cadresActualisation[0].w += j;
         surfaces->cadresActualisation[0].x = surfaces->cadresEffacement[0].x;
      } else {
         if (surfaces->cadresActualisation[0].w < surfaces->cadresEffacement[0].w - j) {
            surfaces->cadresActualisation[0].w = surfaces->cadresEffacement[0].w - j;
         }
      }
      if (surfaces->cadresEffacement[0].y < surfaces->cadresActualisation[0].y) {
         surfaces->cadresActualisation[0].y = surfaces->cadresEffacement[0].y;
         surfaces->cadresActualisation[0].h = surfaces->cadresEffacement[0].h;
      }
   }
   
   /* Puis on affiche la balle. */
   afficheBalle (surfaces, objets);
   
   /* Enfin, on rafra�chit l'�cran. */
   if (surfaces->cadresEffacement[1].x < surfaces->cadresActualisation[1].x) {
      surfaces->cadresActualisation[1].w = surfaces->cadresActualisation[1].x - surfaces->cadresEffacement[1].x + 2 * RAYON_BALLE + 1;
      surfaces->cadresActualisation[1].x = surfaces->cadresEffacement[1].x;
   } else {
      surfaces->cadresActualisation[1].w = surfaces->cadresEffacement[1].x - surfaces->cadresActualisation[1].x + 2 * RAYON_BALLE + 1;
   }
   if (surfaces->cadresEffacement[1].y < surfaces->cadresActualisation[1].y) {
      surfaces->cadresActualisation[1].h = surfaces->cadresActualisation[1].y - surfaces->cadresEffacement[1].y + 2 * RAYON_BALLE + 1;
      surfaces->cadresActualisation[1].y = surfaces->cadresEffacement[1].y;
   } else {
      surfaces->cadresActualisation[1].h = surfaces->cadresEffacement[1].y - surfaces->cadresActualisation[1].y + 2 * RAYON_BALLE + 1;
   }
   SDL_UpdateRects (surfaces->ecran, surfaces->cadreLibre - i, &(surfaces->cadresActualisation[i]));
   
   
}

int effaceBarre (ObjetsAffichage *surfaces)
{
   /* Effacer la barre consiste simplement ici � la "recouvrir" d'un rectangle noir. */
   if (SDL_FillRect (surfaces->ecran, &(surfaces->cadresEffacement[0]), surfaces->couleurNoir) < 0) {
      fprintf (stderr, "Fonction effaceBarre: Echec lors du recouvrement de la barre: %s\n", SDL_GetError ());
      return (-1);
   }
   
   /* Mais on recopie l'emplacement de la surface pour l'actualisation future de
   l'�cran. */
   surfaces->cadresActualisation[0].x = surfaces->cadresEffacement[0].x;
   surfaces->cadresActualisation[0].y = surfaces->cadresEffacement[0].y;
   surfaces->cadresActualisation[0].w = surfaces->cadresEffacement[0].w;
   surfaces->cadresActualisation[0].h = surfaces->cadresEffacement[0].h;
   
   return (0);
}

int effaceBalle (ObjetsAffichage *surfaces)
{
   /* Effacer la balle est la m�me chose que pour la barre. */
   if (SDL_FillRect (surfaces->ecran, &(surfaces->cadresEffacement[1]), surfaces->couleurNoir) < 0) {
      fprintf (stderr, "Fonction effaceBalle: Echec lors du recouvrement de la balle: %s\n", SDL_GetError ());
      return (-1);
   }
   
   /* Et on recopie ici une partie de l'emplacement de la surface. */
   surfaces->cadresActualisation[1].x = surfaces->cadresEffacement[1].x;
   surfaces->cadresActualisation[1].y = surfaces->cadresEffacement[1].y;
   
   return (0);
}

int effaceBrique (ObjetsAffichage *surfaces, ObjetsCDE *objets, int indexBrique)
{
   //D�claration des variables
   int i = surfaces->cadreLibre;
   
   /* Pareil que pr�c�demment, on recouvre de noir. */
   surfaces->cadresActualisation[i].x = objets->briques[indexBrique].x;
   surfaces->cadresActualisation[i].y = objets->briques[indexBrique].y;
   if (SDL_FillRect (surfaces->ecran, &(surfaces->cadresActualisation[i]), surfaces->couleurNoir) < 0) {
      fprintf (stderr, "Fonction effaceBrique: Echec lors de l'effacement de la %de brique: %s\n", indexBrique, SDL_GetError ());
      return (-1);
   }
   
   /* Pour finir, on indique que le cadre doit �tre actualis� sur l'�cran. */
   surfaces->cadreLibre++;
   
   return (0);
}

int afficheBarre (ObjetsAffichage *surfaces, ObjetsCDE *objets)
{
   //D�claration des variables
   int i = indexAngle (objets->angleBarre);
   SDL_Surface *barre;
   
   /* On actualise le cadre, et on blitte ! */
   if (i == 0) {
      barre = surfaces->barre;
   } else if (i > 0) {
      barre = surfaces->barreGauche[i-1];
   } else {
      barre = surfaces->barreDroite[-i-1];
   }
   surfaces->cadresEffacement[0].x = objets->barreX - barre->w / 2;
   surfaces->cadresEffacement[0].y = ORDONNEE_BARRE - barre->h / 2;
   while ((i = SDL_BlitSurface (barre, NULL, surfaces->ecran, &(surfaces->cadresEffacement[0]))) == -2) {
      redessineObjetsAffichage (surfaces);
   }
   if (i < 0) {
      fprintf (stderr, "Fonction afficheBarre: Echec a l'affichage de la barre: %s\n", SDL_GetError ());
      return (-1);
   }
   surfaces->cadresEffacement[0].w = barre->w;
   surfaces->cadresEffacement[0].h = barre->h;
   
   return (0);
}

int afficheBalle (ObjetsAffichage *surfaces, ObjetsCDE *objets)
{
   //D�claration des variables
   int i;
   
   /* On actualise encore le cadre de la balle, et on blitte. */
   surfaces->cadresEffacement[1].x = (int)(objets->balle.x + 0.5) - RAYON_BALLE;
   surfaces->cadresEffacement[1].y = (int)(objets->balle.y + 0.5) - RAYON_BALLE;
   while ((i = SDL_BlitSurface (surfaces->balle, NULL, surfaces->ecran, &(surfaces->cadresEffacement[1]))) == -2) {
      redessineObjetsAffichage (surfaces);
   }
   if (i < 0) {
      fprintf (stderr, "Fonction afficheBalle: Echec a l'affichage de la balle: %s\n", SDL_GetError ());
      return (-1);
   }
   
   return (0);
}
