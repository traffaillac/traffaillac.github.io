/*

Fichier: Constantes.h

Auteur: Thibault Raffaillac <thibaultraffaillac@yahoo.fr>
Cr�� le: 08/07/07

Ce fichier contient les constantes de pr�compilation du jeu et les structures.

*/

#ifndef TRAF_CONSTANTES_H
#define TRAF_CONSTANTES_H

#include <SDL/SDL.h>
#include <FMOD/fmod.h>
#include <FMOD/fmod_errors.h>

#ifndef FALSE
#define FALSE 0
#endif
#ifndef TRUE
#define TRUE 1
#endif

/* Pour l'affichage. */
#define NIVEAU_GRIS_BARRE 128

/* Pour le temps. */
#define INTERVALLE_TEMPS 25

/* Pour les briques. */
#define NOMBRE_BRIQUES_EN_LARGEUR 10
#define NOMBRE_BRIQUES_EN_HAUTEUR 6
#define NOMBRE_BRIQUES (NOMBRE_BRIQUES_EN_HAUTEUR*NOMBRE_BRIQUES_EN_LARGEUR)
#define LARGEUR_BRIQUE 50
#define HAUTEUR_BRIQUE 26
#define NOMBRE_LARGEURS_INTER_BRIQUES_AUX_BORDS 4
#define NOMBRE_HAUTEURS_INTER_BRIQUES_AUX_BORDS 3
#define INTER_BRIQUES_X ((800-NOMBRE_BRIQUES_EN_LARGEUR*LARGEUR_BRIQUE)/(NOMBRE_LARGEURS_INTER_BRIQUES_AUX_BORDS*2+NOMBRE_BRIQUES_EN_LARGEUR-1))
#define INTER_BRIQUES_Y ((480-NOMBRE_BRIQUES_EN_HAUTEUR*HAUTEUR_BRIQUE)/(NOMBRE_HAUTEURS_INTER_BRIQUES_AUX_BORDS*2+NOMBRE_BRIQUES_EN_HAUTEUR-1))
#define LARGEUR_BORD_GAUCHE ((800-NOMBRE_BRIQUES_EN_LARGEUR*(LARGEUR_BRIQUE+INTER_BRIQUES_X)+INTER_BRIQUES_X)/2)
#define LARGEUR_BORD_DROIT (800-LARGEUR_BORD_GAUCHE-NOMBRE_BRIQUES_EN_LARGEUR*(LARGEUR_BRIQUE+INTER_BRIQUES_X)+INTER_BRIQUES_X)
#define HAUTEUR_BORD_HAUT ((480-NOMBRE_BRIQUES_EN_HAUTEUR*(HAUTEUR_BRIQUE+INTER_BRIQUES_Y)+INTER_BRIQUES_Y)/2)
#define HAUTEUR_BORD_BAS (480-HAUTEUR_BORD_HAUT-NOMBRE_BRIQUES_EN_HAUTEUR*(HAUTEUR_BRIQUE+INTER_BRIQUES_Y)+INTER_BRIQUES_Y)

/* Pour la balle. */
#define RAYON_BALLE 7
#define LIMITE_ANGLE_BALLE 0.2F
#define VITESSE_BALLE 300 /* En pixels/seconde. */
#define MAX_DEPLACEMENT_BALLE (VITESSE_BALLE * (double)INTERVALLE_TEMPS / 1000.0F)

/* Pour la barre. */
#define NOMBRE_INCLINAISONS 6
#define MOITIE_HAUTEUR_BARRE 6
#define MOITIE_LARGEUR_BARRE 35
#define LIMITE_ANGLE 0.18F
#define ORDONNEE_BARRE 576
#define VITESSE_MAX_ANGLE_MAX 300.0F
#define MAX_MOITIE_HAUTEUR_BARRE_INCLINEE (MOITIE_HAUTEUR_BARRE+sin(LIMITE_ANGLE)*(MOITIE_LARGEUR_BARRE-MOITIE_HAUTEUR_BARRE))
#define NOMBRE_ITERATIONS_DEPLACEMENT 20

/* Pour le jeu. */
#define ANGLE_CONE_HASARD 0.12F
#define TOLERANCE_ANNULATION 4

/**
 * La structure manipul�e par les fonctions d'affichage, et qui contient les
 * surfaces � afficher.
 */
typedef struct {
   SDL_Surface *ecran;
   
   /* La balle... */
   SDL_Surface *balle;
   
   /* La barre du joueur. Elle est initialement horizontale, mais s'incline
   l�g�rement avec les mouvements du joueur. */
   SDL_Surface *barre;
   SDL_Surface *barreGauche[NOMBRE_INCLINAISONS], *barreDroite[NOMBRE_INCLINAISONS];
   int barreChangee;
   int aToucheBarre;
   
   /* Les couleurs � r�utiliser fr�quement dans le programme. */
   Uint32 couleurBlanc, couleurNoir;
   
   /* Les cadres d'actualisation/effacement de l'�cran.
   0 : barre, 1 : balle, 2 et 3 : briques. */
   SDL_Rect cadresEffacement[2];
   SDL_Rect cadresActualisation[4];
   int cadreLibre;
} ObjetsAffichage;

/**
 * La structure contenant les samples � jouer lors des collisions, et la musique
 * de fond.
 */
typedef struct {
   
   /* Les samples de collision (la valeur NULL est accept�e dans le programme.). */
   FSOUND_SAMPLE *rebondBarre, *rebondBrique;
   
   /* La musique jou�e en arri�re plan (La valeur NULL est accept�e.). */
   FSOUND_STREAM *musiqueFond;
   int canal;
   
} ObjetsSon;

/**
 * Une structure pour contenir les coordonn�es cart�siennes d'un point.
 */
typedef struct {
   int x, y;
} iPointXY;
typedef struct {
   double x, y;
} dPointXY;

/**
 * La structure contenant toutes les informations n�cessaires � la gestion des
 * collisions: positions de la balle, de la barre et des briques.
 */
typedef struct {
   
   /* Les coordonn�es de la balle. */
   dPointXY balle;
   double angleBalle;
   int retientBalle;
   
   /* Les coordonn�es de la barre. */
   int barreX;
   double angleBarre;
   
   /* Les coordonn�es du coin en haut � gauche des briques. */
   iPointXY briques[NOMBRE_BRIQUES];
   int etatBriques[NOMBRE_BRIQUES];
   int briquesRestantes;
   
   /* Des objets pour le temps. */
   Uint32 tempsPrecedent;
   int ecartTemps;
} ObjetsCDE;

#endif
