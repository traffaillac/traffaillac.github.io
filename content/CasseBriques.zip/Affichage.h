/*

Fichier: Affichage.h

Auteur: Thibault Raffaillac <thibaultraffaillac@yahoo.fr>
Cr�� le: 04/07/07

Ce fichier contient les fonctions pour g�rer l'affichage du casse-briques.

*/

#ifndef TRAF_AFFICHAGE_H
#define TRAF_AFFICHAGE_H

#include "Constantes.h"
#include <stdlib.h>
#include <stdio.h>
#include "../../FonctionsUtiles/SDL_Utilites.h"
#include "ChargementAffichage.h"
#include "CollisionsDeplacementsEvenements.h"

/**
 * Cette fonction effectue le premier affichage du casse-briques.
 * Les briques sont color�es de mani�re al�atoire sur chaque ligne de briques.
 *
 * Elle renvoie -1 en cas d'erreur.
 */
int premierAffichage (ObjetsAffichage *surfaces, ObjetsCDE *objets);

/**
 * Cette fonction pr�pare les donn�es li�es � l'affichage avant le traitement
 * des �v�nements et des collisions.
 *
 * Elle renvoie -1 en cas d'erreur.
 */
int preparationAffichage (ObjetsAffichage *surfaces);

/**
 * Cette fonction affiche la balle, la barre (si elle a chang� de position.) et
 * rafra�chit l'�cran.
 *
 * Elle renvoie -1 en cas d'erreur.
 */
int actualiseAffichage (ObjetsAffichage *surfaces, ObjetsCDE *objets);

/**
 * Cette fonction efface la barre dans sa position pr�c�dente (index 0 du
 * tableau cadres.).
 *
 * Elle renvoie -1 en cas d'erreur.
 */
int effaceBarre (ObjetsAffichage *surfaces);

/**
 * Cette fonction efface la balle (index 1 du tableau cadres.).
 *
 * Elle renvoie -1 en cas d'erreur.
 */
int effaceBalle (ObjetsAffichage *surfaces);

/**
 * Cette fonction efface la brique dont l'index est donn� en argument.
 *
 * Elle renvoie -1 en cas d'erreur.
 */
int effaceBrique (ObjetsAffichage *surfaces, ObjetsCDE *objets, int indexBrique);

/**
 * Cette fonction affiche la barre dans sa nouvelle position.
 *
 * Elle renvoie -1 en cas d'erreur.
 */
int afficheBarre (ObjetsAffichage *surfaces, ObjetsCDE *objets);

/**
 * Cette fonction affiche la balle dans sa nouvelle position.
 *
 * Elle renvoie -1 en cas d'erreur.
 */
int afficheBalle (ObjetsAffichage *surfaces, ObjetsCDE *objets);


#endif
