/*

Fichier: ChargementAffichage.h

Auteur: Thibault Raffaillac <thibaultraffaillac@yahoo.fr>
Cr�� le: 01/07/07

Ce fichier contient les fonctions chargeant en m�moire les objets qui seront
affich�s dans le casse brique.

*/

#ifndef TRAF_CHARGEMENT_AFFICHAGE_H
#define TRAF_CHARGEMENT_AFFICHAGE_H

#include "Constantes.h"
#include <stdlib.h>
#include <time.h>
#include "Affichage.h"

/**
 * Cette fonction initialise la SDL, et enregistre l'adresse de la surface
 * principale dans le pointeur ecran.
 *
 * Elle renvoie -1 en cas d'erreur.
 */
int initSDL (ObjetsAffichage *surfaces);

/**
 * Cette fonction r�partit les t�ches pour la cr�ation des surfaces contenues
 * dans la structure objetsAffichage qui lui est donn�e.
 * Il y a simplement l'allocation de m�moire, puis le dessin dans la surface.
 *
 * Elle renvoie -1 en cas d'erreur.
 */
int creeObjetsAffichage (ObjetsAffichage *surfaces);

/**
 * Cette fonction dessine la balle � partir de l'adresse qui lui est donn�e, et
 * au format de pixel donn�.
 */
void dessineBalle (Uint32 *pointeur, SDL_PixelFormat *format);

/**
 * Cette fonction dessine la barre en position horizontale � partir de l'adresse
 * qui lui est donn�e, et au format de pixel donn�.
 */
void dessineBarre (Uint32 *pointeur, SDL_PixelFormat *format);

/*
Cette fonction dessine une inclinaison de la barre � gauche et � droite pour un
m�me angle.

arguments:
   _pointeurGauche: L'adresse du premier pixel de la surface penchant � gauche.
   _pointeurDroite: L'adresse du premier pixel de la surface penchant � droite.
   _pitch32Droite: cette valeur doit �tre [surfaceGauche->pitch / 4].
   _angle: L'angle d'inclinaison de la barre � dessiner.
   _l: La moiti� de la largeur de la surface (Pour acc�l�rer le dessin.).
   _h: La moiti� de la hauteur de la surface (Pour acc�l�rer le dessin.).
   _format: Le format des couleurs � dessiner.
*/
void dessineBarresInclinees (Uint32 *pointeurGauche, Uint32 *pointeurDroite, Uint16 pitch32Droite, double angle, int l, int h, double lint, double hint, SDL_PixelFormat *format);

/**
 * Cette fonction redessine la balle et les barres dans les surfaces.
 * Elle doit �tre appel�e si SDL_BlitSurface renvoie -2.
 *
 * Comme la fonction doit attendre pour r�cup�rer la m�moire vid�o, elle g�re
 * sommairement les �v�nements importants afin de ne pas bloquer le programme
 * ind�finiment.
 *
 * Elle renvoie -1 si l'utilisateur a d�cid� de quitter le programme avant que
 * la m�moire vid�o ait �t� r�cup�r�e.
 */
int redessineObjetsAffichage (ObjetsAffichage *surfaces);

/**
 * Cette fonction efface les surfaces de la structure ObjetsAffichage qui lui
 * est donn�e, et ferme la SDL.
 */
void quitteSDL (ObjetsAffichage *surfaces);

#endif
