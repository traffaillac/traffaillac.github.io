/*

Fichier: CollisionsDeplacementsEvenements.h

Auteur: Thibault Raffaillac <thibaultraffaillac@yahoo.fr>
Cr�� le: 04/07/07

Ce fichier contient les fonctions g�rant les collisions entre la balle et la
barre et entre la balle et les briques, et les fonctions g�rant les d�placements
et les �v�nements.

*/

#ifndef TRAF_COLLISIONS_DEPLACEMENTS_EVENEMENTS_H
#define TRAF_COLLISIONS_DEPLACEMENTS_EVENEMENTS_H

#include "Constantes.h"
#include <math.h>
#include "../../FonctionsUtiles/SDL_TemporisateurIntelligent.h"
#include "../../FonctionsUtiles/UtilitesVariees.h"
#include "Affichage.h"

/**
 * Cette fonction initialise la position des briques.
 */
void initObjetsCDE (ObjetsCDE *objets);

/**
 * Cette fonction est une seconde initialisation qui fixe les positions de la
 * balle, de la barre et les �tats des briques. Elle doit �tre appel�e chaque
 * fois qu'on recommence une partie.
 */
void reinitObjetsCDE (ObjetsCDE *objets);

/**
 * Cette fonction intercepte tous les �v�nements qui se sont produits pendant la
 * temporisation, et r�pond en cons�quence.
 *
 * Elle renvoie 1 si l'utilisateur veut quitter, 2 s'il veut recommencer une
 * partie, -1 en cas d'erreur, et 0 sinon.
 */
int gereEvenements (ObjetsAffichage *surfaces, ObjetsCDE *objets, SDL_Tempo *tempo);

/**
 * Cette fonction fait se d�placer la barre � sa nouvelle position et pousse la
 * balle si besoin est.
 */
void deplacementBarre (ObjetsCDE *objets, int nouvAbscisse);

/**
 * Cette fonction fait avancer la balle et teste les collisions entre elle et la
 * barre et les briques.
 *
 * Elle renvoie -1 en cas d'erreur, 1 si l'utilisateur a gagn�, 2 s'il a perdu,
 * et 0 sinon.
 */
int deplacementEtCollisions (ObjetsAffichage *surfaces, ObjetsSon *sons, ObjetsCDE *objets);

/**
 * Cette fonction fournit l'angle de la barre � partir de sa vitesse.
 */
double calculeAngleBarre (double vitesse);

/**
 * Cette fonction indique l'index de la barre inclin�e � afficher en fonction de
 * l'angle de la barre.
 *
 * 0: barre horizontale.
 * Les index positifs d�signent la barre penchant � gauche, et ceux n�gatifs la
 * barre penchant � droite.
 */
int indexAngle (double angle);

/**
 * Cette fonction fournit l'abscisse de la barre � partir de l'abscisse du
 * curseur sur l'�cran.
 */
int abscisseBarre (int x);

/**
 * Fonction temporaire.
 */
void pause (void);

#endif
