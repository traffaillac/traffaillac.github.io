/*

Fichier: ChargementAffichage.c

Auteur: Thibault Raffaillac <thibaultraffaillac@yahoo.fr>
Cr�� le: 01/07/07

Ce fichier contient les fonctions chargeant en m�moire les objets qui seront
affich�s dans le casse brique.

*/

#include "ChargementAffichage.h"

int initSDL (ObjetsAffichage *surfaces)
{
   /* On d�marre la SDL. */
   if (SDL_Init (SDL_INIT_VIDEO | SDL_INIT_TIMER) < 0) {
      fprintf (stderr, "Echec a l'initialisation de la SDL: %s\n", SDL_GetError ());
      return (-1);
   }
   
   /* On cr�e la surface principale, de taille fixe, et qui ne sera pas chang�e. */
   surfaces->ecran = SDL_SetVideoMode (800, 600, 32, SDL_SWSURFACE | SDL_FULLSCREEN);
   if (surfaces->ecran == NULL) {
      fprintf (stderr, "Impossible de definir le mode video 800x600x32: %s\n", SDL_GetError ());
      return (-1);
   }
   
   /* On signale les �v�nements qu'on ne souhaite pas recevoir. */
   SDL_EventState(SDL_ACTIVEEVENT, SDL_IGNORE);
   SDL_EventState(SDL_KEYUP, SDL_IGNORE);
   SDL_EventState(SDL_MOUSEBUTTONUP, SDL_IGNORE);
   SDL_EventState(SDL_JOYAXISMOTION, SDL_IGNORE);
   SDL_EventState(SDL_JOYBALLMOTION, SDL_IGNORE);
   SDL_EventState(SDL_JOYHATMOTION, SDL_IGNORE);
   SDL_EventState(SDL_JOYBUTTONDOWN, SDL_IGNORE);
   SDL_EventState(SDL_JOYBUTTONUP, SDL_IGNORE);
   SDL_EventState(SDL_SYSWMEVENT, SDL_IGNORE);
   SDL_EventState(SDL_VIDEORESIZE, SDL_IGNORE);
   SDL_EventState(SDL_VIDEOEXPOSE, SDL_IGNORE);
   SDL_EventState(SDL_USEREVENT, SDL_IGNORE);
   
   /* On fait dispara�tre le curseur. */
   SDL_ShowCursor (SDL_DISABLE);
   
   /* On initialise le g�n�rateur de nombres al�atoires (pour cr�er les couleurs
   des briques et pour le l�cher de balle.). */
   srand (time (NULL));
   
   return (0);
}

int creeObjetsAffichage (ObjetsAffichage *surfaces)
{
   //D�claration des variables
   int l, h, i;
#if SDL_BYTEORDER == SDL_BIG_ENDIAN
   Uint32 Rmask = 0xFF000000, Gmask = 0x00FF0000, Bmask = 0x0000FF00, Amask = 0x000000FF;
#else
   Uint32 Rmask = 0x000000FF, Gmask = 0x0000FF00, Bmask = 0x00FF0000, Amask = 0xFF000000;
#endif
   double angle = 0.0F, lint, hint;
   
   /* On cr�e les surfaces simples d'abord, et on v�rifie qu'elles ont bien �t� allou�es. */
   surfaces->balle = SDL_CreateRGBSurface (SDL_HWSURFACE | SDL_SRCALPHA, 2 * RAYON_BALLE + 1, 2 * RAYON_BALLE + 1, 32, Rmask, Gmask, Bmask, Amask);
   surfaces->barre = SDL_CreateRGBSurface (SDL_HWSURFACE | SDL_SRCALPHA, 2 * MOITIE_LARGEUR_BARRE + 1, 2 * MOITIE_HAUTEUR_BARRE + 1, 32, Rmask, Gmask, Bmask, Amask);
   if ((surfaces->balle == NULL) || (surfaces->barre == NULL)) {
      fprintf (stderr, "Echec lors de l'allocation des surfaces: %s\n", SDL_GetError ());
      return (-1);
   }
   
   /* On cr�e les surfaces contenant les barres inclin�es, et on les dessine du
   m�me coup. */
   for (i = 0; i < NOMBRE_INCLINAISONS; i++) {
      
      /* Initialisation des variables. */
      angle += LIMITE_ANGLE / NOMBRE_INCLINAISONS;
      lint = (MOITIE_LARGEUR_BARRE - MOITIE_HAUTEUR_BARRE) * cos (angle);
      l = (int)ceil(lint) + MOITIE_HAUTEUR_BARRE;
      hint = (MOITIE_LARGEUR_BARRE - MOITIE_HAUTEUR_BARRE) * sin (angle);
      h = (int)ceil(hint) + MOITIE_HAUTEUR_BARRE;
      
      /* Allocation des surfaces, et stockage de l'angle pour chacune. */
      surfaces->barreGauche[i] = SDL_CreateRGBSurface (SDL_HWSURFACE | SDL_SRCALPHA, 2*l+1, 2*h+1, 32, Rmask, Gmask, Bmask, Amask);
      surfaces->barreDroite[i] = SDL_CreateRGBSurface (SDL_HWSURFACE | SDL_SRCALPHA, 2*l+1, 2*h+1, 32, Rmask, Gmask, Bmask, Amask);
      if ((surfaces->barreGauche[i] == NULL) || (surfaces->barreDroite[i] == NULL)) {
         fprintf (stderr, "Echec lors de l'allocation des surfaces: %s\n", SDL_GetError ());
         return (-1);
      }
      
      /* On dessine enfin dans les surfaces. */
      if (SDL_MUSTLOCK (surfaces->barreGauche[i])) {
         if (SDL_LockSurface (surfaces->barreGauche[i]) < 0) {
            fprintf (stderr, "Impossible de verrouiller la surface de dessin de la barre inclinee: %s\n", SDL_GetError ());
            return (-1);
         }
      }
      if (SDL_MUSTLOCK (surfaces->barreDroite[i])) {
         if (SDL_LockSurface (surfaces->barreDroite[i]) < 0) {
            fprintf (stderr, "Impossible de verrouiller la surface de dessin de la barre inclinee: %s\n", SDL_GetError ());
            return (-1);
         }
      }
      dessineBarresInclinees ((Uint32 *)surfaces->barreGauche[i]->pixels, (Uint32 *)surfaces->barreDroite[i]->pixels, surfaces->barreDroite[i]->pitch / 4, angle, l, h, lint, hint, surfaces->barre->format);
      if (SDL_MUSTLOCK (surfaces->barreGauche[i])) {
         SDL_UnlockSurface (surfaces->barreGauche[i]);
      }
      if (SDL_MUSTLOCK (surfaces->barreDroite[i])) {
         SDL_UnlockSurface (surfaces->barreDroite[i]);
      }
   }
   
   /* On dessine la ba-balle. :) */
   if (SDL_MUSTLOCK (surfaces->balle)) {
      if (SDL_LockSurface (surfaces->balle) < 0) {
         fprintf (stderr, "Impossible de verrouiller la surface de dessin de la balle: %s\n", SDL_GetError ());
         return (-1);
      }
   }
   dessineBalle ((Uint32 *)surfaces->balle->pixels, surfaces->balle->format);
   if (SDL_MUSTLOCK (surfaces->balle)) {
      SDL_UnlockSurface (surfaces->balle);
   }
   
   /* On dessine la ba-barre. :D */
   if (SDL_MUSTLOCK (surfaces->barre)) {
      if (SDL_LockSurface (surfaces->barre) < 0) {
         fprintf (stderr, "Impossible de verrouiller la surface de dessin de la barre: %s\n", SDL_GetError ());
         return (-1);
      }
   }
   dessineBarre ((Uint32 *)surfaces->barre->pixels, surfaces->barre->format);
   if (SDL_MUSTLOCK (surfaces->barre)) {
      SDL_UnlockSurface (surfaces->barre);
   }
   
   /* Enfin, on calcule les valeurs des couleurs � r�utiliser, .. */
   surfaces->couleurBlanc = SDL_MapRGB (surfaces->ecran->format, 255, 255, 255);
   surfaces->couleurNoir = SDL_MapRGB (surfaces->ecran->format, 0, 0, 0);
   
   /* .. on indique la taille unique des briques qu'on va utiliser, .. */
   surfaces->cadresActualisation[2].w = LARGEUR_BRIQUE;
   surfaces->cadresActualisation[2].h = HAUTEUR_BRIQUE;
   surfaces->cadresActualisation[3].w = LARGEUR_BRIQUE;
   surfaces->cadresActualisation[3].h = HAUTEUR_BRIQUE;
   
   /* .. et on indique la taille de la balle. */
   surfaces->cadresEffacement[1].w = RAYON_BALLE;
   surfaces->cadresEffacement[1].h = RAYON_BALLE;
   
   return (0);
}

void dessineBalle (Uint32 *pointeur, SDL_PixelFormat *format)
{
   //D�claration des variables
   int x, y;
   float distance;
   Uint32 blancOpaque, blancTransparent;
   
   /* Et on dessine... */
   blancOpaque = SDL_MapRGBA (format, 255, 255, 255, 255);
   blancTransparent = SDL_MapRGBA (format, 255, 255, 255, 0);
   for (y = -RAYON_BALLE; y <= RAYON_BALLE; y++) {
      for (x = -RAYON_BALLE; x <= RAYON_BALLE; x++) {
         distance = sqrtf ((float)(x*x+y*y));
         if (distance <= (float)RAYON_BALLE - 0.5) {
            *pointeur = blancOpaque;
         } else if (distance >= (float)RAYON_BALLE + 0.5) {
            *pointeur = blancTransparent;
         } else {
            *pointeur = SDL_MapRGBA (format, 255, 255, 255, 254 - (int)((distance - (float)RAYON_BALLE - 0.5) * 255));
         }
         pointeur++;
      }
   }
   
   return;
}

void dessineBarre (Uint32 *pointeur, SDL_PixelFormat *format)
{
   //D�claration des variables
   int x, y;
   float distance;
   Uint32 grisOpaque, grisDemiTransparent, grisTransparent;
   
   /* Et on dessine... */
   grisOpaque = SDL_MapRGBA (format, NIVEAU_GRIS_BARRE, NIVEAU_GRIS_BARRE, NIVEAU_GRIS_BARRE, 255);
   grisDemiTransparent = SDL_MapRGBA (format, NIVEAU_GRIS_BARRE, NIVEAU_GRIS_BARRE, NIVEAU_GRIS_BARRE, 128);
   grisTransparent = SDL_MapRGBA (format, NIVEAU_GRIS_BARRE, NIVEAU_GRIS_BARRE, NIVEAU_GRIS_BARRE, 0);
   for (y = -MOITIE_HAUTEUR_BARRE; y <= MOITIE_HAUTEUR_BARRE; y++) {
      for (x = -MOITIE_HAUTEUR_BARRE; x < 0; x++) {
         distance = sqrtf ((float)(x*x+y*y));
         if (distance <= (float)MOITIE_HAUTEUR_BARRE - 0.5) {
            *pointeur = grisOpaque;
         } else if (distance >= (float)(MOITIE_HAUTEUR_BARRE + 0.5)) {
            *pointeur = grisTransparent;
         } else {
            *pointeur = SDL_MapRGBA (format, NIVEAU_GRIS_BARRE, NIVEAU_GRIS_BARRE, NIVEAU_GRIS_BARRE, 254 - (int)((distance - (float)MOITIE_HAUTEUR_BARRE - 0.5) * 255));
         }
         pointeur++;
      }
      if (abs (y) == MOITIE_HAUTEUR_BARRE) {
         for ( ; x <= 2 * (MOITIE_LARGEUR_BARRE - MOITIE_HAUTEUR_BARRE); x++) {
            *pointeur = grisDemiTransparent;
            pointeur++;
         }
      } else {
         for ( ; x <= 2 * (MOITIE_LARGEUR_BARRE - MOITIE_HAUTEUR_BARRE); x++) {
            *pointeur = grisOpaque;
            pointeur++;
         }
      }
      for (x = 1; x <= MOITIE_HAUTEUR_BARRE; x++) {
         distance = sqrtf ((float)(x*x+y*y));
         if (distance <= (float)MOITIE_HAUTEUR_BARRE - 0.5) {
            *pointeur = grisOpaque;
         } else if (distance >= (float)(MOITIE_HAUTEUR_BARRE + 0.5)) {
            *pointeur = grisTransparent;
         } else {
            *pointeur = SDL_MapRGBA (format, NIVEAU_GRIS_BARRE, NIVEAU_GRIS_BARRE, NIVEAU_GRIS_BARRE, 254 - (int)((distance - (float)MOITIE_HAUTEUR_BARRE - 0.5) * 255));
         }
         pointeur++;
      }
   }
   
   return;
}

void dessineBarresInclinees (Uint32 *pointeurGauche, Uint32 *pointeurDroite, Uint16 pitch32Droite, double angle, int l, int h, double lint, double hint, SDL_PixelFormat *format)
{
   //D�claration des variables
   double x1, x2, y1, y2;
   float distance;
   Uint32 grisOpaque, grisTransparent, *pointeur = pointeurGauche;
   
   /* On se lance... */
   grisOpaque = SDL_MapRGBA (format, NIVEAU_GRIS_BARRE, NIVEAU_GRIS_BARRE, NIVEAU_GRIS_BARRE, 255);
   grisTransparent = SDL_MapRGBA (format, NIVEAU_GRIS_BARRE, NIVEAU_GRIS_BARRE, NIVEAU_GRIS_BARRE, 0);
   pointeurDroite += pitch32Droite - 1;
   y1 = -h - hint;
   y2 = -h + hint;
   do {
      x1 = -l + lint;
      x2 = -l - lint;
      do {
         if ((double)x1 < ((double)y1) * tan (angle)) {
            distance = sqrtf ((float)(x1*x1+y1*y1));
         } else if ((double)x2 > ((double)y2) * tan (angle)) {
            distance = sqrtf ((float)(x2*x2+y2*y2));
         } else {
            distance = fabsf ((float)x1 * sinf (angle) + (float)y1 * cosf (angle));
         }
         if (distance <= (float)MOITIE_HAUTEUR_BARRE - 0.5) {
            *pointeurGauche = grisOpaque;
         } else if (distance >= (float)MOITIE_HAUTEUR_BARRE + 0.5) {
            *pointeurGauche = grisTransparent;
         } else {
            *pointeurGauche = SDL_MapRGBA (format, NIVEAU_GRIS_BARRE, NIVEAU_GRIS_BARRE, NIVEAU_GRIS_BARRE, 1 - (int)((distance - (float)MOITIE_HAUTEUR_BARRE - 0.5) * 254));
         }
         *pointeurDroite = *pointeurGauche;
         pointeurGauche++;
         pointeurDroite--;
         x1++;
         x2++;
      } while (x2 < MOITIE_HAUTEUR_BARRE + 1);
      pointeurDroite += 2 * pitch32Droite;
      y1++;
      y2++;
   } while (y1 < MOITIE_HAUTEUR_BARRE + 1);
   
   return;
}

/* Fonction priv�e. */
int tenteVerrou (SDL_Surface *surface)
{
   //D�claration des variables
   SDL_Event event;
   
   /* On temporise et on v�rifie les �v�nements qui arrivent. */
   while (SDL_LockSurface (surface) < 0) {
      SDL_Delay (100);
      while (SDL_PollEvent (&event)) {
         if ((event.type == SDL_QUIT) || ((event.type == SDL_KEYDOWN) && (event.key.keysym.sym == SDLK_ESCAPE))) {
            return (-1);
         }
      }
   }
   
   /* Ouf... */
   return (0);
}

int redessineObjetsAffichage (ObjetsAffichage *surfaces)
{
   //D�claration des variables
   int i;
   double angle = 0.0F;
   
   /* On commence par redessiner la balle. */
   if (SDL_MUSTLOCK (surfaces->balle)) {
      if (tenteVerrou (surfaces->balle) < 0) {
         return (-1);
      }
   }
   dessineBalle ((Uint32 *)surfaces->balle->pixels, surfaces->balle->format);
   if (SDL_MUSTLOCK (surfaces->balle)) {
      SDL_UnlockSurface (surfaces->balle);
   }
   
   /* On redessine la barre. */
   if (SDL_MUSTLOCK (surfaces->barre)) {
      if (tenteVerrou (surfaces->barre) < 0) {
         return (-1);
      }
   }
   dessineBarre ((Uint32 *)surfaces->barre->pixels, surfaces->barre->format);
   if (SDL_MUSTLOCK (surfaces->barre)) {
      SDL_UnlockSurface (surfaces->barre);
   }
   
   /* On redessine enfin les inclinaisons de la barre. */
   for (i = 0; i < NOMBRE_INCLINAISONS; i++) {
      angle += LIMITE_ANGLE / NOMBRE_INCLINAISONS;
      if (SDL_MUSTLOCK (surfaces->barreGauche[i])) {
         if (tenteVerrou (surfaces->barreGauche[i]) < 0) {
            return (-1);
         }
      }
      if (SDL_MUSTLOCK (surfaces->barreDroite[i])) {
         if (tenteVerrou (surfaces->barreDroite[i]) < 0) {
            return (-1);
         }
      }
      dessineBarresInclinees ((Uint32 *)surfaces->barreGauche[i]->pixels, (Uint32 *)surfaces->barreDroite[i]->pixels, surfaces->barreDroite[i]->pitch / 4, angle, surfaces->barreGauche[i]->w/2, surfaces->barreGauche[i]->h/2, (MOITIE_LARGEUR_BARRE - MOITIE_HAUTEUR_BARRE) * cos (angle), (MOITIE_LARGEUR_BARRE - MOITIE_HAUTEUR_BARRE) * sin (angle), surfaces->barre->format);
      if (SDL_MUSTLOCK (surfaces->barreGauche[i])) {
         SDL_UnlockSurface (surfaces->barreGauche[i]);
      }
      if (SDL_MUSTLOCK (surfaces->barreDroite[i])) {
         SDL_UnlockSurface (surfaces->barreDroite[i]);
      }
   }
   
   return (0);
}

void quitteSDL (ObjetsAffichage *surfaces)
{
   //D�claration des variables
   int i;
   
   /* On efface toutes les surfaces, et on quitte la SDL. */
   SDL_FreeSurface (surfaces->balle);
   SDL_FreeSurface (surfaces->barre);
   for (i = 0; i < NOMBRE_INCLINAISONS; i++) {
      SDL_FreeSurface (surfaces->barreGauche[i]);
      SDL_FreeSurface (surfaces->barreDroite[i]);
   }
   SDL_Quit ();
   
   return;
}
