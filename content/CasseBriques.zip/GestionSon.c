/*

Fichier: GestionSon.c

Auteur: Thibault Raffaillac <thibaultraffaillac@yahoo.fr>
Cr�� le: 04/07/07

Ce fichier contient toutes les fonctions ayant rapport au son dans le jeu.

*/

#include "GestionSon.h"

static char nomRebondBarre[] = "sonRebondBarre.wav";
static char nomRebondBrique[] = "sonRebondBrique.wav";
static char nomMusiqueFond[] = "musiqueFond.mp3";

int initFMOD (void)
{
   /* On d�marre FMOD. */
   if (FSOUND_Init (44100, 32, 0) == 0) {
      fprintf (stderr, "Echec a l'initialisation de FMOD: %s\n", FMOD_ErrorString (FSOUND_GetError ()));
      return (-1);
   }
   
   /* R�glage du volume. */
   FSOUND_SetSFXMasterVolume (128);
   
   return (0);
}

/* Fonction priv�e. */
int gereErreurChargementSon (char *nomSon)
{
   //D�claration des variables
   int codeErreur = FSOUND_GetError (), retour;
   FILE *directionMessageErreur = NULL;
   
   /* On d�termine d'abord la gravit� de l'erreur pour le programme. */
   switch (codeErreur) {
   case FMOD_ERR_NONE:
   case FMOD_ERR_FILE_NOTFOUND:
   case FMOD_ERR_FILE_FORMAT:
   case FMOD_ERR_FILE_BAD:
   case FMOD_ERR_VERSION:
      
      /* Le programme peut continuer � tourner apr�s. */
      retour = 0;
      directionMessageErreur = stdout;
      break;
      
   default:
      
      /* Le programme doit s'arr�ter. */
      retour = -1;
      directionMessageErreur = stderr;
      break;
   }
   
   /* On signale enfin le probl�me. */
   fprintf (directionMessageErreur, "Impossible de lire le fichier %s: %s\n", nomSon, FMOD_ErrorString (codeErreur));
   
   return (retour);
}

int creeObjetsSon (ObjetsSon *sons)
{
   //D�claration des variables
   int retour = 0;
   
   /* Chargement des sons. */
   sons->rebondBarre = FSOUND_Sample_Load (FSOUND_FREE, nomRebondBarre, 0, 0, 0);
   if (sons->rebondBarre == NULL) {
      retour = gereErreurChargementSon (nomRebondBarre);
   }
   sons->rebondBrique = FSOUND_Sample_Load (FSOUND_FREE, nomRebondBrique, 0, 0, 0);
   if (sons->rebondBarre == NULL) {
      retour |= gereErreurChargementSon (nomRebondBrique);
   }
      /* Cette fonction ne cr�e pas d'erreur, � cause de l'option NONBLOCKING. */
   sons->musiqueFond = FSOUND_Stream_Open (nomMusiqueFond, FSOUND_NONBLOCKING, 0, 0);
   sons->canal = -1;
   
   return (retour);
}

/* Fonction priv�e. */
F_CALLBACKAPI signed char rejoueMusique (FSOUND_STREAM *stream, void *buff, int len, void *userdata)
{
   int *canal = (int *)userdata;
   *canal = FSOUND_Stream_Play (*canal, stream);
   return TRUE;
}

int joueMusiqueFond (ObjetsSon *sons)
{
   /* Le test � effectuer pour savoir si la musique n'a pas d�j� commenc�. */
   if (sons->canal < 0) {
      
      /* On teste l'ouverture correcte du fichier. */
      if (FSOUND_Stream_GetOpenState (sons->musiqueFond) == -3) {
         sons->canal = 0x7FFF;
         return (gereErreurChargementSon (nomMusiqueFond));
      }
         
      sons->canal = FSOUND_Stream_Play (FSOUND_FREE, sons->musiqueFond);
      if (sons->canal >= 0) {
         FSOUND_Stream_SetEndCallback (sons->musiqueFond, rejoueMusique, &(sons->canal));
      }
   }
   
   return (0);
}

void joueSonRebondBrique (ObjetsSon *sons)
{
   /* On ne se pr�occupe pas des �ventuelles erreurs rencontr�es par le programme. */
   if (sons->rebondBrique != NULL) {
      FSOUND_PlaySound (FSOUND_FREE, sons->rebondBrique);
   }
   
   return;
}

void joueSonRebondBarre (ObjetsSon *sons)
{
   /* On ne se pr�occupe pas des �ventuelles erreurs rencontr�es par le programme. */
   if (sons->rebondBarre != NULL) {
      FSOUND_PlaySound (FSOUND_FREE, sons->rebondBarre);
   }
   
   return;
}

void quitteFMOD (ObjetsSon *sons)
{
   //D�claration des variables
   int continuer = 10;
   
   /* On efface d'abord les samples. */
   if (sons->rebondBarre == NULL) {
      FSOUND_Sample_Free (sons->rebondBarre);
   }
   if (sons->rebondBrique == NULL) {
      FSOUND_Sample_Free (sons->rebondBrique);
   }
   
   /* On ferme la musique de fond. */
   if ((sons->canal >= 0) && (sons->canal != 0x7FFF)) {
      FSOUND_Stream_Stop (sons->musiqueFond);
   }
   while (FSOUND_Stream_Close (sons->musiqueFond) == FALSE) {
      if (continuer == 0) {
         fprintf (stderr, "Echec � la fermeture de %s: %s\n", nomMusiqueFond, FMOD_ErrorString(FSOUND_GetError ()));
         break;
      }
      continuer--;
      sleep (100);
   }
   
   /* Et on quitte FMOD. */
   FSOUND_Close ();
   
   return;
}
