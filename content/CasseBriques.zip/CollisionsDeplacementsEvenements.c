/*

Fichier: CollisionsDeplacementsEvenements.c

Auteur: Thibault Raffaillac <thibaultraffaillac@yahoo.fr>
Cr�� le: 04/07/07

Ce fichier contient les fonctions g�rant les collisions entre la balle et la
barre et entre la balle et les briques, et les fonctions g�rant les d�placements
et les �v�nements.

*/

#include "CollisionsDeplacementsEvenements.h"

void initObjetsCDE (ObjetsCDE *objets)
{
   //D�claration des variables
   int x, y, indexTableau = 0;
   
   /* Remplissage des coordonn�es des briques. */
   for (y = HAUTEUR_BORD_HAUT; y < 480-NOMBRE_HAUTEURS_INTER_BRIQUES_AUX_BORDS*INTER_BRIQUES_Y; y += HAUTEUR_BRIQUE+INTER_BRIQUES_Y) {
      for (x = LARGEUR_BORD_GAUCHE; x < 800-NOMBRE_LARGEURS_INTER_BRIQUES_AUX_BORDS*INTER_BRIQUES_X; x += LARGEUR_BRIQUE+INTER_BRIQUES_X) {
         objets->briques[indexTableau].x = x;
         objets->briques[indexTableau].y = y;
         indexTableau++;
      }
   }
   
   return;
}

void reinitObjetsCDE (ObjetsCDE *objets)
{
   //D�claration des variables
   int x;
   
   //Initialisation des variables
   SDL_GetMouseState (&x, NULL);

   /* On commence par la barre.
   L'angle de la barre ne peut pas �tre connu car sa vitesse ne peut pas �tre
   calcul�e (On ne sait pas par rapport � quel instant le mouvement relatif de
   la souris s'est fait.). */
   objets->angleBarre = 0.0;
   objets->barreX = abscisseBarre (x);
   
   /* Puis la balle. */
   objets->balle.x = (double)objets->barreX;
   objets->balle.y = (double)(ORDONNEE_BARRE - (MOITIE_HAUTEUR_BARRE*3)/2 - (RAYON_BALLE*3)/2);
   objets->retientBalle = 1;
   
   /* Enfin, on fixe les �tats des briques � 1. */
   for (x = 0; x < NOMBRE_BRIQUES; x++) {
      objets->etatBriques[x] = 1;
   }
   objets->briquesRestantes = NOMBRE_BRIQUES;
   
   return;
}

/* Fonction priv�e. */
double doubleAleatoire (double absAngleLimite)
{
   return ((rand () * 2 * absAngleLimite) / RAND_MAX - absAngleLimite);
}

int gereEvenements (ObjetsAffichage *surfaces, ObjetsCDE *objets, SDL_Tempo *tempo)
{
   //D�claration des variables
   SDL_Event event;
   
   /* On mesure tout d'abord l'�cart de temps par rapport au dernier appel de
   cette fonction. */
   objets->ecartTemps = ((tempo->dernierRetour == 1) || (tempo->dateDernierRetourReel - objets->tempsPrecedent >= INTERVALLE_TEMPS+20)) ? INTERVALLE_TEMPS : tempo->dateDernierRetourReel - objets->tempsPrecedent;
   objets->tempsPrecedent = tempo->dateDernierRetourReel;
   
   /* Puis on s'occupe des �v�nements. */
   while (SDL_PollEvent (&event)) {
      switch (event.type) {
      
      /* Le clavier... La touche [ECHAP] met fin au programme, et la touche
      [ENTREE] recommence une partie. */
      case SDL_KEYDOWN:
         switch (event.key.keysym.sym) {
         case SDLK_ESCAPE:
            return (1);
            break;
         case SDLK_RETURN:
            return (2);
            break;
         case SDLK_SPACE:
            fprintf (stdout, "balle=[%lf, %lf]\n", objets->balle.x, objets->balle.y);
            break;
         default:
            break;
         }
         break;
      
      /* Le clic de souris lib�re la balle si elle �tait retenue. */
      case SDL_MOUSEBUTTONDOWN:
         if (objets->retientBalle != 0) {
            objets->retientBalle = 0;
            
            /* La balle est l�ch�e avec un angle semi-al�atoire. */
            objets->angleBalle = M_PI_2 + objets->angleBarre + doubleAleatoire (ANGLE_CONE_HASARD);
         }
         break;
      
      /* Le mouvement de la souris... Il fait s'incliner la barre, et il faut
      v�rifier que celle-ci ne rentre pas dans la balle. */
      case SDL_MOUSEMOTION:
         
         /* On actualise l'�tat de la barre, puis on la fait se d�placer. */
         effaceBarre (surfaces);
         surfaces->barreChangee = 1;
         deplacementBarre (objets, abscisseBarre (event.motion.x));
         break;
      
      case SDL_QUIT:
         return (1);
         break;
      default:
         break;
      }
   }
   
   /* Si la vitesse de la barre est nulle, on pense � la mettre � l'horizontale. */
   if ((surfaces->barreChangee == 0) && !doubleNul (objets->angleBarre, TOLERANCE_ANNULATION)) {
      effaceBarre (surfaces);
      surfaces->barreChangee = 1;
      deplacementBarre (objets, objets->barreX);
   } else if (surfaces->aToucheBarre) {
      /* A l'image pr�c�dente, la balle est entr�e dans la zone de collisions de la barre. */
      effaceBarre (surfaces);
      surfaces->barreChangee = 1;
      surfaces->aToucheBarre = 0;
   }
   
   return (0);
}

/* Cette macro est utilis�e dans la fonction deplacementEtCollisions et la
fonction deplacementBarre uniquement. */
#define CARRE(x) ((x)*(x))

/* Fonction priv�e utilis�e dans les fonctions deplacementEtCollisions et deplacementBarre.
Elle renvoie l'angle du point 1 au point 2 dans le plan, en partant de angleDepart. */
double angleDroiteOrientee (dPointXY *point1, dPointXY *point2, double angleDepart)
{
   //D�claration des variables
   double angle;
   
   /* On calcule d'abord l'angle. */
   if (doubleNul (point2->x - point1->x, TOLERANCE_ANNULATION)) {
      angle = M_PI_2 + (((point2->y - point1->y) > 0) ? M_PI : 0);
   } else {
      angle = atan ((point1->y - point2->y) / (point2->x - point1->x)) + (((point2->x - point1->x) > 0) ? 0 : M_PI);
   }
   
   /* On renvoie l'angle depuis l'angle de d�part choisi. */
   return (fmod (angle - angleDepart, 2*M_PI) + angleDepart);
}

/* Fonction priv�e utilis�e dans la fonction deplacementBarre.
Elle renvoie le coefficient de rencontre du cercle sur le segment, et 2 s'il ne
le coupe pas. */
double cercleCoupeSegment (dPointXY *centre, int rayon, dPointXY *point1, dPointXY *point2, dPointXY *resultat)
{
   //D�claration des variables
   double a, b, c, d, e, delta, coeffRencontre1, coeffRencontre2, dtemp;
   
   /* On calcule d'abord les coefficients de la droite. */
   a = (point1->y - point2->y) / (point1->x - point2->x);
   b = point1->y - a * point1->x;
   
   /* Puis on calcule les coefficients de l'�quation du second ordre � r�soudre. */
   c = CARRE (a) + 1;
   d = 2 * (a * (b - centre->y) - centre->x);
   e = CARRE (b - centre->y) + CARRE (centre->x) - CARRE (rayon);
   
   delta = CARRE (d) - 4 * c * e;
   /* Les solutions complexes ne nous int�ressent pas :D */
   if (delta < 0) {
      return (2);
   }
   
   /* On calcule la/les solutions, et on choisit le bon r�sultat. */
   resultat->x = (-d - sqrt (delta)) / (2 * c);
   dtemp = (-d + sqrt (delta)) / (2 * c);
   coeffRencontre1 = (point1->x - resultat->x) / (point1->x - point2->x);
   coeffRencontre2 = (point1->x - dtemp) / (point1->x - point2->x);
   if ((coeffRencontre1 >= 0) && (coeffRencontre1 <= 1)) {
      if ((coeffRencontre2 >= 0) && (coeffRencontre2 <= 1) && (coeffRencontre2 < coeffRencontre1)) {
         resultat->x = dtemp;
         coeffRencontre1 = coeffRencontre2;
      }
      resultat->y = a * resultat->x + b;
      return (coeffRencontre1);
   } else {
      if ((coeffRencontre2 >= 0) && (coeffRencontre2 <= 1)) {
         resultat->x = dtemp;
         resultat->y = a * dtemp + b;
         return (coeffRencontre2);
      } else {
         return (2);
      }
   }
}

/* Fonction priv�e utilis�e dans la fonction deplacementBarre.
Elle renvoie 1 s'il y a intersection, et 0 sinon. */
int intersectionDroiteCercle (dPointXY *point1, dPointXY *point2, dPointXY *centre, int rayon, dPointXY *resultat1, dPointXY *resultat2)
{
   //D�claration des variables
   double a, b, c, d, e, delta;
   
   /* On calcule les coefficients. */
   a = (point1->y - point2->y) / (point1->x - point2->x);
   b = point1->y - a * point1->x;
   c = CARRE (a) + 1;
   d = 2 * (a * (b - centre->y) - centre->x);
   e = CARRE (b - centre->y) + CARRE (centre->x) - CARRE (rayon);
   delta = CARRE (d) - 4 * c * e;
   if (delta < 0) {
      return (0);
   }
   
   /* On calcule enfin les coordonn�es des deux solutions. */
   resultat1->x = (-d - sqrt (delta)) / (2 * c);
   resultat1->y = a * resultat1->x + b;
   resultat2->x = (-d + sqrt (delta)) / (2 * c);
   resultat2->y = a * resultat2->x + b;
   
   return (1);
}

/* Fonction priv�e utilis�e dans la fonction deplacementBarre.
Elle renvoie la distance n�cessaire pour sortir le cercle de la droite dans la
direction indiqu�e, et -1 si le cercle ne coupera pas la droite.
/!\ : Faire que lorsque -1 est renvoy�, coupe soit fix� � 0. */
double distanceCercleHorsDroite (dPointXY *centre, int rayon, double angle, dPointXY *point1, dPointXY *point2, int *cercleRencontreDroite)
{
   //D�claration des variables
   double a1, b1, a2, b2, coeffRencontre1, coeffRencontre2, dtemp;
   dPointXY point;
   
   /* On calcule d'abord les coefficients des droites. */
   a1 = -cos (angle) / sin (angle);
   b1 = centre->x - centre->y * a1;
   a2 = (point2->y - point1->y) / (point2->x - point1->x);
   b2 = point1->y - a2 * point1->x;
   
   /* On calcule ensuite les deux ordonn�es solutions, et on choisit la bonne. */
   point.y = (a2 * b1 + b2 - rayon * sqrt (1 + CARRE (a2))) / (1 - a1 * a2);
   coeffRencontre1 = -(point.y - centre->y) / (sin (angle));
   dtemp = (a2 * b1 + b2 + rayon * sqrt (1 + CARRE (a2))) / (1 - a1 * a2);
   coeffRencontre2 = -(dtemp - centre->y) / (sin (angle));
   if (coeffRencontre1 > 0) {
      if (coeffRencontre2 > coeffRencontre1) {
         point.y = dtemp;
      }
   } else {
      if (coeffRencontre2 > 0) {
         point.y = dtemp;
      } else {
         *cercleRencontreDroite = 0;
         return (-1);
      }
   }
   point.x = a1 * point.y + b1;
   
   /* Maintenant qu'on a le bon point, on calcule la position du point
   d'intersection du cercle centr� en ce point et coupant la droite. */
   dtemp = -(2 * (a2 * (b2 - point.y) - point.x)) / (2 * (1 + CARRE (a2)));
   
   coeffRencontre1 = (point1->x - dtemp) / (point1->x - point2->x);
   *cercleRencontreDroite = ((coeffRencontre1 >= 0) && (coeffRencontre1 <= 1)) ? 1 : 0;
   
   return (sqrt (CARRE (point.x - centre->x) + CARRE (point.y - centre->y)));
}

/* Fonction priv�e utilis�e dans la fonction deplacementBarre. */
double distanceCercleHorsPoint (dPointXY *centre, int rayon, double angle, dPointXY *point)
{
   //D�claration des variables
   double a, b, c, d, e, delta, coeffRencontre1, coeffRencontre2, dtemp;
   dPointXY resultat;
   
   /* On calcule les coefficients de la droite sur laquelle circule le centre. */
   a = -cos (angle) / sin (angle);
   b = centre->x - centre->y * a;
   c = CARRE (a) + 1;
   d = 2 * (a * (b - point->x) - point->y);
   e = CARRE (b - point->x) + CARRE (point->y) - CARRE (rayon);
   
   /* On calcule les deux ordonn�es solutions, et on choisit la bonne :) */
   delta = CARRE (d) - 4 * c * e;
   resultat.y = (-d - sqrt (delta)) / (2 * c);
   coeffRencontre1 = (resultat.y - centre->y) / (sin (angle));
   dtemp = (-d + sqrt (delta)) / (2 * c);
   coeffRencontre2 = (dtemp - centre->y) / (sin (angle));
   if (coeffRencontre2 > coeffRencontre1) {
      resultat.y = dtemp;
   }
   resultat.x = a * resultat.y + b;
   
   return (sqrt (CARRE (resultat.x - centre->x) + CARRE (resultat.y - centre->y)));
}

/* Fonction priv�e utilis�e dans la fonction deplacementBarre. */
void avanceBalle (dPointXY *balle, double angle, double distance)
{
   balle->x += cos (angle) * distance;
   balle->y -= sin (angle) * distance;
   
   return;
}

void deplacementBarre (ObjetsCDE *objets, int nouvbarreX)
{
   //D�claration des variables
   int ancbarreX = objets->barreX, coupe1, coupe2, coupe3, i;
   double ancangleBarre = objets->angleBarre, angle, distance, distance1, distance2, distance3, coeffRencontre1, coeffRencontre2;
   dPointXY anc1, anc2, nouv1, nouv2, intersec1, intersec2, anc3, anc4, nouv3, nouv4;
   
   objets->barreX = nouvbarreX;
   objets->angleBarre = calculeAngleBarre (((double)(objets->barreX - ancbarreX))*1000/((double)(objets->ecartTemps)));
   
   /* La barre est-elle susceptible de rentrer dans la balle ? */
   if ((objets->balle.y >= ORDONNEE_BARRE - MAX_MOITIE_HAUTEUR_BARRE_INCLINEE - RAYON_BALLE - 1)
   && (objets->balle.x >= ((objets->barreX > ancbarreX) ? ancbarreX : objets->barreX) - MOITIE_LARGEUR_BARRE - RAYON_BALLE - 1)
   && (objets->balle.x <= ((objets->barreX > ancbarreX) ? objets->barreX : ancbarreX) + MOITIE_LARGEUR_BARRE + RAYON_BALLE + 1)) {
      
      /* On repr�sente la barre par un segment, et on consid�rera la balle comme
      ayant un plus grand rayon. Les ancienne et nouvelle positions de la barre
      dessinent un quadrilat�re. */
      anc3.x = anc1.x = ancbarreX - cos (ancangleBarre) * (MOITIE_LARGEUR_BARRE - MOITIE_HAUTEUR_BARRE);
      anc3.y = anc1.y = ORDONNEE_BARRE + sin (ancangleBarre) * (MOITIE_LARGEUR_BARRE - MOITIE_HAUTEUR_BARRE);
      anc4.x = anc2.x = ancbarreX + cos (ancangleBarre) * (MOITIE_LARGEUR_BARRE - MOITIE_HAUTEUR_BARRE);
      anc4.y = anc2.y = ORDONNEE_BARRE - sin (ancangleBarre) * (MOITIE_LARGEUR_BARRE - MOITIE_HAUTEUR_BARRE);
      nouv3.x = nouv1.x = objets->barreX - cos (objets->angleBarre) * (MOITIE_LARGEUR_BARRE - MOITIE_HAUTEUR_BARRE);
      nouv3.y = nouv1.y = ORDONNEE_BARRE + sin (objets->angleBarre) * (MOITIE_LARGEUR_BARRE - MOITIE_HAUTEUR_BARRE);
      nouv4.x = nouv2.x = objets->barreX + cos (objets->angleBarre) * (MOITIE_LARGEUR_BARRE - MOITIE_HAUTEUR_BARRE);
      nouv4.y = nouv2.y = ORDONNEE_BARRE - sin (objets->angleBarre) * (MOITIE_LARGEUR_BARRE - MOITIE_HAUTEUR_BARRE);
      
      /* On d�termine par dichotomie le premier point � atteindre le cercle. */
      coeffRencontre1 = cercleCoupeSegment (&(objets->balle), MOITIE_HAUTEUR_BARRE + RAYON_BALLE + 1, &anc1, &nouv1, &intersec1);
      coeffRencontre2 = cercleCoupeSegment (&(objets->balle), MOITIE_HAUTEUR_BARRE + RAYON_BALLE + 1, &anc2, &nouv2, &intersec2);
      if ((coeffRencontre1 > 1) && (coeffRencontre2 > 1)) {
         if (intersectionDroiteCercle (&nouv1, &nouv2, &(objets->balle), MOITIE_HAUTEUR_BARRE + RAYON_BALLE + 1, &intersec1, &intersec2) == 0) {
            return;
         }
         coeffRencontre1 = (intersec1.x - nouv1.x) / (nouv2.x - nouv1.x);
         coeffRencontre2 = (intersec2.x - nouv1.x) / (nouv2.x - nouv1.x);
         if ((coeffRencontre1 < 0) || (coeffRencontre1 > 1)) {
            return;
         }
         anc3.x = anc1.x + coeffRencontre1 * (anc2.x - anc1.x);
         anc4.x = anc1.x + coeffRencontre2 * (anc2.x - anc1.x);
         anc3.y = anc1.y + coeffRencontre1 * (anc2.y - anc1.y);
         anc4.y = anc1.y + coeffRencontre2 * (anc2.y - anc1.y);
         nouv3.x = intersec1.x; nouv3.y = intersec1.y; nouv4.x = intersec2.x; nouv4.y = intersec2.y;
         coeffRencontre1 = cercleCoupeSegment (&(objets->balle), MOITIE_HAUTEUR_BARRE + RAYON_BALLE + 1, &anc3, &nouv3, &intersec1);
         coeffRencontre2 = cercleCoupeSegment (&(objets->balle), MOITIE_HAUTEUR_BARRE + RAYON_BALLE + 1, &anc4, &nouv4, &intersec2);
      }
      for (i = 0; i < NOMBRE_ITERATIONS_DEPLACEMENT; i++) {
         if (coeffRencontre1 > coeffRencontre2) {
            anc3.x += (anc4.x - anc3.x) / 2;
            anc3.y += (anc4.y - anc3.y) / 2;
            nouv3.x += (nouv4.x - nouv3.x) / 2;
            nouv3.y += (nouv4.y - nouv3.y) / 2;
            coeffRencontre1 = cercleCoupeSegment (&(objets->balle), MOITIE_HAUTEUR_BARRE + RAYON_BALLE + 1, &anc3, &nouv3, &intersec1);
         } else {
            anc4.x += (anc3.x - anc4.x) / 2;
            anc4.y += (anc3.y - anc4.y) / 2;
            nouv4.x += (nouv3.x - nouv4.x) / 2;
            nouv4.y += (nouv3.y - nouv4.y) / 2;
            coeffRencontre2 = cercleCoupeSegment (&(objets->balle), MOITIE_HAUTEUR_BARRE + RAYON_BALLE + 1, &anc4, &nouv4, &intersec2);
         }
      }
      if ((coeffRencontre1 > 1) && (coeffRencontre2 > 1)) {
         return;
      }
      if (coeffRencontre1 > coeffRencontre2) {
         intersec1.x = intersec2.x;
         intersec1.y = intersec2.y;
      }   
         
      /* On fait progresser la balle dans la direction oppos�e au point
      sur le cercle. */
      angle = objets->angleBalle + ((cos (angleDroiteOrientee (&(objets->balle), &intersec1, 0) - objets->angleBalle) > 0) ? M_PI : 0);
      distance1 = distanceCercleHorsDroite (&(objets->balle), MOITIE_HAUTEUR_BARRE + RAYON_BALLE + 1, angle, &anc1, &nouv1, &coupe1);
      distance2 = distanceCercleHorsDroite (&(objets->balle), MOITIE_HAUTEUR_BARRE + RAYON_BALLE + 1, angle, &nouv1, &nouv2, &coupe2);
      distance3 = distanceCercleHorsDroite (&(objets->balle), MOITIE_HAUTEUR_BARRE + RAYON_BALLE + 1, angle, &nouv2, &anc2, &coupe3);
      if (coupe1 && coupe2) {
         distance = (distance1 > distance2) ? distance1 : distance2;
      } else if (coupe2 && coupe3) {
         distance = (distance2 > distance3) ? distance2 : distance3;
      } else if (coupe1 && coupe3) {
         distance = (distance1 > distance3) ? distance1 : distance3;
      } else if (coupe1) {
         distance = distance1;
      } else if (coupe2) {
         distance = distance2;
      } else if (coupe3) {
         distance = distance3;
      } else if (distance1 < 0) {
         distance = distanceCercleHorsPoint (&(objets->balle), MOITIE_HAUTEUR_BARRE + RAYON_BALLE + 1, angle, &nouv2);
      } else if (distance3 < 0) {
         distance = distanceCercleHorsPoint (&(objets->balle), MOITIE_HAUTEUR_BARRE + RAYON_BALLE + 1, angle, &nouv1);
      } else if (distance1 > distance3) {
         distance = distanceCercleHorsPoint (&(objets->balle), MOITIE_HAUTEUR_BARRE + RAYON_BALLE + 1, angle, &nouv2);
      } else {
         distance = distanceCercleHorsPoint (&(objets->balle), MOITIE_HAUTEUR_BARRE + RAYON_BALLE + 1, angle, &nouv1);
      }
      
      /* On la fait avancer un tout petit peu plus par s�curit�. */
      nouv4.x = objets->balle.x;
      nouv4.y = objets->balle.y;
      avanceBalle (&(objets->balle), angle, distance + pow (10.0, -TOLERANCE_ANNULATION));
      
      /* Test de s�curit�. */
      if ((objets->balle.x <= 1 + RAYON_BALLE) || (objets->balle.x >= 798 - RAYON_BALLE)) {
         objets->retientBalle = 1;
      }
   }
   
   return;
}

/* Structure priv�e utilis�e dans la fonction deplacementEtCollisions. */
typedef struct {
   /* La droite rencontr�e. */
   double angle;
   /* Ce coefficient entre 0 et 1 indique o� la droite a �t� rencontr�e entre le
   point pr�c�dent et futur. */
   double coeffRencontre;
} LieuCollision;

/* Fonction priv�e utilis�e dans la fonction deplacementEtCollisions.
Elle renvoie le coefficient de rencontre sur le segment. */
double intersectionSegmentCercle (dPointXY *point1, dPointXY *point2, dPointXY *centre, int rayon, dPointXY *resultat)
{
   //D�claration des variables
   double a, b, c, d, e, delta, coeffRencontre;
   
   /* On calcule d'abord les coefficients caract�risant la droite. */
   a = (point2->x - point1->x) / (point2->y - point1->y);
   b = point1->x - a * point1->y;
   
   /* Puis on calcule les coefficients de l'�quation du second ordre � r�soudre. */
   c = (CARRE (a) + 1);
   d = 2 * ((b - centre->x) * a - centre->y);
   e = CARRE (b - centre->x) + CARRE (centre->y) - CARRE (rayon);
   
   /* Et on r�soud l'�quation en y (dont on est s�r qu'elle a des solutions.). */
   delta = CARRE (d) - 4 * c * e;
   resultat->y = (-d - sqrt (delta)) / (2 * c);
   coeffRencontre = (point1->y - resultat->y) / (point1->y - point2->y);
   if (coeffRencontre > 1) {
      resultat->y = (-d + sqrt (delta)) / (2 * c);
      coeffRencontre = (point1->y - resultat->y) / (point1->y - point2->y);
   }
   resultat->x = a * resultat->y + b;
   
   return (coeffRencontre);
}

/* Fonction priv�e utilis�e dans la fonction deplacementEtCollisions.
Elle renvoie le coefficient de rencontre du point1 au point2 (-1 si pas rencontre.). */
double intersection2Segments (dPointXY *point1, dPointXY *point2, dPointXY *point3, dPointXY *point4)
{
   //D�claration des variables
   double a, b, c, d, coeffRencontre;
   dPointXY resultat;
   
   /* On calcule les coefficients des droites. */
   a = (point2->x - point1->x) / (point2->y - point1->y);
   b = point1->x - a * point1->y;
   c = (point4->y - point3->y) / (point4->x - point3->x);
   d = point3->y - c * point3->x;
   
   /* On calcule les coordonn�es de l'intersection. */
   if (doubleNul (1 - c * a, TOLERANCE_ANNULATION)) {
      /* Les deux droites sont parall�les. */
      return (-1);
   }
   resultat.y = (c * b + d) / (1 - c * a);
   resultat.x = a * resultat.y + b;
   
   /* Enfin, on v�rifie que l'intersection est bien sur les deux segments. */
   coeffRencontre = (point3->x - resultat.x) / (point3->x - point4->x);
   if ((coeffRencontre < 0) || (coeffRencontre > 1)) {
      return (-1);
   }
   coeffRencontre = (point1->y - resultat.y) / (point1->y - point2->y);
   if ((coeffRencontre < 0) || (coeffRencontre > 1)) {
      return (-1);
   }
   
   return (coeffRencontre);
}

int deplacementEtCollisions (ObjetsAffichage *surfaces, ObjetsSon *sons, ObjetsCDE *objets)
{
   //D�claration des variables
   int i, nombreCollisions, secteurx, secteury, indexBrique = -1;
   double distance, carreDistParcourue;
   LieuCollision lieux[2];
   dPointXY proj, pointBarre1, pointBarre2, intersec;
   
   if (objets->retientBalle) {
      objets->balle.x = objets->barreX - ((MOITIE_HAUTEUR_BARRE*3)/2 + (RAYON_BALLE*3)/2) * sin (objets->angleBarre);
      objets->balle.y = ORDONNEE_BARRE - ((MOITIE_HAUTEUR_BARRE*3)/2 + (RAYON_BALLE*3)/2) * cos (objets->angleBarre);
   } else {
      /* On fait avancer la balle. */
      proj.x = objets->balle.x + (double)(VITESSE_BALLE * objets->ecartTemps) / 1000.0F * cos (objets->angleBalle);
      proj.y = objets->balle.y - (double)(VITESSE_BALLE * objets->ecartTemps) / 1000.0F * sin (objets->angleBalle);
      
      carreDistParcourue = CARRE (proj.x - objets->balle.x) + CARRE (proj.y - objets->balle.y);
      
      /* On effectuera deux tests de collisions successifs (pour les coins.). */
      for (i = 0; i < 2; i++) {
         nombreCollisions = 0;
         
         /* Les briques. */
         if ((proj.y <= (480 - HAUTEUR_BORD_BAS + RAYON_BALLE)) && (proj.x <= (800 - LARGEUR_BORD_DROIT + RAYON_BALLE)) && (proj.x >= (LARGEUR_BORD_GAUCHE - RAYON_BALLE - 1)) && (proj.y >= (HAUTEUR_BORD_HAUT - RAYON_BALLE - 1))) {
            
            /* On d�termine d'abord le secteur dans lequel se situe la balle. */
            secteurx = ((int)(proj.x+0.5) - (LARGEUR_BORD_GAUCHE - INTER_BRIQUES_X - LARGEUR_BRIQUE / 2)) / (LARGEUR_BRIQUE + INTER_BRIQUES_X);
            secteury = ((int)(proj.y+0.5) - (HAUTEUR_BORD_HAUT - INTER_BRIQUES_Y - HAUTEUR_BRIQUE / 2)) / (HAUTEUR_BRIQUE + INTER_BRIQUES_Y);
            
            if (secteurx > 0) {
               if (secteury > 0) {
                  /* La brique en haut � gauche. */
                  indexBrique = (secteury - 1) * NOMBRE_BRIQUES_EN_LARGEUR + (secteurx - 1);
                  if ((objets->etatBriques[indexBrique] != 0) && (proj.x <= objets->briques[indexBrique].x + LARGEUR_BRIQUE + RAYON_BALLE) && (proj.y <= objets->briques[indexBrique].y + HAUTEUR_BRIQUE + RAYON_BALLE)) {
                     pointBarre1.x = objets->briques[indexBrique].x + LARGEUR_BRIQUE - 1;
                     pointBarre1.y = objets->briques[indexBrique].y + HAUTEUR_BRIQUE - 1;
                     distance = sqrt (CARRE (proj.x - pointBarre1.x) + CARRE (proj.y - pointBarre1.y));
                     if (distance <= (1 + RAYON_BALLE)) {
                        lieux[nombreCollisions].coeffRencontre = intersectionSegmentCercle (&(objets->balle), &proj, &pointBarre1, 1 + RAYON_BALLE, &intersec);
                        lieux[nombreCollisions].angle = angleDroiteOrientee (&pointBarre1, &intersec, -M_PI_2) + M_PI_2;
                        if ((lieux[nombreCollisions].angle > 0) && (lieux[nombreCollisions].angle < M_PI_2)) {
                           nombreCollisions++;
                           objets->etatBriques[indexBrique]--;
                        }
                     }
                     lieux[nombreCollisions].coeffRencontre = (objets->balle.y - objets->briques[indexBrique].y - HAUTEUR_BRIQUE - RAYON_BALLE) / (objets->balle.y - proj.y);
                     intersec.x = objets->balle.x + lieux[nombreCollisions].coeffRencontre * (proj.x - objets->balle.x);
                     if ((lieux[nombreCollisions].coeffRencontre >= 0) && (lieux[nombreCollisions].coeffRencontre <= 1) && (intersec.x >= objets->briques[indexBrique].x) && (intersec.x <= pointBarre1.x)) {
                        lieux[nombreCollisions].angle = 0.0F;
                        nombreCollisions++;
                        objets->etatBriques[indexBrique]--;
                     }
                     if (!doubleNul (cos (objets->angleBalle), TOLERANCE_ANNULATION)) {
                        lieux[nombreCollisions].coeffRencontre = (objets->balle.x - objets->briques[indexBrique].x - LARGEUR_BRIQUE - RAYON_BALLE) / (objets->balle.x - proj.x);
                        intersec.y = objets->balle.y + lieux[nombreCollisions].coeffRencontre * (proj.y - objets->balle.y);
                        if ((lieux[nombreCollisions].coeffRencontre >= 0) && (lieux[nombreCollisions].coeffRencontre <= 1) && (intersec.y >= objets->briques[indexBrique].y) && (intersec.y <= pointBarre1.y)) {
                           lieux[nombreCollisions].angle = M_PI_2;
                           nombreCollisions++;
                           objets->etatBriques[indexBrique]--;
                        }
                     }
                     if (objets->etatBriques[indexBrique] == 0) {
                        effaceBrique (surfaces, objets, indexBrique);
                        objets->briquesRestantes--;
                     }
                  }
               }
               if (secteury < NOMBRE_BRIQUES_EN_HAUTEUR) {
                  /* La brique en bas � gauche. */
                  indexBrique = secteury * NOMBRE_BRIQUES_EN_LARGEUR + (secteurx - 1);
                  if ((objets->etatBriques[indexBrique] != 0) && (proj.x <= objets->briques[indexBrique].x + LARGEUR_BRIQUE + RAYON_BALLE) && (proj.y >= objets->briques[indexBrique].y - RAYON_BALLE - 1)) {
                     pointBarre1.x = objets->briques[indexBrique].x + LARGEUR_BRIQUE - 1;
                     pointBarre1.y = objets->briques[indexBrique].y;
                     distance = sqrt (CARRE (proj.x - pointBarre1.x) + CARRE (proj.y - pointBarre1.y));
                     if (distance <= (1 + RAYON_BALLE)) {
                        lieux[nombreCollisions].coeffRencontre = intersectionSegmentCercle (&(objets->balle), &proj, &pointBarre1, 1 + RAYON_BALLE, &intersec);
                        lieux[nombreCollisions].angle = angleDroiteOrientee (&pointBarre1, &intersec, 0.0F) + M_PI_2;
                        if ((lieux[nombreCollisions].angle > M_PI_2) && (lieux[nombreCollisions].angle < M_PI)) {
                           nombreCollisions++;
                           objets->etatBriques[indexBrique]--;
                        }
                     }
                     lieux[nombreCollisions].coeffRencontre = (objets->balle.y - objets->briques[indexBrique].y + RAYON_BALLE + 1) / (objets->balle.y - proj.y);
                     intersec.x = objets->balle.x + lieux[nombreCollisions].coeffRencontre * (proj.x - objets->balle.x);
                     if ((lieux[nombreCollisions].coeffRencontre >= 0) && (lieux[nombreCollisions].coeffRencontre <= 1) && (intersec.x >= objets->briques[indexBrique].x) && (intersec.x <= pointBarre1.x)) {
                        lieux[nombreCollisions].angle = 0.0F;
                        nombreCollisions++;
                        objets->etatBriques[indexBrique]--;
                     }
                     if (!doubleNul (cos (objets->angleBalle), TOLERANCE_ANNULATION)) {
                        lieux[nombreCollisions].coeffRencontre = (objets->balle.x - objets->briques[indexBrique].x - LARGEUR_BRIQUE - RAYON_BALLE) / (objets->balle.x - proj.x);
                        intersec.y = objets->balle.y + lieux[nombreCollisions].coeffRencontre * (proj.y - objets->balle.y);
                        if ((lieux[nombreCollisions].coeffRencontre >= 0) && (lieux[nombreCollisions].coeffRencontre <= 1) && (intersec.y >= pointBarre1.y) && (intersec.y <= (pointBarre1.y + HAUTEUR_BRIQUE - 1))) {
                           lieux[nombreCollisions].angle = M_PI_2;
                           nombreCollisions++;
                           objets->etatBriques[indexBrique]--;
                        }
                     }
                     if (objets->etatBriques[indexBrique] == 0) {
                        effaceBrique (surfaces, objets, indexBrique);
                        objets->briquesRestantes--;
                     }
                  }
               }
            }
            if (secteurx < NOMBRE_BRIQUES_EN_LARGEUR) {
               if (secteury > 0) {
                  /* La brique en haut � droite. */
                  indexBrique = (secteury - 1) * NOMBRE_BRIQUES_EN_LARGEUR + secteurx;
                  if ((objets->etatBriques[indexBrique] != 0) && (proj.x >= objets->briques[indexBrique].x - RAYON_BALLE - 1) && (proj.y <= objets->briques[indexBrique].y + HAUTEUR_BRIQUE + RAYON_BALLE)) {
                     pointBarre1.x = objets->briques[indexBrique].x;
                     pointBarre1.y = objets->briques[indexBrique].y + HAUTEUR_BRIQUE - 1;
                     distance = sqrt (CARRE (proj.x - pointBarre1.x) + CARRE (proj.y - pointBarre1.y));
                     if (distance <= (1 + RAYON_BALLE)) {
                        lieux[nombreCollisions].coeffRencontre = intersectionSegmentCercle (&(objets->balle), &proj, &pointBarre1, 1 + RAYON_BALLE, &intersec);
                        lieux[nombreCollisions].angle = angleDroiteOrientee (&pointBarre1, &intersec, M_PI) + M_PI_2;
                        if ((lieux[nombreCollisions].angle > (M_PI_2 + M_PI)) && (lieux[nombreCollisions].angle < (2 * M_PI))) {
                           nombreCollisions++;
                           objets->etatBriques[indexBrique]--;
                        }
                     }
                     lieux[nombreCollisions].coeffRencontre = (objets->balle.y - objets->briques[indexBrique].y - HAUTEUR_BRIQUE - RAYON_BALLE) / (objets->balle.y - proj.y);
                     intersec.x = objets->balle.x + lieux[nombreCollisions].coeffRencontre * (proj.x - objets->balle.x);
                     if ((lieux[nombreCollisions].coeffRencontre >= 0) && (lieux[nombreCollisions].coeffRencontre <= 1) && (intersec.x >= pointBarre1.x) && (intersec.x <= (pointBarre1.x + LARGEUR_BRIQUE - 1))) {
                        lieux[nombreCollisions].angle = 0.0F;
                        nombreCollisions++;
                        objets->etatBriques[indexBrique]--;
                     }
                     if (!doubleNul (cos (objets->angleBalle), TOLERANCE_ANNULATION)) {
                        lieux[nombreCollisions].coeffRencontre = (objets->balle.x - objets->briques[indexBrique].x + RAYON_BALLE + 1) / (objets->balle.x - proj.x);
                        intersec.y = objets->balle.y + lieux[nombreCollisions].coeffRencontre * (proj.y - objets->balle.y);
                        if ((lieux[nombreCollisions].coeffRencontre >= 0) && (lieux[nombreCollisions].coeffRencontre <= 1) && (intersec.y >= objets->briques[indexBrique].y) && (intersec.y <= pointBarre1.y)) {
                           lieux[nombreCollisions].angle = M_PI_2;
                           nombreCollisions++;
                           objets->etatBriques[indexBrique]--;
                        }
                     }
                     if (objets->etatBriques[indexBrique] == 0) {
                        effaceBrique (surfaces, objets, indexBrique);
                        objets->briquesRestantes--;
                     }
                  }
               }
               if (secteury < NOMBRE_BRIQUES_EN_HAUTEUR) {
                  /* La brique en bas � droite. */
                  indexBrique = secteury * NOMBRE_BRIQUES_EN_LARGEUR + secteurx;
                  if ((objets->etatBriques[indexBrique] != 0) && (proj.x >= objets->briques[indexBrique].x - RAYON_BALLE - 1) && (proj.y >= objets->briques[indexBrique].y - RAYON_BALLE - 1)) {
                     pointBarre1.x = objets->briques[indexBrique].x;
                     pointBarre1.y = objets->briques[indexBrique].y;
                     distance = sqrt (CARRE (proj.x - pointBarre1.x) + CARRE (proj.y - pointBarre1.y));
                     if (distance <= (1 + RAYON_BALLE)) {
                        lieux[nombreCollisions].coeffRencontre = intersectionSegmentCercle (&(objets->balle), &proj, &pointBarre1, 1 + RAYON_BALLE, &intersec);
                        lieux[nombreCollisions].angle = angleDroiteOrientee (&pointBarre1, &intersec, M_PI_2) + M_PI_2;
                        if ((lieux[nombreCollisions].angle > M_PI) && (lieux[nombreCollisions].angle < (M_PI + M_PI_2))) {
                           nombreCollisions++;
                           objets->etatBriques[indexBrique]--;
                        }
                     }
                     lieux[nombreCollisions].coeffRencontre = (objets->balle.y - objets->briques[indexBrique].y + RAYON_BALLE + 1) / (objets->balle.y - proj.y);
                     intersec.x = objets->balle.x + lieux[nombreCollisions].coeffRencontre * (proj.x - objets->balle.x);
                     if ((lieux[nombreCollisions].coeffRencontre >= 0) && (lieux[nombreCollisions].coeffRencontre <= 1) && (intersec.x >= objets->briques[indexBrique].x) && (intersec.x <= (objets->briques[indexBrique].x + LARGEUR_BRIQUE - 1))) {
                        lieux[nombreCollisions].angle = 0.0F;
                        nombreCollisions++;
                        objets->etatBriques[indexBrique]--;
                     }
                     if (!doubleNul (cos (objets->angleBalle), TOLERANCE_ANNULATION)) {
                        lieux[nombreCollisions].coeffRencontre = (objets->balle.x - objets->briques[indexBrique].x + RAYON_BALLE + 1) / (objets->balle.x - proj.x);
                        intersec.y = objets->balle.y + lieux[nombreCollisions].coeffRencontre * (proj.y - objets->balle.y);
                        if ((lieux[nombreCollisions].coeffRencontre >= 0) && (lieux[nombreCollisions].coeffRencontre <= 1) && (intersec.y >= objets->briques[indexBrique].y) && (intersec.y <= (objets->briques[indexBrique].y + HAUTEUR_BRIQUE - 1))) {
                           lieux[nombreCollisions].angle = M_PI_2;
                           nombreCollisions++;
                           objets->etatBriques[indexBrique]--;
                        }
                     }
                     if (objets->etatBriques[indexBrique] == 0) {
                        effaceBrique (surfaces, objets, indexBrique);
                        objets->briquesRestantes--;
                     }
                  }
               }
            }
            if (objets->briquesRestantes == 0) {
               joueSonRebondBrique (sons);
               return (1);
            }
         } else {
            /* Le mur de droite. */
            if (proj.x >= (798 - RAYON_BALLE)) {
               lieux[0].angle = M_PI_2;
               lieux[0].coeffRencontre = (798 - RAYON_BALLE - objets->balle.x) / (proj.x - objets->balle.x);
               nombreCollisions = 1;
            }
            /* Le mur de gauche. */
            if (proj.x <= (1 + RAYON_BALLE)) {
               lieux[nombreCollisions].angle = M_PI_2;
               lieux[nombreCollisions].coeffRencontre = (objets->balle.x - 1 - RAYON_BALLE) / (objets->balle.x - proj.x);
               nombreCollisions++;
            }
            /* Le mur du haut. */
            if (proj.y <= (1 + RAYON_BALLE)) {
               lieux[nombreCollisions].angle = 0.0F;
               lieux[nombreCollisions].coeffRencontre = (objets->balle.y - 1 - RAYON_BALLE) / (objets->balle.y - proj.y);
               nombreCollisions++;
            }
            /* Le vide du bas. */
            if (proj.y >= (600 + RAYON_BALLE)) {
               return 2;
            }
            /* La barre. */
            if ((proj.y >= (surfaces->cadresEffacement[0].y - RAYON_BALLE - 1)) && (proj.x >= (surfaces->cadresEffacement[0].x - RAYON_BALLE - 1)) && (proj.x <= (surfaces->cadresEffacement[0].x + surfaces->cadresEffacement[0].w + RAYON_BALLE))) {
               
               /* La balle est susceptible de faire s'effacer une partie de la barre. */
               surfaces->aToucheBarre = 1;
               
               /* Pour le point de gauche. */
               pointBarre1.x = objets->barreX - (MOITIE_LARGEUR_BARRE - MOITIE_HAUTEUR_BARRE) * cos (objets->angleBarre);
               pointBarre1.y = ORDONNEE_BARRE + (MOITIE_LARGEUR_BARRE - MOITIE_HAUTEUR_BARRE) * sin (objets->angleBarre);
               distance = sqrt (CARRE (proj.x - pointBarre1.x) + CARRE (proj.y - pointBarre1.y));
               if (distance <= (MOITIE_HAUTEUR_BARRE + 1 + RAYON_BALLE)) {
                  lieux[nombreCollisions].coeffRencontre = intersectionSegmentCercle (&(objets->balle), &proj, &pointBarre1, MOITIE_HAUTEUR_BARRE + 1 + RAYON_BALLE, &intersec);
                  lieux[nombreCollisions].angle = angleDroiteOrientee (&pointBarre1, &intersec, objets->angleBarre) + M_PI_2;
                  if ((lieux[nombreCollisions].angle > (objets->angleBarre + M_PI)) && (lieux[nombreCollisions].angle < (objets->angleBarre + 2*M_PI))) {
                     nombreCollisions++;
                  }
               }
               pointBarre1.x -= (MOITIE_HAUTEUR_BARRE + 1 + RAYON_BALLE) * sin (objets->angleBarre);
               pointBarre1.y -= (MOITIE_HAUTEUR_BARRE + 1 + RAYON_BALLE) * cos (objets->angleBarre);
               
               /* Le point de droite. */
               pointBarre2.x = objets->barreX + (MOITIE_LARGEUR_BARRE - MOITIE_HAUTEUR_BARRE) * cos (objets->angleBarre);
               pointBarre2.y = ORDONNEE_BARRE - (MOITIE_LARGEUR_BARRE - MOITIE_HAUTEUR_BARRE) * sin (objets->angleBarre);
               distance = sqrt (CARRE (proj.x - pointBarre2.x) + CARRE (proj.y - pointBarre2.y));
               if (distance <= (MOITIE_HAUTEUR_BARRE + 1 + RAYON_BALLE)) {
                  lieux[nombreCollisions].coeffRencontre = intersectionSegmentCercle (&(objets->balle), &proj, &pointBarre2, MOITIE_HAUTEUR_BARRE + 1 + RAYON_BALLE, &intersec);
                  lieux[nombreCollisions].angle = angleDroiteOrientee (&pointBarre2, &intersec, objets->angleBarre) + M_PI_2;
                  if ((lieux[nombreCollisions].angle > objets->angleBarre) && (lieux[nombreCollisions].angle < (objets->angleBarre + M_PI))) {
                     nombreCollisions++;
                  }
               }
               pointBarre2.x -= (MOITIE_HAUTEUR_BARRE + 1 + RAYON_BALLE) * sin (objets->angleBarre);
               pointBarre2.y -= (MOITIE_HAUTEUR_BARRE + 1 + RAYON_BALLE) * cos (objets->angleBarre);
               
               /* La pleine barre (seulement la surface du haut !). */
               if (proj.y >= (((pointBarre1.y - pointBarre2.y) / (pointBarre1.x - pointBarre2.x)) * (proj.x - pointBarre1.x) + pointBarre1.y)) {
                  lieux[nombreCollisions].coeffRencontre = intersection2Segments (&(objets->balle), &proj, &pointBarre1, &pointBarre2);
                  if (lieux[nombreCollisions].coeffRencontre >= 0) {
                     lieux[nombreCollisions].angle = objets->angleBarre;
                     nombreCollisions++;
                  }
               }
            }
         }
         
         /* Les collisions. */
         if (nombreCollisions > 0) {
            if ((nombreCollisions >= 2) && (lieux[0].coeffRencontre > lieux[1].coeffRencontre)) {
               lieux[0].angle = lieux[1].angle;
               lieux[0].coeffRencontre = lieux[1].coeffRencontre;
            }
            distance = sqrt (carreDistParcourue) * cos (lieux[0].angle + M_PI_2 - objets->angleBalle);
            objets->balle.x += 2 * distance * lieux[0].coeffRencontre * cos (lieux[0].angle + M_PI_2);
            objets->balle.y -= 2 * distance * lieux[0].coeffRencontre * sin (lieux[0].angle + M_PI_2);
            proj.x -= 2 * distance * (1 - lieux[0].coeffRencontre) * cos (lieux[0].angle + M_PI_2);
            proj.y += 2 * distance * (1 - lieux[0].coeffRencontre) * sin (lieux[0].angle + M_PI_2);
            objets->angleBalle = fmod (2 * lieux[0].angle - objets->angleBalle + M_PI, 2*M_PI) - M_PI;
            if (fabs (sin (objets->angleBalle)) < sin (LIMITE_ANGLE_BALLE)) {
               objets->angleBalle = ((cos (objets->angleBalle) < 0) ? M_PI : 0) - ((objets->angleBalle <= 0.0F) ? -LIMITE_ANGLE_BALLE : LIMITE_ANGLE_BALLE);
            }
            
            /* En avant la musique ! */
            if (indexBrique >= 0) {
               joueSonRebondBrique (sons);
            }
            if (surfaces->aToucheBarre) {
               joueSonRebondBarre (sons);
            }
         } else {
            break;
         }
      }
      
      /* C'est fini ! */
      objets->balle.x = proj.x;
      objets->balle.y = proj.y;
   }
   
   return (0);
}

double calculeAngleBarre (double vitesse)
{
   if (fabs(vitesse) < VITESSE_MAX_ANGLE_MAX) {
      return (-vitesse * LIMITE_ANGLE / VITESSE_MAX_ANGLE_MAX);
   } else {
      return ((vitesse > 0) ? -LIMITE_ANGLE : LIMITE_ANGLE);
   }
}

int indexAngle (double angle)
{
   return ((int)(angle * NOMBRE_INCLINAISONS / LIMITE_ANGLE + 0.5));
}

int abscisseBarre (int x)
{
   return ((int)((float)x*(797-2*MOITIE_LARGEUR_BARRE)/799+0.5)+MOITIE_LARGEUR_BARRE+1);
}

void pause (void)
{
   //D�claration des variables
   SDL_Event event;
   
   while (SDL_WaitEvent (&event)) {
      if ((event.type == SDL_KEYDOWN) && (event.key.keysym.sym == SDLK_RETURN)) {
         return;
      }
   }
}
