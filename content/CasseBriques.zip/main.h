/*

Fichier: main.h

Auteur: Thibault Raffaillac <thibaultraffaillac@yahoo.fr>
Cr�� le: 19/06/07

Ce jeu est un classique jeu de casse-briques.

*/

#ifndef TRAF_MAIN_H
#define TRAF_MAIN_H

#include "Constantes.h"
#include <stdio.h>
#include <stdlib.h>
#include "../../FonctionsUtiles/SDL_TemporisateurIntelligent.h"
#include "Affichage.h"
#include "ChargementAffichage.h"
#include "CollisionsDeplacementsEvenements.h"
#include "GestionSon.h"

int main (int argc, char *argv[]);

/**
 * Cette fonction g�re la fermeture de toutes les sous-parties du programme.
 */
void quitte (ObjetsAffichage *surfaces, ObjetsSon *sons);

#endif
