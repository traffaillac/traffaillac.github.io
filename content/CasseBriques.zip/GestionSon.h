/*

Fichier: GestionSon.h

Auteur: Thibault Raffaillac <thibaultraffaillac@yahoo.fr>
Cr�� le: 04/07/07

Ce fichier contient toutes les fonctions ayant rapport au son dans le jeu.

*/

#ifndef TRAF_GESTION_SON_H
#define TRAF_GESTION_SON_H

#include "Constantes.h"
#include <stdio.h>

/**
 * Cette fonction initialise FMOD.
 *
 * Elle renvoie -1 en cas d'erreur.
 */
int initFMOD (void);

/**
 * Cette fonction charge en m�moire les samples et appelle le chargement de la
 * musique de fond � l'aide de l'option FSOUND_NONBLOCKING.
 *
 * Elle renvoie -1 si une erreur ne permet pas que le programme continue, et 0
 * si tout s'est bien pass� ou si une erreur permet toutefois que le jeu marche.
 */
int creeObjetsSon (ObjetsSon *sons);

/**
 * Cette fonction tente de lancer la musique de fond et fait qu'elle sera jou�e
 * en boucle.
 *
 * Elle renvoie -1 en cas d'erreur.
 */
int joueMusiqueFond (ObjetsSon *sons);

/**
 * Cette fonction tente de jouer le sample de rebond sur une brique.
 */
void joueSonRebondBrique (ObjetsSon *sons);

/**
 * Cette fonction tente de jouer le sample d rebond sur la barre.
 */
void joueSonRebondBarre (ObjetsSon *sons);

/**
 * Cette fonction efface les samples et la musique de fond de la structure qui
 * lui est pass�e en argument, et quitte FMOD.
 */
void quitteFMOD (ObjetsSon *sons);

#endif
