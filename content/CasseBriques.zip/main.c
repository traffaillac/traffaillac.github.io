/*

Fichier: main.c

Auteur: Thibault Raffaillac <thibaultraffaillac@yahoo.fr>
Cr�� le: 19/06/07

Ce jeu est un classique jeu de casse-briques.

*/

#include "main.h"

int main (int argc, char *argv[])
{
   //D�claration des variables
   int nouvellePartie, continuer;
   SDL_Tempo temporisateur = {};
   ObjetsAffichage surfaces = {};
   ObjetsSon sons = {};
   ObjetsCDE objets = {};
      
   //Initialisations
   /* On ouvre la SDL et FMOD. */
   if ((initSDL (&surfaces) < 0) || (initFMOD () < 0)) {
      SDL_Quit ();
      return (EXIT_FAILURE);
   }
   
   /* On initialise le temporisateur. */
   SDL_InitTempo (&temporisateur, INTERVALLE_TEMPS);
   
   /* On cr�e les images et les sons qui seront utilis�s tout au long du jeu. */
   if ((creeObjetsAffichage (&surfaces) < 0) || (creeObjetsSon (&sons) < 0)) {
      quitte (&surfaces, &sons);
      return (EXIT_FAILURE);
   }
   
   /* On initialise les positions des briques. */
   initObjetsCDE (&objets);
   
   /* La boucle permettant de recommencer une partie. */
   do {
      
      nouvellePartie = 0;
      continuer = 1;
      
      /* Initialisation des positions de la balle et de la barre, et
      initialisation de l'�tat des briques. */
      reinitObjetsCDE (&objets);
      
      /* Premier affichage. */
      if (premierAffichage (&surfaces, &objets) < 0) {
         quitte (&surfaces, &sons);
         return (EXIT_FAILURE);
      }
      
      /* On met les pendules � l'heure. */
      SDL_ReinitTempo (&temporisateur);
      
      /* La boucle du jeu. */
      do {
         
         /* On lance la musique de fond. */
         if (joueMusiqueFond (&sons) < 0) {
            quitte (&surfaces, &sons);
            return (EXIT_FAILURE);
         }
         
         /* La temporisation. */
         SDL_TemporiseIntelligemment (&temporisateur);
         
         /* On pr�pare l'affichage. */
         if (preparationAffichage (&surfaces) < 0) {
            quitte (&surfaces, &sons);
            return (EXIT_FAILURE);
         }
         
         /* On g�re les �v�nements. */
         switch (gereEvenements (&surfaces, &objets, &temporisateur)) {
         case -1:
            quitte (&surfaces, &sons);
            return (EXIT_FAILURE);
            break;
         case 2:
            nouvellePartie = 1;
         case 1:
            continuer = 0;
            break;
         default:
            break;
         }
         
         /* On fait �voluer le syst�me et on g�re les collisions. */
         switch (deplacementEtCollisions (&surfaces, &sons, &objets)) {
         case -1:
            quitte (&surfaces, &sons);
            return (EXIT_FAILURE);
            break;
         case 1:
         case 2:
            continuer = 0;
            nouvellePartie = 1;
            break;
         default:
            break;
         }
         
         /* Enfin, on affiche le tout. */
         if (actualiseAffichage (&surfaces, &objets) < 0) {
            quitte (&surfaces, &sons);
            return (EXIT_FAILURE);
         }
         
      } while (continuer);
      
   } while (nouvellePartie);
   
   /* On ferme tout ce qui doit �tre ferm�. */
   quitte (&surfaces, &sons);
   
   return (EXIT_SUCCESS);
}

void quitte (ObjetsAffichage *surfaces, ObjetsSon *sons)
{
   /* On ferme la SDL. */
   quitteSDL (surfaces);
   
   /* On ferme FMOD. */
   quitteFMOD (sons);
   
   return;
}
