#!/bin/sh
./nasm -f elf64 main.asm
ld -s -o main main.o
rm main.o
./main
