package semant.amsyntax;

public class Div extends Inst {
    public Div() {
        super(Opcode.DIV);
    }
}
