package semant.amsyntax;

public class False extends Inst {
    public False() {
        super(Opcode.FALSE);
    }
}
