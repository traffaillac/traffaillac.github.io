package semant.amsyntax;

public class And extends Inst {
    public And() {
        super(Opcode.AND);
    }
}
