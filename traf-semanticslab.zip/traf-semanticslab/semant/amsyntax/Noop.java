package semant.amsyntax;

public class Noop extends Inst {
    public Noop() {
        super(Opcode.NOOP);
    }
}
