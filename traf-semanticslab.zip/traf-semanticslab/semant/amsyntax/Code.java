package semant.amsyntax;

import java.util.*;

public class Code extends ArrayList<Inst> {
}
