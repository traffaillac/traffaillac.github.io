package semant.amsyntax;

public class Sub extends Inst {
    public Sub() {
        super(Opcode.SUB);
    }
}
