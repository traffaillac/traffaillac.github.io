package semant.amsyntax;

public class Le extends Inst {
    public Le() {
        super(Opcode.LE);
    }
}
