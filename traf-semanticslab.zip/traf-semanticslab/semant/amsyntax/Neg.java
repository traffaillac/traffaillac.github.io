package semant.amsyntax;

public class Neg extends Inst {
    public Neg() {
        super(Opcode.NEG);
    }
}
