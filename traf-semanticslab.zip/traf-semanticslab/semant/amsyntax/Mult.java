package semant.amsyntax;

public class Mult extends Inst {
    public Mult() {
        super(Opcode.MULT);
    }
}
