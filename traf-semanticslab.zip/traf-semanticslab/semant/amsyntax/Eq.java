package semant.amsyntax;


public class Eq extends Inst {
    public Eq() {
        super(Opcode.EQ);
    }
}
