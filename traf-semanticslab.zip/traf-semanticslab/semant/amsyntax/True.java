package semant.amsyntax;

public class True extends Inst {
    public True() {
        super(Opcode.TRUE);
    }
}
