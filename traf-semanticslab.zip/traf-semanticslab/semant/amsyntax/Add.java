package semant.amsyntax;

public class Add extends Inst {
    public Add() {
        super(Opcode.ADD);
    }
}
