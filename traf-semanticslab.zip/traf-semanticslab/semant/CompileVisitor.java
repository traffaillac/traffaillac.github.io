package semant;

import semant.amsyntax.*;
import semant.whilesyntax.*;
import semant.signexc.*;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Stack;



class MutableBoolean {
	public boolean value;
	public MutableBoolean(boolean b) {
		value = b;
	}
}


	
class Variable {
	public String number;
	public boolean initialized;
	public SignExc e = SignExc.Z;
	public Variable(int number, boolean initialized) {
		this.number = new String(Integer.toString(number));
		this.initialized = initialized;
	}
	public Variable(Variable v) {
		this.number = v.number; // No need to deep copy
		this.initialized = v.initialized;
		this.e = v.e;
	}
	public String toString() {
		return e.toString();
	}
}



public class CompileVisitor implements WhileVisitor {
	
	void debug_print(String s) {
		// Comment out to toggle pretty printing off
		// System.out.print(s);
	}
	
	private String i = ""; // indentation level
	Stack<Hashtable<String,Variable>> states = new Stack<Hashtable<String,Variable>>(); // each level corresponds to a parallel branch
	private Stack<MutableBoolean> errors = new Stack<MutableBoolean>(); // each level corresponds to a try block
	private final SignExcOps seo = new SignExcOps(); // workaround to call the SignExcOps methods
	private final SignExcLattice sel = new SignExcLattice(); // To call SignExcLattice.lub
	
	private void indent() {
		i += "\t";
	}
	
	private void outdent() {
		i = i.substring(1);
	}
	
	private boolean got_optimized(BCode b) {
		boolean res = true;
		switch (b.e) {
		case TT: b.c.clear(); b.c.add(new True()); break;
		case FF: b.c.clear(); b.c.add(new False()); break;
		default: res = false; break;
		}
		return res;
	}
	
	private boolean got_optimized(ACode a) {
		boolean res = true;
		if (a.e == SignExc.ZERO) { a.c.clear(); a.c.add(new Push("0")); }
		else res = false;
		return res;
	}
	
	private Hashtable<String,Variable> duplicate_state() {
		Hashtable<String,Variable> res = new Hashtable<String,Variable>();
		Enumeration e = states.peek().keys();
		while (e.hasMoreElements()) {
			String s = (String)e.nextElement(); // No need to deep copy
			res.put(s, new Variable(states.peek().get(s)));
		}
		return (res);
	}
	
	private void merge_states() {
		Hashtable<String,Variable> h = states.pop();
		Enumeration e = h.keys();
		while (e.hasMoreElements()) {
			String s = (String)e.nextElement();
			Variable v1 = states.peek().get(s), v2 = h.get(s);
			if (v1 == null) {
				states.peek().put(s, v2);
			} else {
				v1.e = sel.lub(v1.e, v2.e);
				v1.initialized &= v2.initialized;
			}
		}
	}
	
	private void join_states() {
		Hashtable<String,Variable> h = states.pop();
		Enumeration e = h.keys();
		while (e.hasMoreElements()) {
			String s = (String)e.nextElement();
			Variable v = states.peek().get(s);
			if (v == null)
				states.peek().put(s, new Variable(states.peek().size(), h.get(s).initialized));
			else
				v.e = SignExc.Z;
		}
	}
	
	public Code visit(Compound compound) {
		Code c = compound.s1.accept(this);
		debug_print(";\n" + i);
		c.addAll(compound.s2.accept(this));
		return c;
	}
	
	public BCode visit(Not not) {
		debug_print("!(");
		BCode b = not.b.accept(this);
		debug_print(")");
		b.e = seo.neg(b.e);
		if (!got_optimized(b))
			b.c.add(new Neg());
		return b;
	}
	
	public BCode visit(Conjunction and) {
		BCode b1 = and.b1.accept(this);
		debug_print(" & ");
		BCode b2 = and.b2.accept(this);
		b1.e = seo.and(b1.e, b2.e);
		if (!got_optimized(b1)) {
			b1.c.addAll(b2.c);
			b1.c.add(new And());
		}
		return b1;
	}
	
	public Code visit(Assignment assignment) throws Exception {
		debug_print(states.peek().toString() + "\n" + i + assignment.x.id + " := ");
		ACode a = assignment.a.accept(this);
		if (seo.possiblyAErr(a.e)) {
			if (errors.empty())
				throw new Exception("Exception raiser outside try block");
			debug_print(" # Possible exception raiser!");
			errors.peek().value = true;
			a.e = SignExc.Z;
		}
		Variable v = states.peek().get(assignment.x.id);
		if (v == null) {
			states.peek().put(assignment.x.id, new Variable(states.peek().size(), true));
			v = states.peek().get(assignment.x.id);
		}
		v.e = (!errors.empty() && errors.peek().value) ? sel.lub(v.e, a.e) : a.e;
		Code c = a.c;
		c.add(new Store(assignment.x.id));
		return c;
	}
	
	public Code visit(Conditional conditional) throws Exception {
		debug_print(states.peek().toString() + "\n" + i + "if ");
		BCode b = conditional.b.accept(this);
		debug_print(" then");
		if (seo.possiblyBErr(b.e)) {
			if (errors.empty())
				throw new Exception("Exception raiser outside try block");
			debug_print(" # Possible exception raiser!");
			errors.peek().value = true;
			b.e = TTExc.T;
		}
		indent();
		debug_print("\n" + i);
		Code c;
		if (seo.possiblyTrue(b.e)) {
			Hashtable<String,Variable> h = duplicate_state();
			Code c1 = conditional.s1.accept(this);
			outdent();
			debug_print("\n" + i + "else\n\t" + i);
			indent();
			if (seo.possiblyFalse(b.e)) {
				c = b.c;
				states.push(h);
				c.add(new Branch(c1, conditional.s2.accept(this)));
				merge_states();
			} else {
				debug_print("# Unreachable");
				c = c1;
			}
		} else {
			outdent();
			debug_print("# Unreachable\n" + i + "else\n\t" + i);
			indent();
			c = conditional.s2.accept(this);
		}
		outdent();
		return c;
	}
	
	public BCode visit(Equals equals) {
		ACode a1 = equals.a1.accept(this);
		debug_print(" = ");
		ACode a2 = equals.a2.accept(this);
		BCode b = new BCode(seo.eq(a1.e, a2.e), a2.c);
		if (!got_optimized(b)) {
			b.c.addAll(a1.c);
			b.c.add(new Eq());
		}
		return b;
	}
	
	public BCode visit(FalseConst f) {
		debug_print("false");
		return new BCode(TTExc.FF, new False());
	}
	
	public BCode visit(LessThanEq lessthaneq) {
		ACode a1 = lessthaneq.a1.accept(this);
		debug_print(" <= ");
		ACode a2 = lessthaneq.a2.accept(this);
		BCode b = new BCode(seo.leq(a1.e, a2.e), a2.c);
		if (!got_optimized(b)) {
			b.c.addAll(a1.c);
			b.c.add(new Le());
		}
		return b;
	}
	
	public ACode visit(Minus minus) {
		debug_print("(");
		ACode a1 = minus.a1.accept(this);
		debug_print(" - ");
		ACode a2 = minus.a2.accept(this);
		debug_print(")");
		a2.e = seo.substract(a1.e, a2.e);
		if (!got_optimized(a2)) {
			a2.c.addAll(a1.c);
			a2.c.add(new Sub());
		}
		return a2;
	}
	
	public ACode visit(Num num) {
		debug_print(num.n);
		return new ACode(seo.abs(Integer.decode(num.n)), new Push(num.n));
	}
	
	public ACode visit(Plus plus) {
		debug_print("(");
		ACode a1 = plus.a1.accept(this);
		debug_print(" + ");
		ACode a2 = plus.a2.accept(this);
		debug_print(")");
		a2.e = seo.add(a1.e, a2.e);
		if (!got_optimized(a2)) {
			a2.c.addAll(a1.c);
			a2.c.add(new Add());
		}
		return a2;
	}
	
	public Code visit(Skip skip) {
		debug_print("skip");
		Code c = new Code();
		c.add(new Noop());
		return c;
	}
	
	public ACode visit(Times times) {
		debug_print("(");
		ACode a1 = times.a1.accept(this);
		debug_print(" * ");
		ACode a2 = times.a2.accept(this);
		debug_print(")");
		a2.e = seo.multiply(a1.e, a2.e);
		if (!got_optimized(a2)) {
			a2.c.addAll(a1.c);
			a2.c.add(new Mult());
		}
		return a2;
	}
	
	public BCode visit(TrueConst t) {
		debug_print("true");
		return new BCode(TTExc.TT, new True());
	}
	
	public ACode visit(Var var) {
		debug_print(var.id);
		Variable v = states.peek().get(var.id);
		if (v == null) {
			states.peek().put(var.id, new Variable(states.peek().size(), false));
			v = states.peek().get(var.id);
		}
		return new ACode(v.e, new Fetch(var.id));
	}
	
	public Code visit(While whyle) throws Exception {
		debug_print(states.peek().toString() + "\n" + i + "while ");
		BCode b = whyle.b.accept(this);
		debug_print(" do");
		if (seo.possiblyBErr(b.e)) {
			if (errors.empty())
				throw new Exception("Exception raiser outside try block");
			debug_print(" # Possible exception raiser!");
			errors.peek().value = true;
			b.e = TTExc.T;
		}
		indent();
		debug_print("\n" + i);
		Code c = new Code();
		if (seo.possiblyTrue(b.e)) {
			states.push(new Hashtable<String,Variable>());
			c.add(new Loop(b.c, whyle.s.accept(this)));
			join_states();
		} else {
			debug_print("# Unreachable");
		}
		outdent();
		return c;
	}
	
	public Code visit(TryCatch trycatch) {
		debug_print(states.peek().toString() + "\n" + i + "try\n\t" + i);
		indent();
		errors.push(new MutableBoolean(false));
		Code c = trycatch.s1.accept(this);
		outdent();
		debug_print("\n" + i + "catch\n\t" + i);
		indent();
		if (errors.pop().value) {
			duplicate_state();
			Code c1 = new Code();
			c1.add(new Try(c, trycatch.s2.accept(this)));
			c = c1;
			merge_states();
		} else {
			debug_print("# Unreachable");
		}
		outdent();
		return c;
	}
	
	public ACode visit(Divide div) {
		debug_print("(");
		ACode a1 = div.a1.accept(this);
		debug_print(" / ");
		ACode a2 = div.a2.accept(this);
		debug_print(")");
		a2.e = seo.divide(a1.e, a2.e);
		if (!got_optimized(a2)) {
			a2.c.addAll(a1.c);
			a2.c.add(new Div());
		}
		return a2;
	}
}
