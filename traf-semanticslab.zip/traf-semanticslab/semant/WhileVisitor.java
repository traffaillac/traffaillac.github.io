package semant;

import semant.amsyntax.*;
import semant.whilesyntax.*;

public interface WhileVisitor {
    public Code visit(Compound compound);
    public BCode visit(Not not);
    public BCode visit(Conjunction and);
    public Code visit(Assignment assignment) throws Exception;
    public Code visit(Conditional conditional) throws Exception;
    public BCode visit(Equals equals);
    public BCode visit(FalseConst f);
    public BCode visit(LessThanEq lessthaneq);
    public ACode visit(Minus minus);
    public ACode visit(Num num);
    public ACode visit(Plus plus);
    public Code visit(Skip skip);
    public ACode visit(Times times);
    public BCode visit(TrueConst t);
    public ACode visit(Var var);
    public Code visit(While whyle) throws Exception;
    public Code visit(TryCatch trycatch);
    public ACode visit(Divide div);
}
