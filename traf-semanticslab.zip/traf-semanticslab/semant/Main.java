package semant;

import semant.whilesyntax.Stm;
import semant.amsyntax.*;
import java.io.FileWriter;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.Hashtable;



class MutableInt {
	public int value;
	
	public MutableInt(int i) {
		value = i;
	}
	
	public void add(int i) {
		value += i;
	}
	
	public void increment() {
		value++;
	}
	
	public int intValue() {
		return value;
	}
	
	public String toString() {
		return Integer.toString(value);
	}
}



public class Main {
    public static void WriteVariablesDeclarations(FileWriter file, Hashtable<String,Variable> variables) throws Exception {
        Enumeration enu = variables.elements();
        while (enu.hasMoreElements())
            file.write("\tvar" + ((Variable)enu.nextElement()).number + ": resq 1\n");
    }
    
    public static void WriteVariablesTexts(FileWriter file, Hashtable<String,Variable> variables) throws Exception {
    	Enumeration enu = variables.keys();
    	String str, num;
    	Variable var;
    	while (enu.hasMoreElements()) {
    		str = (String)enu.nextElement();
    		var = variables.get(str);
    		if (!var.initialized) {
    			num = var.number;
    			file.write("\tvarInput" + num + ": db 'Initial value of " + str + ": '\n\tvarInputSize" + num + ": equ $-varInput" + num + "\n");
    			file.write("\tvarOutput" + num + ": db 'Final value of " + str + ": '\n\tvarOutputSize" + num + ": equ $-varOutput" + num + "\n");
    		}
    	}
    }
    
    public static void WriteVariablesInputs(FileWriter file, Hashtable<String,Variable> variables, MutableInt labelNum) throws Exception {
    	Enumeration enu = variables.elements();
    	String num, label1, label2;
    	Variable var;
    	while (enu.hasMoreElements()) {
    		var = (Variable)enu.nextElement();
    		if (!var.initialized) {
    			num = var.number;
    			file.write("\t; Prompt Initial value of var" + num + "\n\tpush 1\n\tpop rax\n\tmov rdi,rax\n\tmov rsi,varInput" + num + "\n\tmov rdx,varInputSize" + num + "\n\tsyscall\n"); // Display prompt text
    			file.write("\txor rax,rax\n\txor rdi,rdi\n\tmov rsi,inputBuffer\n\tpush 19\n\tpop rdx\n\tsyscall\n"); // Get user input
    			label1="label"+Integer.toString(labelNum.intValue()); label2="label"+Integer.toString(labelNum.intValue()+1); labelNum.add(2);
    			file.write("\tmov rcx,rax\n\tmov al,[rsi]\n\ttest al,'-'\n\tje " + label1 + "\n\tpush 0\n\tjmp " + label2 + "\n" + label1 + ":\n\tpush 1\n\tdec rcx\n\tinc rsi\n" + label2 + ":\n"); // Check for minus sign
    			label1="label"+Integer.toString(labelNum.intValue()); label2="label"+Integer.toString(labelNum.intValue()+1); labelNum.add(2);
    			file.write("\txor rax,rax\n\txor rbx,rbx\n\tpush '0'\n\tpop rdi\n\tpush 10\n\tpop r8\n" + label1 + ":\n\tmov bl,[rsi]\n\tsub bl,dil\n\tcmp bl,r8b\n\tjae " + label2 + "\n\tmul r8\n\tadd rax,rbx\n\tinc rsi\n\tloop " + label1 + "\n" + label2 + ":\n"); // Read each digit to compute the number
    			label1="label"+Integer.toString(labelNum.intValue()); labelNum.increment();
    			file.write("\tpop rbx\n\ttest rbx,rbx\n\tjz " + label1 + "\n\tneg rax\n" + label1 + ":\n\tmov [var" + num + "],rax\n\n"); // Negation if minus sign
    		}
    	}
    }
    
    public static void WriteVariablesOutputs(FileWriter file, Hashtable<String,Variable> variables, MutableInt labelNum) throws Exception {
    	Enumeration enu = variables.elements();
    	String num, label1, label2;
    	Variable var;
    	while (enu.hasMoreElements()) {
    		var = (Variable)enu.nextElement();
    		if (!var.initialized) {
    			num = var.number;
    			file.write("\n\t; Write final value of var" + num + "\n\tpush 1\n\tpop rax\n\tmov rdi,rax\n\tmov rsi,varOutput" + num + "\n\tmov rdx,varOutputSize" + num + "\n\tsyscall\n"); // Display output text
    			label1="label"+Integer.toString(labelNum.intValue()); label2="label"+Integer.toString(labelNum.intValue()+1); labelNum.add(2);
    			file.write("\tmov rax,[var" + num + "]\n\ttest rax,rax\n\tjs " + label1 + "\n\tmov rsi,outputBuffer+1\n\tjmp " + label2 + "\n" + label1 + ":\n\tmov rsi,outputBuffer\n\tneg rax\n" + label2 + ":\n"); // Check if number is negative
    			label1="label"+Integer.toString(labelNum.intValue()); labelNum.increment();
    			file.write("\tpush 10\n\tpop rbx\n\txor rcx,rcx\n" + label1 + ":\n\txor rdx,rdx\n\tdiv rbx\n\tpush rdx\n\tinc rcx\n\ttest rax,rax\n\tjnz " + label1 + "\n"); // Successive modulos are pushed on stack
    			label1="label"+Integer.toString(labelNum.intValue()); labelNum.increment();
    			file.write("\tpush '0'\n\tpop rdi\n\tmov rdx,outputBuffer+1\n" + label1 + ":\n\tpop rax\n\tadd rax,rdi\n\tmov [rdx],al\n\tinc rdx\n\tloop " + label1 + "\n\tmov [rdx],bl\n\tinc rdx\n"); // Write the digits
    			file.write("\tpush 1\n\tpop rax\n\tmov rdi,rax\n\tsub rdx,rsi\n\tsyscall\n"); // Output the number
    		}
    	}
    }
    
    public static void WriteInstructions(FileWriter file, Code c, Hashtable<String,Variable> variables, MutableInt labelNum, String catchLabel) throws Exception {
        Iterator itr = c.iterator();
        String label1, label2;
        while (itr.hasNext()) {
            Inst inst = (Inst)itr.next();
            switch (inst.opcode) {
            case ADD:
                file.write("\tpop rax\n\tpop rbx\n\tadd rax,rbx\n\tpush rax\n");
                break;
            case AND:
                file.write("\tpop rax\n\tpop rbx\n\tand rax,rbx\n\tpush rax\n");
                break;
            case BRANCH:
                label1="label"+Integer.toString(labelNum.intValue()); label2="label"+Integer.toString(labelNum.intValue()+1); labelNum.add(2);
                file.write("\tpop rcx\n\tjrcxz " + label1 + "\n");
                WriteInstructions(file, ((Branch)inst).c1, variables, labelNum, catchLabel);
                file.write("\tjmp " + label2 + "\n" + label1 + ":\n");
                WriteInstructions(file, ((Branch)inst).c2, variables, labelNum, catchLabel);
                file.write(label2 + ":\n");
                break;
            case DIV:
            	file.write("\tpop rax\n\tpop rbx\n");
            	if (catchLabel != null) // The contrary can well happen if the division was deemed safe
            		file.write("\ttest rbx,rbx\n\tjz " + catchLabel + "\n");
            	file.write("\tcqo\n\tidiv rbx\n\tpush rax\n");
            	break;
            case EQ:
            	file.write("\tpop rax\n\tpop rbx\n\tcmp rax,rbx\n\tsete al\n\tmovzx rax,al\n\tpush rax\n");
            	break;
            case FALSE:
                file.write("\tpush 0\n");
                break;
            case FETCH:
                file.write("\tpush qword [var" + variables.get(((Fetch)inst).x).number + "]\n");
                break;
            case LE:
                file.write("\tpop rax\n\tpop rbx\n\tcmp rax,rbx\n\tsetle al\n\tmovzx rax,al\n\tpush rax\n");
                break;
            case LOOP:
                label1="label"+Integer.toString(labelNum.intValue()); label2="label"+Integer.toString(labelNum.intValue()+1); labelNum.add(2);
                file.write(label1 + ":\n");
                WriteInstructions(file, ((Loop)inst).c1, variables, labelNum, catchLabel);
                file.write("\tpop rcx\n\tjrcxz " + label2 + "\n");
                WriteInstructions(file, ((Loop)inst).c2, variables, labelNum, catchLabel);
                file.write("\tjmp " + label1 + "\n" + label2 + ":\n");
                break;
            case MULT:
                file.write("\tpop rax\n\tpop rbx\n\timul rbx\n\tpush rax\n");
                break;
            case NEG:
                file.write("\tpop rax\n\txor rax,1\n\tpush rax\n");
                break;
            case NOOP:
                file.write("\tnop\n");
                break;
            case PUSH:
                file.write("\tpush " + ((Push)inst).n + "\n");
                break;
            case STORE:
                file.write("\tpop qword [var" + variables.get(((Store)inst).x).number + "]\n");
                break;
            case SUB:
                file.write("\tpop rax\n\tpop rbx\n\tsub rax,rbx\n\tpush rax\n");
                break;
            case TRUE:
                file.write("\tpush 1\n");
                break;
            case TRY:
            	label1="label"+Integer.toString(labelNum.intValue()); label2="label"+Integer.toString(labelNum.intValue()+1); labelNum.add(2);
            	WriteInstructions(file, ((Try)inst).c1, variables, labelNum, label1);
            	file.write("\tjmp " + label2 + "\n" + label1 + ":\n");
            	WriteInstructions(file, ((Try)inst).c2, variables, labelNum, catchLabel);
            	file.write(label2 + ":\n");
            	break;
            }
        }
    }
    
    public static void main(String[] args) throws Exception {
        // While -> AM Code
        Stm s = WhileParser.parse(args[0]);
        CompileVisitor cv = new CompileVisitor();
        cv.states.push(new Hashtable<String,Variable>());
        Code c = s.accept(cv);
        Hashtable<String,Variable> variables = cv.states.peek();
        cv.debug_print("\n" + variables.toString() + "\n");
        
        // AM Code -> ASM x86-64
        FileWriter file = new FileWriter("main.asm");
        file.write("section .bss\n");
        WriteVariablesDeclarations(file, variables);
        file.write("\nsection .data\n\tinputBuffer db '0000000000000000000',0\n\toutputBuffer db '-00000000000000000000',10\n");
        WriteVariablesTexts(file, variables);
        file.write("\nsection .text\n\tglobal _start\n\n_start:\n");
        MutableInt labelNum = new MutableInt(1);
        WriteVariablesInputs(file, variables, labelNum);
        file.write("\t; Program code\n");
        WriteInstructions(file, c, variables, labelNum, null);
        WriteVariablesOutputs(file, variables, labelNum);
        file.write("\n\t; Exit\n\tmov rax,0x3c\n\txor rdi,rdi\n\tsyscall\n");
        file.close();
    }
}

