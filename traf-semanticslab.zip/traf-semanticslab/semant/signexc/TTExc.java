package semant.signexc;

public enum TTExc {
    NONE_B, TT, FF, ERR_B, T, ANY_B
}
