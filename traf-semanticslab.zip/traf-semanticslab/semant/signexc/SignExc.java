package semant.signexc;

public enum SignExc {
    NONE_A, NEG, ZERO, POS, ERR_A, NON_POS, NON_ZERO, NON_NEG, Z, ANY_A
}
