package semant.whilesyntax;

import semant.signexc.TTExc;
import semant.amsyntax.*;

public class BCode {
	public TTExc e;
	public Code c;
	public BCode(TTExc _e, Code _c) {
		e = _e;
		c = _c;
	}
	public BCode(TTExc _e, Inst i) {
		e = _e;
		c = new Code();
		c.add(i);
	}
}
