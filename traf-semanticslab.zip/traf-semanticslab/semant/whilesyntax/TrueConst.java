package semant.whilesyntax;

import semant.WhileVisitor;
import semant.amsyntax.Code;

public class TrueConst extends Bexp {
    public BCode accept(WhileVisitor v) {
        return v.visit(this);
    }
    
}
