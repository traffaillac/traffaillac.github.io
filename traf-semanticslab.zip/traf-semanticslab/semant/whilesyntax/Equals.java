package semant.whilesyntax;

import semant.WhileVisitor;
import semant.amsyntax.Code;

public class Equals extends Bexp {

    public final Aexp a1, a2;
    
    public Equals(Aexp a1, Aexp a2) {
        this.a1 = a1;
        this.a2 = a2;
    }

    public BCode accept(WhileVisitor v) {
        return v.visit(this);
    }
}
