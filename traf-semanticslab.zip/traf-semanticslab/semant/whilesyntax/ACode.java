package semant.whilesyntax;

import semant.signexc.SignExc;
import semant.amsyntax.*;

public class ACode {
	public SignExc e;
	public Code c;
	public ACode(SignExc _e, Code _c) {
		c = _c;
		e = _e;
	}
	public ACode(SignExc _e, Inst i) {
		e = _e;
		c = new Code();
		c.add(i);
	}
}
